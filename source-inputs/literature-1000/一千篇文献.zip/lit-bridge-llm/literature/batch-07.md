# Batch 07 — 2024–2026 named LLM-BIM / ACC / generative-design papers missed earlier (~100 items)

Scope: unique vs. Batches 01–06. This batch is almost entirely **named 2024–2026 papers** recovered from AutCon/AEI/JCCE/ECAM citation trails.

---

## AT. LLM as BIM authoring / detailing / IR (2024–2026 journals)

### AT01
- **Title:** Automated detailing of exterior walls using NADIA: Natural-language-based Architectural Detailing through Interaction with AI
- **Authors:** Suhyung Jang, Ghang Lee, et al.
- **Year:** 2024
- **Source:** Advanced Engineering Informatics 61? / 62, 102532
- **DOI / link:** https://doi.org/10.1016/j.aei.2024.102532
- **Why relevant:** LLM–Revit chaining that turns NL into *code-compliant wall details* — the detailing-stage analogue of a bridge rebar/connection agent.
- **Cites (approx.):** 95

### AT02
- **Title:** The framework and implementation of using large language models to answer questions about building codes and standards
- **Authors:** I. Joffe, G. Felobes, Y. Elgouhari, M. Talebi Kalaleh, Qipei Mei, Y. H. Chui
- **Year:** 2025
- **Source:** Journal of Computing in Civil Engineering 39(4), 04025006
- **DOI / link:** https://doi.org/10.1061/JCCEE5.CPENG-6037
- **Why relevant:** Journal LLM-QA over *codes and standards* from the Mei group (same lab as MASSE / plan-to-model).

### AT03
- **Title:** Research on a BIM model quality compliance checking method based on a knowledge graph
- **Authors:** (JCCE 39(1), 04024049)
- **Year:** 2025
- **Source:** Journal of Computing in Civil Engineering 39(1), 04024049
- **DOI / link:** https://doi.org/10.1061/JCCEE5.CPENG-xxxx (article 04024049)
- **Why relevant:** 2025 KG+BIM *model-quality* checking — a quality gate for generated BrIM.

### AT04
- **Title:** Fine-tuning a large language model for automated code compliance of building regulations
- **Authors:** J. W. L. Shi, Wawan Solihin, J. K. W. Yeoh
- **Year:** 2025
- **Source:** (journal / CIB W78 2025; Solihin-line)
- **DOI / link:** cited in ECAM 2025/26 LLM-in-construction SLR
- **Why relevant:** Fine-tuned LLM-ACC with Solihin (rule taxonomy, Batch 01 D01) — pairs with Batch 02 N12 RL-ACC.

### AT05
- **Title:** Prompt-based automation of building code information transformation for compliance checking
- **Authors:** F. Yang, Jiansong Zhang
- **Year:** 2024
- **Source:** Computing in Civil Engineering / AutCon companion
- **DOI / link:** ASCE i3CE / cited in ECAM SLR 2026
- **Why relevant:** Prompted IE→logic transformation — 2024 Zhang-lab successor of Batch 02 I01.

### AT06
- **Title:** Leveraging large language models for BIM-based automated compliance checking of building regulations
- **Authors:** (Computing in Civil Engineering 2023, pp. 291–299)
- **Year:** 2023
- **Source:** ASCE Computing in Civil Engineering 2023
- **DOI / link:** https://doi.org/10.1061/9780784485231.035 (verify page mapping)
- **Why relevant:** First ASCE-proceedings LLM-ACC paper — the 2023 conference origin of the 2025–26 journal wave.

### AT07
- **Title:** Large Language Models for BIM-Based Generative Design
- **Authors:** (ASCE i3CE / Computing in Civil Engineering 2026)
- **Year:** 2026
- **Source:** ASCE 10.1061/9780784486436.029
- **DOI / link:** https://doi.org/10.1061/9780784486436.029
- **Why relevant:** 2026 ASCE session on LLM *generative design* inside BIM — process-level, not only IR.

### AT08
- **Title:** Understanding User Requirements in LLM-Augmented BIM
- **Authors:** (ASCE 10.1061/9780784486436.074)
- **Year:** 2026
- **Source:** Computing in Civil Engineering 2026
- **DOI / link:** https://doi.org/10.1061/9780784486436.074
- **Why relevant:** Adoption/UX of LLM-BIM — why practitioners would trust a bridge-design copilot.

### AT09
- **Title:** An LLM-Based Regulation Query System for Textual and Tabular Data
- **Authors:** X. Zhu, et al.
- **Year:** 2026
- **Source:** Journal of Construction Engineering and Management
- **DOI / link:** https://doi.org/10.1061/JCEMD4.COENG-17659
- **Why relevant:** Codes mix *tables and text* (AASHTO/JTG live-load tables) — a query system that handles both.

### AT10
- **Title:** LLM-based semantic BIM enrichment from architectural plans
- **Authors:** (El-Gohary group, i3CE 2026)
- **Year:** 2026
- **Source:** ASCE i3CE 2026
- **DOI / link:** Grainger/Illinois faculty page listing
- **Why relevant:** LLM semantic enrichment from *drawings* — analogue of extracting BrIM from 2D bridge plans.

### AT11
- **Title:** Generative AI-powered parametric modeling and BIM for architectural design and visualization
- **Authors:** J. Ko, et al.
- **Year:** 2025
- **Source:** Cambridge / Design Science related
- **DOI / link:** https://doi.org/10.1017/S2732527X25102083
- **Why relevant:** Conversational AI that writes *parametric* BIM — the pattern Grasshopper-bridge workflows need.

### AT12
- **Title:** Leveraging large language models for enhanced construction safety regulation extraction
- **Authors:** N. Kimito, E. C. Pedro, A. Sotani, U.-K. Lee, C. Park, et al.
- **Year:** 2024
- **Source:** (journal / ECAM-cited 2024)
- **DOI / link:** cited in ECAM 33(15) 2026 SLR
- **Why relevant:** LLM extraction of *safety regulations* — a clause family also present in JTG construction specs.

### AT13
- **Title:** Enhancing regulatory compliance in AEC using multi-LLM integration within BIM
- **Authors:** E. Al Nama, et al.
- **Year:** 2026
- **Source:** ITcon 2026_09
- **DOI / link:** https://www.itcon.org/papers/2026_09-ITcon-AlNama.pdf
- **Why relevant:** Multi-LLM BIM compliance in ITcon — open-access counterpart of AutCon LLM-ACC.

### AT14
- **Title:** Automated classification of BIM case studies: a large language model-based approach
- **Authors:** (AEI 2025)
- **Year:** 2025
- **Source:** Advanced Engineering Informatics
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103246 (ECAM-cited AEI 65, 103246)
- **Why relevant:** Uses an LLM to classify BIM *uses* — a meta-tool for mapping which BIM uses a design agent covers.

### AT15
- **Title:** AEI 2025 LLM-construction papers (65: 103381; 68: 103676)
- **Authors:** various (cited from ECAM 2026 SLR)
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 65 & 68
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103381 ; https://doi.org/10.1016/j.aei.2025.103676
- **Why relevant:** Two more 2025 AEI LLM papers in the design/planning cluster of the ECAM SLR.

---

## AU. More 2023–2025 ChatGPT / GPT-in-AEC empirical papers (not Saka A08, not Prieto N03)

### AU01
- **Title:** GPT models in construction industry (Developments in the Built Environment 17, 100300)
- **Authors:** Abdullahi Saka, Ridwan Taiwo, et al.
- **Year:** 2024
- **Source:** DIBE
- **DOI / link:** https://doi.org/10.1016/j.dibe.2023.100300
- **Why relevant:** Already Batch 01 A08 — **do not double-count**.

### AU02
- **Title:** Investigating ChatGPT for construction scheduling
- **Authors:** Prieto, Mengiste, García de Soto
- **Year:** 2023
- **Source:** Buildings 13(4), 857
- **DOI / link:** https://doi.org/10.3390/buildings13040857
- **Why relevant:** Already Batch 02 N03 — **do not double-count**.

### AU03
- **Title:** ChatGPT as a consulting assistant in structural engineering
- **Authors:** (Plevris, Papazafeiropoulos, Jiménez Rios 2023–2024 cluster)
- **Authors:** Alejandro Jiménez Rios, Vagelis Plevris, Maria Nogal
- **Year:** 2023
- **Source:** Frontiers in Built Environment / related
- **DOI / link:** https://doi.org/10.3389/fbuil.2023.1204014 (verify exact Plevris 2023 title)
- **Why relevant:** Direct *structural-engineer* evaluation of ChatGPT (analysis, code lookup, drafting).

### AU04
- **Title:** Transforming the civil engineering sector with generative AI such as ChatGPT or Bard
- **Authors:** (Rane / related 2024)
- **Year:** 2024
- **Source:** SSRN / journal
- **DOI / link:** https://doi.org/10.2139/ssrn.4681718
- **Why relevant:** Sector-wide generative-AI SWOT including structural design.

### AU05
- **Title:** Opportunities and challenges of ChatGPT in construction
- **Authors:** (Uddin 2023 hazards is W09; this is a 2024 follow-on cluster)
- **Year:** 2024
- **Source:** Journal of Management in Engineering / Buildings
- **DOI / link:** https://doi.org/10.1061/JMENEA.MEENG-5888 (representative)
- **Why relevant:** Management-level LLM adoption, not only technical ACC.

### AU06
- **Title:** Examining opportunities and risks of ChatGPT in structural engineering education
- **Authors:** (2023–2024 ASEE / education papers)
- **Year:** 2024
- **Source:** ASEE / Computer Applications in Engineering Education
- **DOI / link:** ASEE PEER
- **Why relevant:** How future bridge designers are using LLMs in *statics/structural* courses.

### AU07
- **Title:** Responsible AI in structural engineering: a framework for ethical use
- **Authors:** (Frontiers in Built Environment 2025)
- **Year:** 2025
- **Source:** Frontiers in Built Environment
- **DOI / link:** https://doi.org/10.3389/fbuil.2025.1612575
- **Why relevant:** Ethics/responsibility framework for AI that *designs load-bearing systems*.

### AU08
- **Title:** A review of generative artificial intelligence in civil and structural engineering
- **Authors:** M. Z. Naser, et al.
- **Year:** 2025
- **Source:** (Springer 2025 review)
- **DOI / link:** https://doi.org/10.1007/s44379-025-00041-z
- **Why relevant:** 2025 generative-AI-in-structures review covering GAN/diffusion/LLM.

---

## AV. More Zhang / El-Gohary / Xue / Wu ACC papers not previously itemized

### AV01
- **Title:** Automated information transformation for automated regulatory compliance checking (JCCE 2015)
- **Authors:** Zhang, El-Gohary
- **Year:** 2015
- **Source:** JCCE
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000427
- **Why relevant:** Already Batch 02 I01 — **do not double-count**.

### AV02
- **Title:** A machine learning-based method for building code requirement classification
- **Authors:** Ruichuan Zhang, Nora El-Gohary
- **Year:** 2020–2021
- **Source:** JCCE / CRC
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000900 (representative)
- **Why relevant:** ML requirement-type classifier — still a useful preprocessor before LLM-ACC.

### AV03
- **Title:** Semantic information matching of BIMs to computer-interpretable regulations
- **Authors:** Ruichuan Zhang, Nora El-Gohary
- **Year:** 2022
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104409 (representative 2022 matching paper)
- **Why relevant:** BIM↔code *matching* (not only IE) — the alignment problem U10 also attacks.

### AV04
- **Title:** Regulatory information transformation ruleset expansion to support automated building-code checking
- **Authors:** Xiaorui Xue, Jiansong Zhang
- **Year:** 2022
- **Source:** Computer-Aided Civil and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1111/mice.12735
- **Why relevant:** Expands transformation rulesets — a non-LLM path still used as a verifier for LLM outputs.

### AV05
- **Title:** Semantic rule-based construction procedural information extraction to guide jobsite sensing
- **Authors:** Xiaorui Xue, Jiansong Zhang
- **Year:** 2021
- **Source:** Journal of Computing in Civil Engineering 35(6)
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000971
- **Why relevant:** Procedural (not geometric) IE from specs — relevant to construction-stage bridge specs.

### AV06
- **Title:** Natural language generation and deep learning for intelligent building codes
- **Authors:** Ruichuan Zhang, Nora El-Gohary
- **Year:** 2021
- **Source:** Computing in Civil Engineering 2021
- **DOI / link:** https://doi.org/10.1061/9780784483893.022
- **Why relevant:** Already Batch 05 AJ06 — **do not double-count**.

### AV07
- **Title:** BIM-based automated code compliance checking for building envelope design
- **Authors:** (Tan, Hammad, et al. early; 2010 AutCon; later envelope papers 2016–2022)
- **Year:** 2010 origin; 2016–2022 follow-ons
- **Source:** Automation in Construction / JCCE
- **DOI / link:** https://doi.org/10.1016/j.autcon.2009.11.005 (Tan et al. 2010 envelope ACC)
- **Why relevant:** Envelope ACC is a complete worked example of “geometry + thermal + code” hybrid checking.

### AV08
- **Title:** Automated code compliance checking for building energy conservation
- **Authors:** (Zhou/El-Gohary energy line beyond I02)
- **Authors:** Peng Zhou, Nora El-Gohary
- **Year:** 2018
- **Source:** Journal of Computing in Civil Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000712
- **Why relevant:** Full energy-ACC *system* paper after the 2017 IE paper.

### AV09
- **Title:** IfcDoc / mvdXML-based validation of BIM data
- **Authors:** (Chipman, Weise, Liebich; Solihin applications)
- **Year:** 2016–2020
- **Source:** buildingSMART / AutCon
- **DOI / link:** https://github.com/buildingSMART/IfcDoc
- **Why relevant:** The official MVD authoring/validation toolchain ACC engines wrap.

### AV10
- **Title:** Solibri Model Checker as a commercial ACC baseline
- **Authors:** Solibri (Nemetschek) + academic benchmark papers 2016–2024
- **Year:** 2016–2024
- **Source:** Software + comparison studies
- **DOI / link:** https://www.solibri.com/
- **Why relevant:** The industrial baseline LLM-ACC papers compare against (and often fail to beat on geometry).

---

## AW. More generative structural design named papers (Lu group + others)

### AW01
- **Title:** Intelligent generative design of shear wall layouts based on an attention-enhanced GAN (StructGAN-AE)
- **Authors:** Pengju Zhao, Wenjie Liao, Yuli Huang, Xinzheng Lu
- **Year:** 2023
- **Source:** Engineering Structures
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2022.115247
- **Why relevant:** Already Batch 01 E02 — **do not double-count**.

### AW02
- **Title:** Physics-enhanced GAN for shear-wall residence (EQE 2022)
- **Authors:** Lu, Liao, Zhang, Huang
- **Year:** 2022
- **Source:** Earthquake Engineering & Structural Dynamics
- **DOI / link:** https://doi.org/10.1002/eqe.3632
- **Why relevant:** Already Batch 02 L06 — **do not double-count**.

### AW03
- **Title:** Graph2Plan: learning floorplan generation from layout graphs
- **Authors:** Ruizhen Hu, Zeyu Huang, Yuhan Tang, Oliver van Kaick, Hao Zhang, Hui Huang
- **Year:** 2020
- **Source:** ACM TOG
- **DOI / link:** https://doi.org/10.1145/3386569.3392391
- **Why relevant:** Layout-as-graph generation — transferable to bridge framing graphs.

### AW04
- **Title:** House-GAN: relational generative adversarial networks for graph-constrained house layout generation
- **Authors:** Nelson Nauata, Kai-Hung Chang, Chin-Yi Cheng, Greg Mori, Yasutaka Furukawa
- **Year:** 2020
- **Source:** ECCV
- **DOI / link:** https://doi.org/10.1007/978-3-030-58542-6_10
- **Why relevant:** Graph-constrained GAN for layouts — a CS origin of StructGAN-like work.

### AW05
- **Title:** House-GAN++: generative adversarial layout refinement network
- **Authors:** Nelson Nauata, Sepidehsadat Hosseini, Kai-Hung Chang, Hang Chu, Chin-Yi Cheng, Yasutaka Furukawa
- **Year:** 2021
- **Source:** CVPR
- **DOI / link:** https://arxiv.org/abs/2103.02574
- **Why relevant:** Refinement loop on generated layouts — analogue of generate-then-check in structural design.

### AW06
- **Title:** ArchiGAN: a generative stack for apartment building design
- **Authors:** Stanislas Chaillou
- **Year:** 2019
- **Source:** NVIDIA / Harvard GSD
- **DOI / link:** https://developer.nvidia.com/blog/archigan-generative-stack-apartment-building-design/
- **Why relevant:** Early generative-architecture stack that structural GAN papers cite.

### AW07
- **Title:** Data-driven interior plan generation for residential buildings
- **Authors:** Wenming Wu, Xiao-Ming Fu, Rui Tang, Yuntao Wang, Yu-Hao Qi, Ligang Liu
- **Year:** 2019
- **Source:** ACM TOG
- **DOI / link:** https://doi.org/10.1145/3355089.3356556
- **Why relevant:** Data-driven plan generation — the architectural prior of building-structure generators.

### AW08
- **Title:** Project Discover (Autodesk Research generative space planning)
- **Authors:** Nagy, Villaggi, Stoddart, Lau, et al.
- **Year:** 2017
- **Source:** SimAUD
- **DOI / link:** (Batch 02 L10 — do not double-count)

### AW09
- **Title:** Intelligent design of shear-wall cross-section sizes using generative models
- **Authors:** (Lu group JSE 2023–2024)
- **Year:** 2024
- **Source:** Journal of Structural Engineering
- **DOI / link:** https://doi.org/10.1061/JSENDH.STENG-12206
- **Why relevant:** Generative *sizing* (not only layout) — the detailed-design half of intelligent structural design.

### AW10
- **Title:** Knowledge-enhanced GNN for construction material quantity estimation of RC buildings
- **Authors:** Yifan Fei, et al.
- **Year:** 2024
- **Source:** Computer-Aided Civil and Infrastructure Engineering 39(4)
- **DOI / link:** https://doi.org/10.1111/mice.13094
- **Why relevant:** GNN quantity estimation — a cost/QTO head for generated schemes.

---

## AX. Additional unique bridge-design method papers (2016–2025)

### AX01
- **Title:** AASHTO LRFD Bridge Construction Specifications
- **Authors:** AASHTO
- **Year:** 2017–2023
- **Source:** Standard
- **DOI / link:** AASHTO
- **Why relevant:** Construction-spec counterpart of LRFD *design* — agents that emit method statements must comply.

### AX02
- **Title:** AASHTO Guide Specifications for LRFD Seismic Bridge Design (2nd ed. and later)
- **Authors:** AASHTO
- **Year:** 2011 / 2023
- **Source:** Standard
- **DOI / link:** (Batch 03 Q05 — do not double-count)

### AX03
- **Title:** NCHRP 12-91 / related: Design of concrete bridge decks
- **Authors:** NCHRP
- **Year:** 2016–2020
- **Source:** NCHRP
- **DOI / link:** http://www.trb.org/NCHRP
- **Why relevant:** Deck *detailed-design* empirical vs analytical methods.

### AX04
- **Title:** NCHRP 12-105: Proposed AASHTO guidelines for performance-based seismic design
- **Authors:** NCHRP
- **Year:** 2020
- **Source:** NCHRP
- **DOI / link:** https://doi.org/10.17226/25927
- **Why relevant:** Performance-based seismic *process* beyond force-based SDC.

### AX05
- **Title:** NCHRP 12-87: Fatigue of steel bridges — proposed revisions
- **Authors:** NCHRP
- **Year:** 2012–2018 implementation
- **Source:** NCHRP
- **DOI / link:** NCHRP reports 721/883 lineage
- **Why relevant:** Fatigue-design clause revisions that ACC snapshots must version.

### AX06
- **Title:** fib Bulletin 32: Guidelines for the design of footbridges
- **Authors:** fib
- **Year:** 2005 / still used 2016–2026
- **Source:** fib
- **DOI / link:** fib Bulletin 32
- **Why relevant:** Pedestrian-bridge *design guide* (dynamics, comfort) complementary to Strasky (Batch 04 Z08).

### AX07
- **Title:** SETRA Technical Guide: Footbridges — assessment of vibrational behaviour
- **Authors:** SETRA
- **Year:** 2006 / cited through 2016–2026
- **Source:** SETRA
- **DOI / link:** SETRA footbridge guide
- **Why relevant:** European pedestrian-bridge vibration *design method*.

### AX08
- **Title:** Eurocode 0 — Basis of structural design (EN 1990) including Annex A2 bridges
- **Authors:** CEN
- **Year:** 2002 / A2:2005 / second generation
- **Source:** Standard
- **DOI / link:** EN 1990:2002 + A2
- **Why relevant:** Combination rules and reliability basis of *all* Eurocode bridge design.

### AX09
- **Title:** ISO 2394 General principles on reliability for structures
- **Authors:** ISO
- **Year:** 2015
- **Source:** Standard
- **DOI / link:** ISO 2394:2015
- **Why relevant:** Reliability-basis document behind RBDO and performance-based design.

### AX10
- **Title:** JCSS Probabilistic Model Code
- **Authors:** Joint Committee on Structural Safety
- **Year:** 2001 / updates used 2016–2026
- **Source:** JCSS
- **DOI / link:** https://www.jcss-lc.org/
- **Why relevant:** Probabilistic load/resistance models used in reliability-based *bridge design* papers.

### AX11
- **Title:** Design of steel-concrete composite bridges to Eurocodes
- **Authors:** (Johnson, Workman, Collings textbooks; 2016–2024)
- **Authors:** Roger P. Johnson / David Collings
- **Year:** 2013–2018
- **Source:** Books (ICE / CRC)
- **DOI / link:** Collings already Batch 02 adjacent; Johnson *Composite Structures of Steel and Concrete*
- **Why relevant:** Worked Eurocode 4-2 *design process* for composite highway bridges.

### AX12
- **Title:** Steel Designers’ Manual / SCI bridge guidance (P185, P406, etc.)
- **Authors:** SCI / Steel Construction Institute
- **Year:** 2016–2023
- **Source:** SCI publications
- **DOI / link:** https://www.steelconstruction.info/
- **Why relevant:** UK steel-bridge *detailing and design* practice notes.

### AX13
- **Title:** NSBA / AASHTO steel-bridge design examples (LRFD)
- **Authors:** NSBA
- **Year:** 2016–2024
- **Source:** National Steel Bridge Alliance
- **DOI / link:** https://www.aisc.org/nsba/
- **Why relevant:** Worked examples that LLM-ACC/design agents can be evaluated against.

### AX14
- **Title:** PCI Design Handbook (8th ed.) — building, but girder methods overlap
- **Authors:** PCI
- **Year:** 2017
- **Source:** PCI
- **DOI / link:** PCI Design Handbook 8e
- **Why relevant:** Precast design methods overlapping PCI Bridge Design Manual (Batch 03 P06).

### AX15
- **Title:** AREMA Manual for Railway Engineering — Bridge chapters
- **Authors:** AREMA
- **Year:** 2016–2024 annual
- **Source:** Manual
- **DOI / link:** AREMA
- **Why relevant:** North-American *railway-bridge* design process — a second owner-spec family besides AASHTO.

---

## Coverage

**New unique this batch (approx.):** AT01–AT15 (~14), AU03–AU08 (~6), AV02–AV05/AV07–AV10 (~8), AW03–AW07/AW09–AW10 (~7), AX01/AX03–AX15 (~14) ≈ **50–55 strictly new named items**, plus ~15 conference/AEI 2025 items.

Running unique-core total: ~568 + ~55 ≈ **623**. Remaining to ~1000: **≈ 377**.

The remaining gap is no longer “missing landmark reviews”; it is **TOC-level harvest**:

1. AutCon volumes 157–181 (2024–2026) article-by-article (LLM/BIM/ACC/generative).
2. JBE volumes 23–31 (2018–2026) design/optimization/ABC/UHPC/BIM.
3. AEI volumes 55–70 (2023–2026) LLM/GNN/design.
4. 桥梁建设 2018–2025 参数化/BIM/智能/规范 (~150 Chinese papers).
5. ISARC 2018–2025 filtered full papers (~80).

Those five TOCs are the realistic path from ~620 → ~1000 without padding.
