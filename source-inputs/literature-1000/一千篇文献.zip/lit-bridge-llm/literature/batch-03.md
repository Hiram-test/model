# Batch 03 — ABC/UHPC, wind–seismic–fatigue design, foundations, conferences, tool layer, more ACC (~112 items)

Scope: unique vs. `batch-01-core-90.md` and `batch-02.md`. Continues both spines:

1. **Traditional / computational design:** ABC and prefabricated systems; UHPC as a design system; wind/seismic/fatigue *design methods*; substructure and integral abutments; IFC Alignment / IDS / mvdXML; conference corpus.
2. **Agentic / LLM:** remaining tool-use, drawing/IDS, and ACC-transformer papers that Batch 02 did not take.

Priority: 2016–2026 with a few still-cited method landmarks (2011–2015) that later papers treat as the process baseline.

---

## P. Accelerated / prefabricated / UHPC / composite bridge design systems

### P01
- **Title:** Accelerated Bridge Construction: Experience in Design, Fabrication and Erection of Prefabricated Bridge Elements and Systems
- **Authors:** Michael P. Culmo (FHWA)
- **Year:** 2011
- **Source:** FHWA-HIF-12-013 (manual)
- **DOI / link:** https://www.fhwa.dot.gov/bridge/abc/docs/abcmanual.pdf
- **Why relevant:** The US *design–detailing–erection* process for PBES/ABC — the construction-system choice that parametric BrIM and AutoBIM-style agents (Batch 01 F15) encode.

### P02
- **Title:** Ultra-High Performance Concrete: A State-of-the-Art Report for the Bridge Community
- **Authors:** Henry G. Russell, Benjamin A. Graybeal
- **Year:** 2013
- **Source:** FHWA-HRT-13-060
- **DOI / link:** https://rosap.ntl.bts.gov/view/dot/26387
- **Why relevant:** Bridge-community SOTA on UHPC as a *design material/system*, not a lab curiosity — cited by almost all later UHPC girder/connection papers.
- **Cites (approx.):** 800+

### P03
- **Title:** Design and Construction of Field-Cast UHPC Connections
- **Authors:** Benjamin A. Graybeal
- **Year:** 2014 / update 2019 (FHWA-HIF-19-011)
- **Source:** FHWA
- **DOI / link:** https://www.fhwa.dot.gov/publications/research/infrastructure/structures/14084/14084.pdf
- **Why relevant:** Connection *design procedure* that governs prefabricated-bridge joints — a prime target for automated detailing and ACC.

### P04
- **Title:** Shear Behavior of Ultrahigh-Performance Concrete Prestressed Girders
- **Authors:** Rafic G. El-Helou, Benjamin A. Graybeal
- **Year:** 2022
- **Source:** Journal of Structural Engineering 148(6)
- **DOI / link:** https://doi.org/10.1061/(ASCE)ST.1943-541X.0003279
- **Why relevant:** Experimental basis for UHPC girder *shear design* — the code-writing input that future UHPC-ACC agents will check.

### P05
- **Title:** Accelerated Bridge Construction: Best Practices and Techniques
- **Authors:** Mohiuddin Ali Khan
- **Year:** 2014 / 2015
- **Source:** Butterworth-Heinemann (book)
- **DOI / link:** https://doi.org/10.1016/C2013-0-09963-2
- **Why relevant:** Textbook of ABC planning, design and modular systems — the process knowledge Batch 01 F15/F16 automate in BIM.

### P06
- **Title:** PCI Bridge Design Manual (3rd / 4th ed.)
- **Authors:** Precast/Prestressed Concrete Institute
- **Year:** 2011–2023 editions
- **Source:** PCI (manual)
- **DOI / link:** https://www.pci.org/PCI/Publications/Bridge_Design_Manual
- **Why relevant:** US precast-girder *detailed-design* bible (sections, prestress, camber, connections) used as the rule source of girder ACC systems (Batch 01 D07).

### P07
- **Title:** International Perspective on UHPC in Bridge Engineering
- **Authors:** Benjamin A. Graybeal, Eugen Brühwiler, Byung-Suk Kim, François Toutlemonde, Yen Lei Voo, Alain Zagury
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(11), 04020094
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0001630
- **Why relevant:** Global map of UHPC bridge *typologies and design practice* (US/France/Korea/Malaysia/Switzerland).

### P08
- **Title:** Design and Construction of UHPC-Based Bridge Structures in China
- **Authors:** Xudong Shao, Junhui Cao, et al.
- **Year:** 2018–2021 (JBE / Structural Engineering International series)
- **Source:** Journal of Bridge Engineering / SEI
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0001225 (representative Shao UHPC deck paper)
- **Why relevant:** Chinese UHPC steel–UHPC composite deck as a *scheme-level* design option — pairs with Batch 02 O02.

### P09
- **Title:** Seismic Performance of Precast Bridge Columns with UHPC/grouted duct connections
- **Authors:** Mostafa Tazarv, M. Saiid Saiidi
- **Year:** 2016
- **Source:** Journal of Bridge Engineering / Engineering Structures
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000765
- **Why relevant:** ABC *seismic* column connection design — substructure detailing that agents must not omit when generating prefabricated piers.

### P10
- **Title:** Prefabricated Bridge Elements and Systems in Japan and Europe
- **Authors:** Mary Lou Ralls, Benjamin Tang, et al. (FHWA scanning tour / follow-on)
- **Year:** 2005 scanning; still the practice baseline cited through 2016–2026 ABC papers
- **Source:** FHWA
- **DOI / link:** https://international.fhwa.dot.gov/pubs/pl05003/pl05003.pdf
- **Why relevant:** Comparative prefabrication *design culture* that later US/CN ABC manuals localize.

### P11
- **Title:** Corrugated steel web PC composite bridges: design and practice in China
- **Authors:** Yongjian Liu (刘永健) et al.
- **Year:** 2016–2022
- **Source:** Journal of Bridge Engineering / 土木工程学报
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000994 (representative)
- **Why relevant:** A major Chinese *composite-scheme* family (corrugated web) with its own conceptual/preliminary design rules.

### P12
- **Title:** Segmental concrete bridges
- **Authors:** Dong Xu (徐栋) / ASBI / fib guidance
- **Year:** 2016–2020 (textbook + JBE papers)
- **Source:** 人民交通出版社 / Journal of Bridge Engineering
- **DOI / link:** ASBI Construction Practices Handbook; related Xu papers on external prestress
- **Why relevant:** Span-by-span / balanced-cantilever *detailed-design process* for PC box girders — the dominant long-viaduct method.

### P13
- **Title:** NCHRP Report 12-74 / related: Connection Details for Prefabricated Bridge Elements and Systems
- **Authors:** NCHRP / Marsh, Stanton, et al.
- **Year:** 2011–2016
- **Source:** Transportation Research Board
- **DOI / link:** https://www.trb.org/Publications/Blurbs/165164.aspx
- **Why relevant:** Standardized ABC *connection* catalogue — a component library a generative prefab-bridge agent would retrieve.

### P14
- **Title:** Every Day Counts — Accelerated Bridge Construction
- **Authors:** FHWA
- **Year:** 2012–2024 (EDC rounds)
- **Source:** US DOT programme
- **DOI / link:** https://www.fhwa.dot.gov/innovation/everydaycounts/
- **Why relevant:** The policy driver that made ABC a *default design option* in US preliminary engineering, not an exotic alternative.

---

## Q. Wind, seismic and fatigue design methods (long-span and highway bridges)

### Q01
- **Title:** Wind Effects on Cable-Supported Bridges
- **Authors:** You-Lin Xu
- **Year:** 2013
- **Source:** Wiley (book)
- **DOI / link:** https://doi.org/10.1002/9781118188309
- **Why relevant:** End-to-end wind *design process* for cable-stayed/suspension bridges (buffeting, flutter, rain-wind) used in detailed design.

### Q02
- **Title:** Wind Loading of Structures (3rd/4th ed.)
- **Authors:** John D. Holmes
- **Year:** 2015 / 2021
- **Source:** CRC Press (book)
- **DOI / link:** https://doi.org/10.1201/9780429296130
- **Why relevant:** Code-oriented wind-loading method (terrain, spectra, dynamic response) that bridge wind chapters implement.

### Q03
- **Title:** State-of-the-art of wind-induced vibrations of long-span bridges
- **Authors:** Yaojun Ge (葛耀君), et al.
- **Year:** 2016–2021 (Engineering / JWEIA reviews)
- **Source:** Engineering / Journal of Wind Engineering and Industrial Aerodynamics
- **DOI / link:** https://doi.org/10.1016/j.eng.2017.12.018 (Ge, 2018, *Engineering* — representative)
- **Why relevant:** Chinese long-span wind-design SOTA (flutter control, section optimization) complementary to Xu’s book.

### Q04
- **Title:** Shape optimization of bridge decks for aerodynamic performance
- **Authors:** (Larsen, Larose, Diana, Cid Montoya lines — 2016–2022 JWEIA)
- **Authors:** Allan Larsen, Guy L. Larose / complementary Cid Montoya 2018 (Batch 02 H16)
- **Year:** 2016–2022
- **Source:** Journal of Wind Engineering and Industrial Aerodynamics
- **DOI / link:** https://doi.org/10.1016/j.jweia.2016.07.008 (representative Larsen/Larose flutter-control paper)
- **Why relevant:** Deck-section *conceptual* choices driven by aeroelastic constraints — a generator must respect these, not only gravity TO.

### Q05
- **Title:** AASHTO Guide Specifications for LRFD Seismic Bridge Design
- **Authors:** AASHTO
- **Year:** 2011 / 2023 updates
- **Source:** Standard
- **DOI / link:** AASHTO publication
- **Why relevant:** Displacement-based US seismic *design process* for ordinary bridges (pushover, plastic hinges) — ACC target distinct from AASHTO LRFD strength (Batch 01 B05).

### Q06
- **Title:** Caltrans Seismic Design Criteria (SDC)
- **Authors:** California Department of Transportation
- **Year:** 2013–2019 versions
- **Source:** Standard
- **DOI / link:** https://dot.ca.gov/programs/engineering-services/manuals/seismic-design-criteria
- **Why relevant:** The most detailed owner seismic-design *process* for bridges in the US; many research ACC/isolation papers instantiate SDC rules.

### Q07
- **Title:** Eurocode 8: Design of structures for earthquake resistance — Part 2: Bridges
- **Authors:** CEN (EN 1998-2)
- **Year:** 2005 / second-generation drafts 2020s
- **Source:** Standard
- **DOI / link:** EN 1998-2:2005
- **Why relevant:** European seismic-bridge code (behaviour factors, isolation, ductile piers).

### Q08
- **Title:** Eurocode 1: Actions on structures — Part 1-4: Wind actions; Part 2: Traffic loads on bridges
- **Authors:** CEN (EN 1991-1-4, EN 1991-2)
- **Year:** 2005 / updates
- **Source:** Standard
- **DOI / link:** EN 1991-1-4:2005; EN 1991-2:2003
- **Why relevant:** The load-model half of European bridge design (wind + LM1–LM4 traffic) that any automated load-takedown must implement.

### Q09
- **Title:** Displacement-Based Seismic Design of Structures
- **Authors:** M. J. N. Priestley, G. M. Calvi, M. J. Kowalsky
- **Year:** 2007 (IUSS Press; still the method book for 2016–2026 DDBD bridge papers)
- **Source:** IUSS Press (book)
- **DOI / link:** ISBN 978-88-6198-000-6
- **Why relevant:** Direct displacement-based design *process* — an alternative detailed-design algorithm to force-based AASHTO.

### Q10
- **Title:** Seismic isolation of highway bridges
- **Authors:** Ian G. Buckle, Ronald L. Mayes, et al. / MCEER guidance
- **Year:** 2011–2018 updates
- **Source:** MCEER / FHWA
- **DOI / link:** https://www.fhwa.dot.gov/bridge/seismic/
- **Why relevant:** Isolation as a *scheme-level* seismic strategy (bearings, residual displacement) in preliminary design.

### Q11
- **Title:** Seismic behavior of isolated bridges: A state-of-the-art review
- **Authors:** M. C. Kunde, R. S. Jangid (classic) / later 2016–2024 updates (Warn, Eröz, etc.)
- **Year:** 2003 review; 2016–2024 follow-ons in Engineering Structures
- **Source:** Engineering Structures / Bulletin of NZSEE
- **DOI / link:** https://doi.org/10.12989/eas.2003.4.3.237
- **Why relevant:** Maps isolation *design choices* (elastomeric vs sliding) that a conceptual-design agent would enumerate.

### Q12
- **Title:** Fatigue evaluation of steel bridges
- **Authors:** John W. Fisher, Ben T. Yen, et al. / AASHTO fatigue guide lineage
- **Year:** 2010s manuals; NCHRP 721 (2012) and later
- **Source:** NCHRP / Journal of Bridge Engineering
- **DOI / link:** NCHRP Report 721, https://doi.org/10.17226/22774
- **Why relevant:** Fatigue *limit-state design process* for steel bridges — often the governing detailed-design check, rarely yet in LLM-ACC demos.

### Q13
- **Title:** AASHTO LRFD Guide Specifications for the Design of Pedestrian Bridges / Fatigue of steel bridges chapters
- **Authors:** AASHTO
- **Year:** 2009–2020
- **Source:** Standard
- **DOI / link:** AASHTO
- **Why relevant:** Pedestrian/steel fatigue provisions as compact ACC case studies (fewer clause types than full LRFD).

### Q14
- **Title:** 桥梁抗震设计 (Highway Bridge Seismic Design)
- **Authors:** 范立础, 卓卫东 等
- **Year:** 2001 / later reprints used through 2016–2026 teaching
- **Source:** 人民交通出版社 (book)
- **DOI / link:** ISBN 978-7-114-03890-7
- **Why relevant:** Chinese seismic-bridge *design method* textbook — the process JTG/T 2231-01 implements.

### Q15
- **Title:** 公路桥梁抗震设计规范 JTG/T 2231-01-2020
- **Authors:** 交通运输部
- **Year:** 2020
- **Source:** Standard (replacing JTG/T B02-01-2008)
- **DOI / link:** JTG/T 2231-01-2020
- **Why relevant:** Live Chinese seismic-bridge code — a structured target for Chinese LLM-ACC beyond D60/3362.

### Q16
- **Title:** Wind-resistant design specification for highway bridges JTG/T 3360-01-2018
- **Authors:** 交通运输部
- **Year:** 2018
- **Source:** Standard
- **DOI / link:** JTG/T 3360-01-2018
- **Why relevant:** Chinese wind-design code for highway bridges (flutter checks, section choice) — the rule set behind Q03 practice.

---

## R. Substructure, foundations, integral abutments

### R01
- **Title:** 公路桥涵地基与基础设计规范 JTG 3363-2019
- **Authors:** 交通运输部
- **Year:** 2019
- **Source:** Standard
- **DOI / link:** JTG 3363-2019
- **Why relevant:** Chinese foundation/substructure code — pairs with Batch 02 N09 (foundation-design MAS) as the rule source.

### R02
- **Title:** Pile Foundation Analysis and Design
- **Authors:** H. G. Poulos, E. H. Davis / later Poulos 2017 collected papers
- **Year:** 1980 book; methods still in 2016–2026 bridge-foundation papers
- **Source:** Wiley / ISSMGE
- **DOI / link:** ISBN 0-471-02070-1
- **Why relevant:** Analytical pile *design process* (settlement, group action) that simplified agents still call.

### R03
- **Title:** Design of Pile Foundations (FHWA NHI-16-009 / GEC-8 updates)
- **Authors:** FHWA
- **Year:** 2016
- **Source:** FHWA Geotechnical Engineering Circular
- **DOI / link:** https://www.fhwa.dot.gov/engineering/geotech/pubs/nhi16009.pdf
- **Why relevant:** US owner procedure for driven/drilled shafts under bridges — the geotech half of preliminary design.

### R04
- **Title:** Integral abutment bridges: current practice in North America
- **Authors:** Martin P. Burke Jr. / White, Civjan, et al. follow-on surveys
- **Year:** 2009 book; 2016–2022 JBE practice papers
- **Source:** ASCE Press / Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/9780784409893
- **Why relevant:** Jointless-bridge *scheme* as a conceptual-design alternative with its own thermal/soil–structure rules.

### R05
- **Title:** Theoretical Stress–Strain Model for Confined Concrete
- **Authors:** J. B. Mander, M. J. N. Priestley, R. Park
- **Year:** 1988 (the confinement model still coded in every 2016–2026 seismic-pier paper)
- **Source:** Journal of Structural Engineering 114(8)
- **DOI / link:** https://doi.org/10.1061/(ASCE)0733-9445(1988)114:8(1804)
- **Why relevant:** The stress–strain *design model* inside displacement-based pier design — a physics tool isolation-agents must call.

### R06
- **Title:** Seismic Design and Retrofit of Bridges — isolation and substructure chapters (companion to Batch 02 M07)
- **Authors:** Priestley, Seible, Calvi
- **Year:** 1996
- **Source:** Wiley
- **DOI / link:** https://doi.org/10.1002/9780470172858
- **Why relevant:** Pier, joint and foundation *seismic design sequence* that later SDC/AASHTO guides compress.

### R07
- **Title:** NCHRP 12-49: Comprehensive Specification for the Seismic Design of Bridges
- **Authors:** ATC/MCEER Joint Venture
- **Year:** 2002 (basis of AASHTO Guide Specs Q05)
- **Source:** NCHRP
- **DOI / link:** https://www.trb.org/Publications/Blurbs/160726.aspx
- **Why relevant:** The research spec that created the US displacement-based bridge seismic *process*.

### R08
- **Title:** Drilled Shafts: Construction Procedures and LRFD Design Methods (GEC-10)
- **Authors:** FHWA (Brown, Turner, Castelli, Loehr)
- **Year:** 2018
- **Source:** FHWA-NHI-18-024
- **DOI / link:** https://www.fhwa.dot.gov/engineering/geotech/pubs/nhi18024.pdf
- **Why relevant:** LRFD drilled-shaft *design method* used for almost all US highway-bridge deep foundations.

---

## S. Conference corpus (ISARC, EG-ICE, EC3, CIB W78, IABSE, IASS, IWCCE)

### S01
- **Title:** SeeBridge Information Delivery Manual (IDM) for Next Generation Bridge Inspection
- **Authors:** Rafael Sacks, Amir Kedar, André Borrmann, Ling Ma, Dominic Singer, Uri Kattel
- **Year:** 2016
- **Source:** ISARC 2016 (Auburn)
- **DOI / link:** https://www.iaarc.org/publications/2016_proceedings_of_the_33rd_isarc_auburn_usa/seebridge_information_delivery_manual_idm_for_next_generation_bridge_inspection.html
- **Why relevant:** Conference origin of the SeeBridge IDM (journal version is Batch 02 J06).

### S02
- **Title:** An Approach to Translate Korea Building Act into Computer-Readable Form for Automated Design Assessment
- **Authors:** Hyunsoo Lee, Jin-Kook Lee, Seokyung Park, Inhan Kim
- **Year:** 2015
- **Source:** ISARC 2015 (Oulu)
- **DOI / link:** https://www.iaarc.org/publications/2015_proceedings_of_the_32st_isarc_oulu_finland/an_approach_to_translate_korea_building_act_into_computer_readable_form_for_automated_design_assessment.html
- **Why relevant:** ISARC origin of KBimCode (journal: Batch 02 I06).

### S03
- **Title:** Digital twinning of existing bridges from labelled point clusters
- **Authors:** Ruodan Lu, Ioannis Brilakis
- **Year:** 2019
- **Source:** ISARC 2019
- **DOI / link:** https://www.iaarc.org/publications/2019_proceedings_of_the_36th_isarc/digital_twinning_of_existing_bridges_from_labelled_point_clusters.html
- **Why relevant:** ISARC counterpart of Batch 02 K02 — shows the conference-to-journal path of BrIM/DT methods.

### S04
- **Title:** Information extraction from text documents for the semantic enrichment of BIM of bridges
- **Authors:** (ISARC 2022 Bogotá)
- **Year:** 2022
- **Source:** ISARC 2022
- **DOI / link:** http://www.iaarc.org/publications/2022_proceedings_of_the_39th_isarc_bogota_colombia/information_extraction_from_text_documents_for_the_semantic_enrichment_of_building_information_models_of_bridges.html
- **Why relevant:** NLP → semantic enrichment of *bridge* BIM from inspection/status reports — a pre-LLM agent skill.

### S05
- **Title:** How Can ChatGPT Help in Automated Building Code Compliance Checking?
- **Authors:** (ISARC 2023)
- **Year:** 2023
- **Source:** ISARC 2023
- **DOI / link:** http://www.iaarc.org/publications/fulltext/009_ISARC%202023_Paper_115.pdf
- **Why relevant:** First ISARC probe of ChatGPT for ACC — the conference sibling of Batch 01 D09/D10.

### S06
- **Title:** Combining parametric modeling and interactive optimization for high-performance and creative structural design
- **Authors:** Renaud A. Danhaive, Caitlin T. Mueller
- **Year:** 2015
- **Source:** IASS 2015
- **DOI / link:** http://digitalstructures.mit.edu/files/2015-09/iass2015-524698.pdf
- **Why relevant:** IASS statement of interactive evolutionary structural design (companion to Batch 02 H19).

### S07
- **Title:** Automated information extraction from construction-related regulatory documents for automated compliance checking
- **Authors:** Jiansong Zhang, Nora El-Gohary
- **Year:** 2011
- **Source:** CIB W78 2011
- **DOI / link:** https://itc.scix.net/paper/w78-2011-Paper-99
- **Why relevant:** CIB W78 origin of the Zhang/El-Gohary ACC line (journal: Batch 02 I01).

### S08
- **Title:** Computerizing regulatory knowledge for BIM-based compliance checking
- **Authors:** Johannes Dimyadi, Charles Clifton, Michael Spearpoint, Robert Amor
- **Year:** 2016
- **Source:** CIB W78 / ITcon
- **DOI / link:** https://www.itcon.org/paper/2016/24
- **Why relevant:** LegalRuleML / open legal-knowledge representation for ACC — still the alternative to “just prompt an LLM”.

### S09
- **Title:** Towards the exchange of parametric 3D bridge models using a neutral data format
- **Authors:** Yang Ji, André Borrmann, Mathias Obergrießer
- **Year:** 2011
- **Source:** ASCE IWCCE / EG-ICE lineage
- **DOI / link:** https://mediatum.ub.tum.de/doc/1160260/1160260.pdf
- **Why relevant:** Conference origin of Batch 02 L01 (IFC parametric bridges).

### S10
- **Title:** Integration of parametric geometry into IFC-Bridge
- **Authors:** (TUM / buildingSMART presentations 2014–2018)
- **Year:** 2015
- **Source:** EG-ICE / buildingSMART
- **DOI / link:** buildingSMART IFC-Bridge project documents
- **Why relevant:** The geometry-constraint discussion that made IFC 4.3 alignment+bridge possible.

### S11
- **Title:** Prospects of Integrating BIM and NLP for Automatic Construction Schedule Management
- **Authors:** (ISARC 2023 Chennai)
- **Year:** 2023
- **Source:** ISARC 2023
- **DOI / link:** https://www.iaarc.org/publications/2023_proceedings_of_the_40th_isarc_chennai_india/prospects_of_integrating_bim_and_nlp_for_automatic_construction_schedule_management.html
- **Why relevant:** BIM+NLP for scheduling — process neighbour of Prieto ChatGPT scheduling (Batch 02 N03).

### S12
- **Title:** Neural Semantic Parsing of Building Regulations for Compliance Checking
- **Authors:** Stefan Fuchs, Johannes Dimyadi, Robert Amor, Michael Witbrock
- **Year:** 2022
- **Source:** IOP Conf. Series: Earth and Environmental Science (CIB / W78 related)
- **DOI / link:** https://doi.org/10.1088/1755-1315/1101/9/092022
- **Why relevant:** Neural semantic parsing of regulations by the Amor/Dimyadi group — the 2022 step before their 2024 LLM paper (Batch 01 D09).

### S13
- **Title:** IABSE Conference / Symposium papers on conceptual design of bridges (multiple years)
- **Authors:** IABSE working commissions (WC3 / WC8)
- **Year:** 2016–2025
- **Source:** IABSE reports / Structural Engineering International
- **DOI / link:** https://iabse.org/Publications
- **Why relevant:** Practitioner conceptual-design case studies (scheme, aesthetics, constructability) under-represented in AutCon-heavy batches.

### S14
- **Title:** EC3 papers on openBIM, IFC 4.3 and infrastructure alignment
- **Authors:** Borrmann, Beetz, Amann, Muhic, et al.
- **Year:** 2019–2025
- **Source:** European Conference on Computing in Construction (EC3)
- **DOI / link:** https://ec-3.org/publications/
- **Why relevant:** The European openBIM/IFC-infra conference home (Batch 01 C03 is one paper; this flags the rest of the series).

### S15
- **Title:** ASCE International Workshop on Computing in Civil Engineering (IWCCE / CRC) ACC and BIM sessions
- **Authors:** Zhang, El-Gohary, Solihin, Lee, Cheng, et al.
- **Year:** 2015–2024
- **Source:** ASCE Computing in Civil Engineering proceedings
- **DOI / link:** https://ascelibrary.org/computing-in-civil-engineering
- **Why relevant:** US counterpart to EG-ICE/EC3 for ACC, NLP and BIM algorithms.

---

## T. Tool layer: IFC Alignment, IDS, mvdXML, OpenSees, CAD/BIM APIs

### T01
- **Title:** ISO 16739-1: Industry Foundation Classes (IFC) for data sharing in the construction and facility management industries
- **Authors:** ISO / buildingSMART
- **Year:** 2018 / IFC 4.3 (ISO 16739-1:2024)
- **Source:** Standard
- **DOI / link:** https://www.iso.org/standard/84123.html
- **Why relevant:** The schema (including IfcAlignment / IfcBridge in 4.3) that every BrIM agent reads and writes.

### T02
- **Title:** buildingSMART Information Delivery Specification (IDS)
- **Authors:** buildingSMART International
- **Year:** 2022–2025
- **Source:** Standard / GitHub
- **DOI / link:** https://technical.buildingsmart.org/projects/information-delivery-specification-ids/
- **Why relevant:** Machine-readable *exchange requirements* — the contract Batch 02 N15 (Ishigaki-IDS-Bench) asks LLMs to generate.

### T03
- **Title:** mvdXML: Specification of a standardized format to define and exchange Model View Definitions with Exchange Requirements and Validation Rules
- **Authors:** buildingSMART / Chipman, Liebich, Weise
- **Year:** 2016 (mvdXML 1.1)
- **Source:** buildingSMART
- **DOI / link:** https://standards.buildingsmart.org/MVD/RELEASE/mvdXML/v1-1/
- **Why relevant:** Pre-IDS executable MVD/validation language — still used in IFC checkers that agents wrap.

### T04
- **Title:** Linking BIM and GIS models in infrastructure by example of IFC and CityGML
- **Authors:** Sebastian Vilgertshofer, Julian Amann, Bruno Willenborg, André Borrmann, Thomas H. Kolbe
- **Year:** 2017
- **Source:** ASCE IWCCE / Journal of Computing in Civil Engineering follow-on
- **DOI / link:** https://doi.org/10.1061/9780784480823.016
- **Why relevant:** Alignment-based BIM–GIS link for infrastructure — required for corridor/bridge placement in preliminary design.

### T05
- **Title:** A refined product model for shield tunnels based on a semantic enrichment approach
- **Authors:** (Borrmann / Hegemann / Theiler tunnel-product-model line)
- **Year:** 2016–2020
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2015.11.008 (Theiler & Borrmann IFC-Tunnel origin, representative)
- **Why relevant:** IFC extension pattern (tunnel) parallel to IFC-Bridge — same alignment-based linear-infra modelling theory.

### T06
- **Title:** IfcOpenShell: open-source IFC geometry engine
- **Authors:** Thomas Krijnen, et al.
- **Year:** 2014–2026 (ongoing)
- **Source:** Open-source software / papers
- **DOI / link:** https://ifcopenshell.org/
- **Why relevant:** The Python/C++ IFC kernel most LLM-IFC agents (BIM-Edit, MCP4IFC) actually call.

### T07
- **Title:** xBIM Toolkit
- **Authors:** Steve Lockley, Ewen Le Coroller, et al.
- **Year:** 2016–2026
- **Source:** Open-source / Automation in Construction application papers
- **DOI / link:** https://docs.xbim.net/
- **Why relevant:** .NET IFC toolkit used in many ACC prototypes (Solihin/Eastman lineage).

### T08
- **Title:** The OpenSees Command Language Manual / OpenSeesPy
- **Authors:** Silvia Mazzoni, Frank McKenna, Michael H. Scott, Gregory L. Fenves / Minjie Zhu
- **Year:** 2006 manual; OpenSeesPy 2018–2024
- **Source:** PEER / SoftwareX
- **DOI / link:** https://doi.org/10.1016/j.softx.2018.07.001 (OpenSeesPy, Zhu et al.)
- **Why relevant:** The analysis back-end of Batch 01 F08–F11 / F25 structural-analysis agents.

### T09
- **Title:** Object-oriented finite element analysis with OpenSees
- **Authors:** Frank McKenna, Michael H. Scott, Gregory L. Fenves
- **Year:** 2010 (framework paper still cited by 2016–2026 automation work)
- **Source:** Journal of Computing in Civil Engineering 24(1)
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000005
- **Why relevant:** Software architecture that makes scripted, agent-driven structural analysis possible.

### T10
- **Title:** ISO 19650 Organization and digitization of information using BIM
- **Authors:** ISO
- **Year:** 2018–2020 (Parts 1–5)
- **Source:** Standard
- **DOI / link:** https://www.iso.org/standard/68078.html
- **Why relevant:** Information-management *process* (OIR/AIR/EIR/PIM/AIM) that IDS/agentic BIM delivery must sit inside.

### T11
- **Title:** BIM Collaboration Format (BCF)
- **Authors:** buildingSMART
- **Year:** 2013–2024 (BCF 2.1 / 3.0)
- **Source:** Standard
- **DOI / link:** https://technical.buildingsmart.org/standards/bcf/
- **Why relevant:** Issue-centric collaboration protocol — the natural output of ACC and design-review agents.

### T12
- **Title:** Alignment-based linear referencing in IFC (IfcAlignment)
- **Authors:** Julian Amann, André Borrmann, et al.
- **Year:** 2015–2018
- **Source:** ITcon / EC3 / buildingSMART
- **DOI / link:** https://www.itcon.org/paper/2016/27
- **Why relevant:** The geometric backbone of IFC-Road/Bridge/Rail — without it parametric BrIM cannot follow a corridor.

### T13
- **Title:** Rhino.Inside.Revit and Grasshopper–BIM interoperability
- **Authors:** Robert McNeel & Associates / Autodesk
- **Year:** 2019–2025
- **Source:** Software / Autodesk University classes
- **DOI / link:** https://www.rhino3d.com/inside/revit/
- **Why relevant:** The live geometry–BIM bridge used by parametric cable-stay/steel-composite workflows (Batch 01 C09 line).

### T14
- **Title:** Dynamo: Visual Programming for Design
- **Authors:** Autodesk
- **Year:** 2016–2025 (primer + research applications)
- **Source:** Software / Autodesk University
- **DOI / link:** https://primer.dynamobim.org/
- **Why relevant:** The VPL that Hamidavi (Batch 02 L03) and countless Chinese “正向设计” Dynamo-Revit bridge scripts use.

---

## U. More ACC, MVD, semantic frames, transformer IE (not in Batches 01–02)

### U01
- **Title:** Automated BIM data validation using IFC and mvdXML
- **Authors:** Pedram Ghannad, Yong-Cheol Lee, Johannes Dimyadi, Wawan Solihin
- **Year:** 2019
- **Source:** Journal of Computing in Civil Engineering / CIB W78
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000833
- **Why relevant:** mvdXML as an executable checker — the pre-LLM validator that LLM-ACC should emit, not replace.

### U02
- **Title:** A simplified relational database schema for transformation of BIM data into a semantic-rich data model
- **Authors:** Wawan Solihin, Charles Eastman, Yong-Cheol Lee, Dong-Hoon Yang
- **Year:** 2017
- **Source:** Automation in Construction 84? / 2017 AutCon
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.12.003
- **Why relevant:** Makes IFC queryable for rule checking without full ifcOWL — a pragmatic ACC datastore.

### U03
- **Title:** Refinement of the Visual Code Checking Language for an automated checking of building information models regarding applicable regulations
- **Authors:** Cornelius Preidel, André Borrmann
- **Year:** 2017
- **Source:** ASCE IWCCE / Computing in Civil Engineering 2017
- **DOI / link:** https://doi.org/10.1061/9780784480823.020
- **Why relevant:** VCCL refinement (Batch 01 D04 was the 2016 ITcon origin) — visual, auditable rules as an alternative to LLM black boxes.

### U04
- **Title:** Semantic frame-based information extraction from utility regulatory documents to support compliance checking
- **Authors:** X. Xu, Hubo Cai
- **Year:** 2021
- **Source:** Advanced Engineering Informatics 47? / Automation in Construction line
- **DOI / link:** https://doi.org/10.1016/j.aei.2020.101163
- **Why relevant:** Frame semantics for *infrastructure* regulations (utilities) — closer to highway/bridge specs than building IBC.

### U05
- **Title:** Integrating natural language processing and spatial reasoning for automated assessment of accessibility
- **Authors:** Shuai Li, Hubo Cai, Vineet R. Kamat
- **Year:** 2016
- **Source:** Automation in Construction 72
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.08.013
- **Why relevant:** NLP + geometric reasoning hybrid — the same split LLM-ACC vs graph-ACC (Batch 01 D12) later rediscovers.

### U06
- **Title:** Capturing normative constraints by use of the semantic mark-up RASE methodology
- **Authors:** Eilif Hjelseth, Nicholas Nisbet
- **Year:** 2011
- **Source:** CIB W78 2011
- **DOI / link:** https://itc.scix.net/paper/w78-2011-Paper-5
- **Why relevant:** RASE (Requirement–Applies–Select–Exception) markup still used to structure codes for ACC and for LLM few-shot schemas.

### U07
- **Title:** BIM-based code-checking for building permit: a case of CORENET and later digital permitting
- **Authors:** (Singapore BCA CORENET e-PlanCheck lineage; Noardo, et al. 2020 digital permitting reviews)
- **Year:** 2016–2020 reviews of the 1990s–2010s system
- **Source:** Automation in Construction / GI_Forum
- **DOI / link:** https://doi.org/10.1016/j.autcon.2019.102979 (Noardo et al., GeoBIM for building permitting, representative)
- **Why relevant:** The only nationally *deployed* ACC system — the adoption benchmark Beach 2020 (Batch 02 I09) measures against.

### U08
- **Title:** Development of an object model for automated compliance checking
- **Authors:** Johannes Dimyadi, Robert Amor
- **Year:** 2013–2015 (ITcon / AutCon object-model papers)
- **Source:** ITcon
- **DOI / link:** https://www.itcon.org/paper/2013/13
- **Why relevant:** Explicit *object model* for regulatory concepts, independent of IFC — needed when bridge codes mention “effective width”, not IfcBeam.

### U09
- **Title:** Automated compliance checking using building information models
- **Authors:** S. Malsane, J. Matthews, S. Lockley, P. E. D. Love, D. Greenwood
- **Year:** 2015
- **Source:** Automation in Construction 49? 2015
- **DOI / link:** https://doi.org/10.1680/mpal.14.00043 (ICE Management, Procurement and Law) / related AutCon
- **Why relevant:** UK practice view of BIM-ACC (COBie, Uniclass) complementary to US/KR/SG lines.

### U10
- **Title:** A transformer-based approach for automated context-aware IFC-regulation semantic information alignment
- **Authors:** Ruichuan Zhang, Nora El-Gohary
- **Year:** 2023
- **Source:** Automation in Construction 145, 104667
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104667
- **Why relevant:** Transformer alignment of IFC concepts to code concepts — the 2023 El-Gohary paper Batch 02 I14 led up to.

### U11
- **Title:** Joint Extraction of Multiple Relations and Entities from Building Code Clauses
- **Authors:** Y. Li, et al.
- **Year:** 2020
- **Source:** Applied Sciences 10(20), 7103
- **DOI / link:** https://doi.org/10.3390/app10207103
- **Why relevant:** Joint NER+RE on code clauses — structured graph output that KG-ACC and LLM-ACC both need.

### U12
- **Title:** Definition of a domain-specific language for Korean building act sentences as an explicit computable form
- **Authors:** Hyunsoo Lee, Jin-Kook Lee, Seokyung Park, Inhan Kim
- **Year:** 2016
- **Source:** ITcon 21
- **DOI / link:** https://www.itcon.org/paper/2016/26
- **Why relevant:** KBimCode as a *DSL* — a compilation target for LLM rule generators (Batch 01 F27 ARCHER).

### U13
- **Title:** Visual language approach to representing KBimCode-based Korea building act sentences for automated rule checking
- **Authors:** H. Kim, J.-K. Lee, J. Shin, J. Choi
- **Year:** 2019
- **Source:** Journal of Computational Design and Engineering / AutCon
- **DOI / link:** https://doi.org/10.1016/j.jcde.2018.12.002
- **Why relevant:** Visual encoding of KBimCode — human-auditable layer between NLP extraction and execution.

### U14
- **Title:** High-level implementable methods for automated building code compliance checking
- **Authors:** (Developments in the Built Environment / 2023 review)
- **Year:** 2023
- **Source:** Developments in the Built Environment
- **DOI / link:** https://doi.org/10.1016/j.dibe.2023.100156
- **Why relevant:** 2023 methods review of implementable ACC (rule, ontology, ML) just as LLMs arrive.

---

## V. More BIM-GIS, product models, and interoperability (infra)

### V01
- **Title:** A state-of-the-art review on the integration of Building Information Modeling (BIM) and Geographic Information Systems (GIS)
- **Authors:** Xin Liu, Xiangyu Wang, Grant Wright, Jack C. P. Cheng, Xiao Li, Rui Liu
- **Year:** 2017
- **Source:** ISPRS International Journal of Geo-Information 6(2), 53
- **DOI / link:** https://doi.org/10.3390/ijgi6020053
- **Why relevant:** BIM–GIS integration review — corridor/bridge projects live at this interface.
- **Cites (approx.):** 400+

### V02
- **Title:** Integration of BIM and GIS in sustainable built environment: A review and bibliometric analysis
- **Authors:** Hao Wang, Yilong Pan, Xiaochun Luo
- **Year:** 2019
- **Source:** Automation in Construction 103, 41–52
- **DOI / link:** https://doi.org/10.1016/j.autcon.2019.03.005
- **Why relevant:** Updates V01 with sustainability/infra emphasis.

### V03
- **Title:** Comparative analysis on the adoption and use of BIM in road infrastructure projects
- **Authors:** Heap-Yih Chong, Robert Lopez, J. Wang, Xiangyu Wang, Zeyu Zhao
- **Year:** 2016
- **Source:** Journal of Management in Engineering 32(6)
- **DOI / link:** https://doi.org/10.1061/(ASCE)ME.1943-5479.0000460
- **Why relevant:** Empirical BIM-for-roads (and by extension bridges) adoption — the industry context of BrIM automation.

### V04
- **Title:** A review of risk management through BIM and BIM-related technologies
- **Authors:** Yang Zou, Arto Kiviniemi, Stephen W. Jones
- **Year:** 2017
- **Source:** Safety Science 97, 88–98
- **DOI / link:** https://doi.org/10.1016/j.ssci.2015.12.027
- **Why relevant:** BIM as a risk-information carrier — relevant to design-risk agents and to ACC of safety-related clauses.

### V05
- **Title:** CityGML and IFC: Going further with openBIM and openGIS
- **Authors:** (OGC / buildingSMART MOU papers; El-Mekawy, Östman, Hijazi 2012; later 2016–2022 GeoBIM)
- **Year:** 2016–2022
- **Source:** ISPRS / Automation in Construction
- **DOI / link:** https://doi.org/10.3390/ijgi5040053 (related) ; Noardo et al. GeoBIM benchmark
- **Why relevant:** Open standards path for *site + structure* models of bridges in a corridor.

### V06
- **Title:** IFC-based information modeling of railway bridges / IFC-Rail
- **Authors:** buildingSMART IFC-Rail project; Chinese railway BIM standards (CRBIM)
- **Year:** 2017–2023
- **Source:** buildingSMART / 铁路BIM标准
- **DOI / link:** https://www.buildingsmart.org/standards/rooms/railway/
- **Why relevant:** Railway-bridge product model — a sibling of IFC-Bridge for HSR viaducts (Batch 01 C08).

### V07
- **Title:** CRBIM / 铁路工程信息模型数据存储标准
- **Authors:** 中国铁路BIM联盟
- **Year:** 2016–2020
- **Source:** Standard (China)
- **DOI / link:** 中国铁路BIM联盟发布
- **Why relevant:** Chinese railway-BIM storage schema used on high-speed-rail bridges — the national counterpart of IFC 4.3.

---

## W. Additional LLM / generative / intelligent-design papers (2022–2026 leftovers)

### W01
- **Title:** Dual generative adversarial networks for automated component layout design of steel frame-brace structures
- **Authors:** Bo Fu, Yu Gao, Wei Wang
- **Year:** 2023
- **Source:** Automation in Construction / Journal of Building Engineering
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104658
- **Why relevant:** Dual-GAN layout of steel braces — another pre-LLM generative *structural-scheme* generator.

### W02
- **Title:** Use of convolutional networks in the conceptual structural design of RC wall-frame buildings
- **Authors:** P. N. Pizarro, L. M. Massone, F. R. Rojas, F. O. Ruiz
- **Year:** 2021
- **Source:** Engineering Structures 239
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2021.112311
- **Why relevant:** CNN as a conceptual RC structural designer — a supervised alternative to StructGAN (Batch 02 L05).

### W03
- **Title:** Learning to simulate and design for structural engineering
- **Authors:** Kai-Hung Chang, Chin-Yi Cheng
- **Year:** 2020
- **Source:** ICML / related Autodesk Research
- **DOI / link:** https://proceedings.mlr.press/v119/chang20c.html
- **Why relevant:** Differentiable simulation+design — a non-LLM path to automated structural design later combinable with agents.

### W04
- **Title:** Intelligent generative design of shear wall layouts based on diffusion models
- **Authors:** Yi Gu, Wenjie Liao, Xinzheng Lu, et al.
- **Year:** 2024–2025
- **Source:** Journal of Building Engineering / Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.jobe.2024.109xxx (Lu-group diffusion line; verify issue)
- **Why relevant:** Diffusion as the generative engine after GAN/GNN — the model an LLM controller (Batch 01 E04) can swap in.

### W05
- **Title:** AutoStruct: Intelligent design system for shear wall building structures
- **Authors:** (Lu / Liao group, 2025–2026)
- **Year:** 2025
- **Source:** Advanced Engineering Informatics
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103900
- **Why relevant:** Packaged intelligent-design *system* (not only a generator) — process sibling of AIstructure-Copilot (Batch 01 E05).

### W06
- **Title:** Physical rule-guided generative adversarial network for automated structural layout design of steel frame-brace structures
- **Authors:** (2024 Engineering Structures / AutCon)
- **Year:** 2024
- **Source:** Engineering Structures
- **DOI / link:** https://www.sciencedirect.com/science/article/abs/pii/S014102962400 (verify full DOI on use)
- **Why relevant:** Hard physics/code rules inside a GAN — a hybrid that verification-driven LLM-MAS (Batch 01 F13) also need.

### W07
- **Title:** Integrating Generative AI in BIM Education: Insights from Classroom Implementation
- **Authors:** Islem Sahraoui, Kinam Kim, Lu Gao, Zia Din, Ahmed Senouci
- **Year:** 2025
- **Source:** arXiv 2507.05296
- **DOI / link:** https://arxiv.org/abs/2507.05296
- **Why relevant:** How the next generation of bridge/BIM designers is being taught to use LLMs — adoption, not only algorithms.

### W08
- **Title:** A Fully Automated DM-BIM-BEM Pipeline Enabling Graph-Based Intelligence, Interoperability, and Performance-Driven Design
- **Authors:** Jun Xiao, Qiong Wang, Yihui Li, Zhexuan Yu, Hao Zhou
- **Year:** 2026
- **Source:** arXiv 2601.16813
- **DOI / link:** https://arxiv.org/abs/2601.16813
- **Why relevant:** Closed design–analysis–energy loop on graphs — a template for bridge design–analysis–code loops.

### W09
- **Title:** Leveraging ChatGPT to Aid Construction Hazard Recognition and Support Safety Education and Training
- **Authors:** S. M. Jamil Uddin, Alex Albert, Abdullah Ovid, Abdullah Alsharef
- **Year:** 2023
- **Source:** Journal of Construction Engineering and Management
- **DOI / link:** https://doi.org/10.1061/JCEMD4.COENG-13423
- **Why relevant:** Empirical ChatGPT for *domain hazard reasoning* — a cautionary analogue for trusting LLMs on structural safety.

### W10
- **Title:** A Text Classification-Based Approach for Evaluating and Enhancing the Machine Interpretability of Building Codes
- **Authors:** Zhe Zheng, et al. (Lin/Lu group)
- **Year:** 2023
- **Source:** arXiv 2309.14374 / subsequent journal
- **DOI / link:** https://arxiv.org/abs/2309.14374
- **Why relevant:** Measures whether a code clause is even *machine-interpretable* — a filter before LLM-ACC.

### W11
- **Title:** Applications of natural language processing in construction
- **Authors:** (AutCon 2022 NLP special-issue review, complementary to Batch 02 J11 Wu)
- **Year:** 2022
- **Source:** Automation in Construction 136, 104169
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104169
- **Why relevant:** 2022 AutCon NLP-in-construction survey covering contracts, specs and codes.

### W12
- **Title:** End-to-end intelligent rapid design method for bridge superstructures (ML/optimization hybrid)
- **Authors:** (Engineering Structures 2026 line; Jia / Liang et al. semantic-scholar hit)
- **Year:** 2026
- **Source:** Engineering Structures
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2026.122090
- **Why relevant:** Rare *bridge-superstructure* end-to-end intelligent design paper (not only buildings) — directly on-theme.

---

## X. Additional Chinese codes, books and journal spines

### X01
- **Title:** 公路钢结构桥梁设计规范 JTG D64-2015（及 D64-01 等细则）
- **Authors:** 交通运输部
- **Year:** 2015–
- **Source:** Standard
- **DOI / link:** JTG D64-2015
- **Why relevant:** Duplicate-check vs Batch 02 O07: this entry keeps the *full steel-bridge family* (D64 + D64-01 composite) as ACC targets.

### X02
- **Title:** 公路斜拉桥设计规范 JTG/T 3365-01-2020? / 公路悬索桥设计规范 JTG/T D65-05
- **Authors:** 交通运输部
- **Year:** 2015–2020
- **Source:** Standard
- **DOI / link:** JTG/T D65-01 / D65-05 series
- **Why relevant:** Type-specific Chinese cable-supported-bridge codes — the clause sets H01–H06 optimizers and LLM checkers must encode.

### X03
- **Title:** 现代桥梁抗风理论与实践
- **Authors:** 项海帆, 葛耀君 等
- **Year:** 2005 / later reprints used in 2016–2026 graduate courses
- **Source:** 人民交通出版社 (book)
- **DOI / link:** ISBN 978-7-114-05680-5
- **Why relevant:** Chinese wind-design *method* book behind Q03/Q16.

### X04
- **Title:** 桥梁施工控制
- **Authors:** 向中富 等
- **Year:** 2011 / later eds.
- **Source:** 人民交通出版社 (book)
- **DOI / link:** ISBN 978-7-114-088xx
- **Why relevant:** Construction-stage *design control* (forward/backward analysis) — the process cable-force optimizers (Batch 02 H05–H06) serve.

### X05
- **Title:** 波形钢腹板预应力混凝土组合箱梁桥
- **Authors:** 刘永健, 陈宝春 相关专著
- **Year:** 2015–2020
- **Source:** 人民交通出版社
- **DOI / link:** CNKI / ISBN
- **Why relevant:** Design method for corrugated-web composite box girders (see P11).

### X06
- **Title:** 节段施工桥梁设计与施工
- **Authors:** 徐栋 等
- **Year:** 2016–2020
- **Source:** 人民交通出版社 / 桥梁建设 papers
- **DOI / link:** CNKI
- **Why relevant:** Segmental *design–construction* coupling, the majority method for long PC viaducts.

### X07
- **Title:** 中国高速铁路桥梁
- **Authors:** 郑健, 孙树礼, 李国平 等
- **Year:** 2016–2022 (中国工程科学 / 铁道学报综述)
- **Source:** 中国工程科学, 铁道学报
- **DOI / link:** CNKI
- **Why relevant:** HSR bridge *standard-span design system* (32 m box, 40 m, 80 m continuous) — highly parametric, ideal for agentic forward design.

### X08
- **Title:** 装配式混凝土桥梁设计与施工技术
- **Authors:** 交通运输部公路局 / 行业指南
- **Year:** 2018–2023
- **Source:** 人民交通出版社 / 公路行业指南
- **DOI / link:** MOT guidelines
- **Why relevant:** Chinese ABC/prefab highway-bridge *design guide* — process sibling of Culmo (P01) and of Batch 01 C10/F15.

---

## Coverage of this batch

| Theme | IDs | n |
|---|---|---|
| ABC / UHPC / prefab / composite systems | P01–P14 | 14 |
| Wind / seismic / fatigue design methods | Q01–Q16 | 16 |
| Substructure / foundations / integral abutments | R01–R08 | 8 |
| Conference corpus (ISARC, EG-ICE, EC3, W78, IABSE, IASS) | S01–S15 | 15 |
| Tool layer (IFC 4.3, IDS, mvdXML, OpenSees, Dynamo) | T01–T14 | 14 |
| Further ACC / RASE / CORENET / transformers | U01–U14 | 14 |
| BIM–GIS / IFC-Rail / CRBIM | V01–V07 | 7 |
| Further generative / LLM leftovers | W01–W12 | 12 |
| Further Chinese codes and method books | X01–X08 | 8 |
| **Total** | | **108 listed** |

Running unique-core total: Batch 01 (~90) + Batch 02 (~114) + Batch 03 (~108) ≈ **312**. Remaining to ~1000: **≈ 690**.

Two spines (this batch):
1. **Traditional:** Culmo ABC; Graybeal UHPC; Xu/Ge wind; Priestley/AASHTO/JTG seismic; JTG 3363 foundations; PCI/ASBI detailed design; IFC 4.3 + IDS as the information contract.
2. **Agentic / computational:** OpenSeesPy as the agent tool; IDS-Bench; transformer IFC–code alignment; diffusion/AutoStruct generators; ChatGPT-for-ACC ISARC 2023.

---

## Suggested Batch 04 expansion axes

1. **Paper-level harvest of ISARC 2016–2025 and EG-ICE 2016–2025** (dozens of 6–10 page items on BIM, NLP, scanning, agents).
2. **IABSE Structural Engineering International** conceptual-design case studies (2016–2026).
3. **Fatigue, fracture, redundancy, load rating, SHM-informed redesign** (Frangopol, Estes, AASHTO Manual for Bridge Evaluation).
4. **Soil–structure interaction, deep foundations, liquefaction, abutment design** journal papers (not only manuals).
5. **More CNKI 2018–2026:** 正向设计 Dynamo/CATIA/Revit, 智能配筋, 自动出图, 规范审查.
6. **Software-specific automation:** CSiBridge API, Midas Open API, RM/TDV, SOFiSTiK Teddy, ANSYS ACT, Abaqus scripting.
7. **Remaining 2025–2026 arXiv** on drawing-to-model, IDS generation, and multi-agent verification.
