# Batch 10 — AEI, JCCE, Buildings, ECAM, ITcon, CACAIE: LLM, ACC, KG, BIM automation

Scope: unique vs. Batches 01–09. Computing-in-civil and informatics journals on LLM-BIM, automated compliance, ontologies, and generative structural design.


## BD. LLM / ACC / agentic BIM (AEI, JCCE, Buildings, ECAM)

### BD01
- **Title:** Generative AI in Architectural Conceptual Design: A Structured Scoping Review of LLMs, Text-to-Image Diffusion Models, Spatial Layout Generation, BIM-AI Coupling, and Human-AI Workflows
- **Authors:** Yingjie Wang, Tianyu Li, Yuexiao Zhao, Bo Zhang, Xiaoran Huang
- **Year:** 2026
- **Source:** Buildings 16(14), 2882
- **DOI / link:** https://doi.org/10.3390/buildings16142882
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BD02
- **Title:** BIM-Based Safety Design Guide Systems Using Rule Checking and LLM Approaches for Preventing Construction Accidents
- **Authors:** Chijoo Lee, Sungil Ham
- **Year:** 2026
- **Source:** Buildings 16(11), 2200
- **DOI / link:** https://doi.org/10.3390/buildings16112200
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.

### BD03
- **Title:** Multi-agent coordination of data-driven and physics-based models for automated design of ultra-high-performance concrete beams
- **Authors:** Jinxin Chen, Yi Bao
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 71, 104297
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.104297
- **Why relevant:** LLM/multi-agent generative structural design with code awareness — precursor to agentic bridge design.
- **Cites (Crossref):** 7

### BD04
- **Title:** A knowledge-informed multi-agent reinforcement learning approach for cost-effective aesthetic facades generative design
- **Authors:** Bolun Wang, Weisheng Lu, Zihan Xu, Hongda An
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104743
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104743
- **Why relevant:** LLM/multi-agent generative structural design with code awareness — precursor to agentic bridge design.
- **Cites (Crossref):** 1

### BD05
- **Title:** An Agentic AI System for Roof Design Compliance Using Computer Vision, Retrieval-Augmented Generation and Large Language Models
- **Authors:** Nawari O. Nawari, Oluwatoyin O. Lawal
- **Year:** 2026
- **Source:** Buildings 16(13), 2637
- **DOI / link:** https://doi.org/10.3390/buildings16132637
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.

### BD06
- **Title:** A large language model-driven framework for automated bridge specification generation and simulation validation
- **Authors:** Shreejan Maharjan, Pang-jo Chun
- **Year:** 2026
- **Source:** Computer-Aided Civil and Infrastructure Engineering 41, 100014
- **DOI / link:** https://doi.org/10.1016/j.cacaie.2026.100014
- **Why relevant:** LLM applied to bridge engineering (specs, drawings, BrIM or design support) — direct thematic fit.
- **Cites (Crossref):** 1

### BD07
- **Title:** A retrieval-augmented method for explainable product ideation: Unifying conceptual design knowledge graph and large language models
- **Authors:** Yangfan Cong, Suihuai Yu, Jianjie Chu, et al.
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104770
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104770
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD08
- **Title:** A Human-in-the-Loop conceptual design framework jointly driven by large language models and knowledge graphs
- **Authors:** Yifan Xu, Jian Xie, Xin Liu, Haoran Cui, Minxia Liu
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104646
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104646
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD09
- **Title:** Empowering building emergency response with large language models and BIM-Based knowledge graphs
- **Authors:** Fangzhou Lin, Mingkai Li, Boyu Wang, et al.
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104703
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104703
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BD10
- **Title:** Large Language Model-Driven Full Lifecycle Architectural Design: A BIM-Based Workflow and Prototype for Apartment Buildings
- **Authors:** John Xianfeng Jiang
- **Year:** 2026
- **Source:** Computing in Civil Engineering 2025
- **DOI / link:** https://doi.org/10.1061/9780784486436.086
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BD11
- **Title:** AI-Driven Automation of Construction Cost Estimation: Integrating BIM with Large Language Models
- **Authors:** Mohamed Abdelsalam, Amr Ashmawi, Phuong H. D. Nguyen
- **Year:** 2026
- **Source:** Buildings 16(3), 485
- **DOI / link:** https://doi.org/10.3390/buildings16030485
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 7

### BD12
- **Title:** AirfoilAgent: Airfoil aerodynamics optimization design via large language model multi-agent collaborations
- **Authors:** Yi Fan, Hao Zhan, Mingxuan Zhang, Baigang Mi
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 71, 104246
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.104246
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 16

### BD13
- **Title:** Real-time safety detection on construction sites using a vision-language and NLP-based model
- **Authors:** S. Sivanraj, D.N.L.S Uduwage, M. Tripathi
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 69, 103889
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103889
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 16

### BD14
- **Title:** Improving construction contract question answering through embedding optimization and semantic chunking in large language models
- **Authors:** Lanqian Zhang, Yan Ning
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 69, 104027
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.104027
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 9

### BD15
- **Title:** A MoE-LLM-based multisensor flexible fusion fault diagnosis method for rotating machinery
- **Authors:** Tantao Lin, Zhijun Ren, Kai Huang, et al.
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 69, 104009
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.104009
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 7

### BD16
- **Title:** An adaptive industrial large language model for mechanical fault diagnosis under variable operating conditions
- **Authors:** Chaojun Xu, Zisheng Wang, Yaqiang Jin, Weihang Nong
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104821
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104821
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 7

### BD17
- **Title:** Physics-informed embodied intelligence in the foundation model era: Advancing robot manipulation for smart manufacturing
- **Authors:** Shufei Li, Cheng Liu, Jianzhuang Zhao, Pai Zheng, Xi Vincent Wang, Lihui Wang
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 71, 104370
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104370
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 6

### BD18
- **Title:** Using an LLM-Powered Framework for Automatic Risk Identification and Mitigation from Past Claims and Supplemental Agreements
- **Authors:** Gongfan Chen, Edward J. Jaselskis, Alyson Tamer, Andrew Folz
- **Year:** 2026
- **Source:** Journal of Computing in Civil Engineering 40(2), 04025151
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-6754
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 4

### BD19
- **Title:** A knowledge-formalization and vision-language-model system for fire emergency decision support
- **Authors:** Jianyuan Tao, Ping Wang, Hanfeng Jiang, Yu Han
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 71, 104409
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104409
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 3

### BD20
- **Title:** Large language model-enhanced graph neural network for quantile prediction of railway track settlement near deep excavations
- **Authors:** Xiaojing Zhou, Yue Pan, Jianjun Qin, Jin-Jian Chen
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 69, 104105
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.104105
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 2

### BD21
- **Title:** TailorAlert: Large Language Model–Based Personalized Alert Generation System for Road Infrastructure Management with Digital Twins
- **Authors:** Peihang Luo, Erika Parn, Soheila Kookalani, Ioannis Brilakis
- **Year:** 2026
- **Source:** Journal of Computing in Civil Engineering 40(2), 04025154
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-7025
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 2

### BD22
- **Title:** RLLM-SS: A knowledge-guided simplex search method integrating large language model and reinforcement learning for injection molding quality control
- **Authors:** Haipeng Zou, Xinyu Li, Yongkuan Yang, et al.
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 71, 104372
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104372
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 2

### BD23
- **Title:** Intelligent defect‑detection framework integrating a modified YOLO algorithm, a domain knowledge graph, and RAG‑enabled large language model
- **Authors:** Jr-Fong Dang, Li-Na Wang, Tzu-Li Chen
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104709
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104709
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD24
- **Title:** LLMARL: An explainable reasoning model for aircraft fault knowledge graphs via large language models assisted reinforcement learning
- **Authors:** Xiangzhen Meng, Xilang Tang, Jinyu Wu, Guo Chi, Xiaoyue Xie
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 76, 104890
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104890
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD25
- **Title:** TM-RAG: A Tree-Mapped Retrieval-Augmented generation framework for construction claim report generation
- **Authors:** Wentao Zhu, Xiao Li, Liang Wang, Juan Wang, Yinyi Wei
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 69, 104092
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.104092
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD26
- **Title:** LightLLM4FDD: Domain-specific lightweight large language models for fault detection and diagnosis in building HVAC systems
- **Authors:** Jian Zhang, Feng (Eva) Wang, Chaobo Zhang, Yizhi Liu, Jie Lu, Yang Zhao
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104794
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104794
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD27
- **Title:** RAMASC: A retrieval-augmented multi-agent framework for automated structural calculation
- **Authors:** Kichang Choi, Minwoo Jeong, Taegeon Kim, Seokhwan Kim, Seungwon Baek, Hongjo Kim
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104698
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104698
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD28
- **Title:** Towards large language model for cognitive industrial mixed reality: A survey
- **Authors:** Wei Fang, Yingfen Xu, Tienong Zhang, Yiwei Wang, Lianyu Zheng
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 71, 104276
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.104276
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD29
- **Title:** Orchestrating large language models with an expert-driven knowledge graph for causal reasoning and management of construction project risks
- **Authors:** Nan Liu, Xinping Hu, Yang Miang Goh, David K.H. Chua
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 75, 104865
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104865
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD30
- **Title:** A knowledge system for aeroengine: an LLM-based graph construction framework and a query-context-aware graph transformer model for knowledge reasoning
- **Authors:** Boyan Shen, Xishuang Jing, Fubao Xie, et al.
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 74, 104650
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104650
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD31
- **Title:** Highly personalized electricity pricing plan selection empowered by knowledge graph-enhanced large language models
- **Authors:** Qingquan Luo, Minhang Liang, Tao Yu, et al.
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 76, 105014
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.105014
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD32
- **Title:** A Multiagent Large Language Model–Based System for Early-Stage Building Layout Planning
- **Authors:** Haolan Zhang, Ruichuan Zhang
- **Year:** 2026
- **Source:** Journal of Computing in Civil Engineering 40(6), 04026095
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-7723
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD33
- **Title:** Sample-Efficient Robot Skill Learning for Construction Tasks: Benchmarking Hierarchical Reinforcement Learning and Vision-Language-Action Model
- **Authors:** Zhaofeng Hu, Hongrui Yu, Vaidhyanathan Chandramouli, Ci-Jyun Liang
- **Year:** 2026
- **Source:** Journal of Computing in Civil Engineering 40(6), 04026098
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-7696
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD34
- **Title:** Using Large Language Models for Systematic Failure Model Identification in Levee Infrastructure
- **Authors:** Aggrey Muhebwa, Khalid K. Osman
- **Year:** 2026
- **Source:** Computing in Civil Engineering 2025
- **DOI / link:** https://doi.org/10.1061/9780784486436.055
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD35
- **Title:** ArchPlanVQA: Benchmark and Comprehensive Evaluation of Vision-Language Models for Understanding Architectural Floor Plan CAD Drawings
- **Authors:** Pengyang Li, Hainan Chen, Zhuang Zheng, Juntao He, Hai Yang
- **Year:** 2026
- **Source:** Journal of Computing in Civil Engineering 40(5), 04026060
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-7571
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD36
- **Title:** Noise-Invariant Agentic Human–Robot Interaction GenAI System Using a Dual-Encoder Contrastive ASR Architecture and VLMs for Robot Control and Navigation in Acoustically Challenging Jobsites
- **Authors:** Oscar Poudel, Rayan H. Assaad, Mohamad Awada
- **Year:** 2026
- **Source:** Journal of Computing in Civil Engineering 40(6), 04026088
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-7372
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD37
- **Title:** LLM-Driven Generative Agents for Simulating Occupant Feedback in Built Environments
- **Authors:** Min Jae Lee, Ruichuan Zhang
- **Year:** 2026
- **Source:** Journal of Computing in Civil Engineering 40(4), 04026045
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-7365
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD38
- **Title:** RIS-LLM: Reasoning-informed semantic modeling of electricity market price dynamics
- **Authors:** Ming Huang, Jieming Ma, Yuxuan Luo, et al.
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 76, 104949
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104949
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD39
- **Title:** Augmenting LLM reasoning with semantic web for knowledge sharing in off-site construction
- **Authors:** Zhen Zhang, Yang Zou, Johannes Dimyadi, Brian H.W. Guo, Lixin Jiang
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 76, 105152
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.105152
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD40
- **Title:** Hierarchical online energy management for off-road hybrid electric vehicles: integrating real-time planning with multi-agent expert knowledge
- **Authors:** Xiaokang Ma, Hui Liu, Lijin Han, Ningkang Yang, Changle Xiang
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 73, 104547
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104547
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD41
- **Title:** Domain textual knowledge-enhanced few-shot utility tunnel video anomaly detection with multimodal large language models
- **Authors:** Baijian Yin, Shuai Wang, Xiaolei Zhou, Hai Wang
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 73, 104594
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104594
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD42
- **Title:** PrefAnalyst: An LLM-based multi-agent system for customer preference identification and recommendation in the apparel industry
- **Authors:** Yuan Cheng, Hui Li, Zhiheng Zhao, George Q. Huang
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 76, 104888
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104888
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD43
- **Title:** Ethical assessment of large language model-generated advisory text on designing the built environment for health
- **Authors:** Mohammad Javad Koohsari, Becky P.Y. Loo, Jing Zhao, et al.
- **Year:** 2026
- **Source:** Developments in the Built Environment 27, 101007
- **DOI / link:** https://doi.org/10.1016/j.dibe.2026.101007
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD44
- **Title:** The Beginning, Not the End: Revisiting Automated Compliance Checking for BIM-Based Design Adaptation
- **Authors:** Jiabin Wu, Stefan Fuchs, Tanya Bloch, André Borrmann
- **Year:** 2026
- **Source:** Computing in Civil Engineering 2025
- **DOI / link:** https://doi.org/10.1061/9780784486436.070
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 1

### BD45
- **Title:** Toward fine-grained construction safety inspection via vision-language grounded reasoning
- **Authors:** Xianrui Luo, Chengqian Li, Botao Gu, Dongping Fang
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 76, 104870
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104870
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD46
- **Title:** Leveraging Large Language Models to Assist Bridge Element Visual Inspections
- **Authors:** Onur Kaan Topçu, Chenxi Yuan, H. Felix Lee
- **Year:** 2025
- **Source:** Computing in Civil Engineering 2024
- **DOI / link:** https://doi.org/10.1061/9780784486115.013
- **Why relevant:** LLM applied to bridge engineering (specs, drawings, BrIM or design support) — direct thematic fit.

### BD47
- **Title:** Generative AI, Large Language Models, and ChatGPT in Construction Education, Training, and Practice
- **Authors:** Mostafa Babaeian Jelodar
- **Year:** 2025
- **Source:** Buildings 15(6), 933
- **DOI / link:** https://doi.org/10.3390/buildings15060933
- **Why relevant:** LLM/multi-agent generative structural design with code awareness — precursor to agentic bridge design.
- **Cites (Crossref):** 30

### BD48
- **Title:** Large Language Model-Based Reasoning for Hierarchical Structure of Scan-to-BIM Objects under IFC Standard
- **Authors:** Jinwu Xiao, Jiashu Hu, Hyuna Kang, Tahoon Hong, Kyubyung Kang
- **Year:** 2025
- **Source:** Computing in Civil Engineering 2024
- **DOI / link:** https://doi.org/10.1061/9780784486122.067
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BD49
- **Title:** Automated Scan-to-BIM with Point Cloud Instance Segmentation and Large Language Model Knowledge Enhancement
- **Authors:** Pengkun Liu, Jiepeng Liu, Hongxu Wang, Tianze Chen, Dongsheng Li
- **Year:** 2025
- **Source:** Computing in Civil Engineering 2024
- **DOI / link:** https://doi.org/10.1061/9780784486122.072
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BD50
- **Title:** Automated Image-to-BIM Using Neural Radiance Fields and Vision-Language Semantic Modeling
- **Authors:** Mohammad H. Mehraban, Shayan Mirzabeigi, Mudan Wang, Rui Liu, Samad M. E. Sepasgozar
- **Year:** 2025
- **Source:** Buildings 15(24), 4549
- **DOI / link:** https://doi.org/10.3390/buildings15244549
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 2

### BD51
- **Title:** Empowering LLMs by hybrid retrieval-augmented generation for domain-centric Q&A in smart manufacturing
- **Authors:** Yuwei Wan, Zheyuan Chen, Ying Liu, Chong Chen, Michael Packianather
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 65, 103212
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103212
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 93

### BD52
- **Title:** Large language model assisted fine-grained knowledge graph construction for robotic fault diagnosis
- **Authors:** Xingming Liao, Chong Chen, Zhuowei Wang, Ying Liu, Tao Wang, Lianglun Cheng
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 65, 103134
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103134
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 70

### BD53
- **Title:** An advanced retrieval-augmented generation system for manufacturing quality control
- **Authors:** José Antonio Heredia Álvaro, Javier González Barreda
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 64, 103007
- **DOI / link:** https://doi.org/10.1016/j.aei.2024.103007
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 64

### BD54
- **Title:** LLM-MANUF: An integrated framework of Fine-Tuning large language models for intelligent Decision-Making in manufacturing
- **Authors:** Kaze Du, Bo Yang, Keqiang Xie, et al.
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 65, 103263
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103263
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 60

### BD55
- **Title:** A large language model-enabled machining process knowledge graph construction method for intelligent process planning
- **Authors:** Qingfeng Xu, Fei Qiu, Guanghui Zhou, et al.
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 65, 103244
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103244
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 41

### BD56
- **Title:** Leveraging large language models for Human-Machine collaborative troubleshooting of complex industrial equipment faults
- **Authors:** Sijie Wen, Fei Li, Weibin Zhuang, et al.
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 65, 103235
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103235
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 41

### BD57
- **Title:** Hybrid large language model approach for prompt and sensitive defect management: A comparative analysis of hybrid, non-hybrid, and GraphRAG approaches
- **Authors:** Kahyun Jeon, Ghang Lee
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 64, 103076
- **DOI / link:** https://doi.org/10.1016/j.aei.2024.103076
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 33

### BD58
- **Title:** A knowledge graph-enhanced large language model for question answering of hydraulic structure safety management
- **Authors:** Dongliang Zhang, Gang Ma, Tongming Qu, Xudong Wang, Wei Zhou, Xiaomao Wang
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 66, 103468
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103468
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 32

### BD59
- **Title:** LLMOA: A novel large language model assisted hyper-heuristic optimization algorithm
- **Authors:** Rui Zhong, Abdelazim G. Hussien, Jun Yu, Masaharu Munetomo
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 64, 103042
- **DOI / link:** https://doi.org/10.1016/j.aei.2024.103042
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 29

### BD60
- **Title:** OmEGa(<mml:math xmlns:mml="http://www.w3.org/1998/Math/MathML" altimg="si1.svg" display="inline" id="d1e2076"><mml:mi>Ω</mml:mi></mml:math>): Ontology-based information extraction framework for constructing task-centric knowledge graph from manufacturing documents with large language model
- **Authors:** Midan Shim, Hyojun Choi, Heeyeon Koo, Kaehyun Um, Kyong-Ho Lee, Sanghyun Lee
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 64, 103001
- **DOI / link:** https://doi.org/10.1016/j.aei.2024.103001
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 26

### BD61
- **Title:** An LLM-based knowledge and function-augmented approach for optimal design of remanufacturing process
- **Authors:** Haiyang Zhang, Wei Yan, Huicong Hu, et al.
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 65, 103206
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103206
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 25

### BD62
- **Title:** A stepwise intelligence generative method for structured maintenance guidance documents based on knowledge graph augmented LLM
- **Authors:** Fangcheng Shi, Liang Chen, Moshi Zhou, Yue Zhao, Yu Zheng
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 67, 103523
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103523
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 18

### BD63
- **Title:** Large language Models-empowered automatic knowledge graph development based on multi-modal data for building health resilience
- **Authors:** Tianlong Shan, Fan Zhang, Albert P.C. Chan, Shiyao Zhu, Kaijian Li
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 68, 103655
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103655
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 15

### BD64
- **Title:** Fine-tuning large language models with contrastive margin ranking loss for selective entity matching in product data integration
- **Authors:** Qian Ruan, Dachuan Shi, Thomas Bauernhansl
- **Year:** 2025
- **Source:** Advanced Engineering Informatics 67, 103538
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.103538
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD65
- **Title:** Construction Behavior Safety Risk Identification Based on Knowledge Graph and Large Language Model
- **Authors:** Yongshuang Li, Feng Xu, Zhipeng Zhang, Xinyu Mei
- **Year:** 2025
- **Source:** Computing in Civil Engineering 2024
- **DOI / link:** https://doi.org/10.1061/9780784486139.096
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BD66
- **Title:** Integrated vision language and foundation model for automated estimation of building lowest floor elevation
- **Authors:** Yu‐Hsuan Ho, Longxiang Li, Ali Mostafavi
- **Year:** 2025
- **Source:** Computer-Aided Civil and Infrastructure Engineering 40(1), 75-90
- **DOI / link:** https://doi.org/10.1111/mice.13310
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 17

### BD67
- **Title:** Development of an Automated Construction Contract Review Framework Using Large Language Model and Domain Knowledge
- **Authors:** Eu Wang Kim, Yeon Ju Shin, Kyong Ju Kim, Sehoon Kwon
- **Year:** 2025
- **Source:** Buildings 15(6), 923
- **DOI / link:** https://doi.org/10.3390/buildings15060923
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 11

### BD68
- **Title:** Image‐based large language model approach to road pavement monitoring
- **Authors:** Shuoshuo Xu, Kai Zhao, James Loney, Zili Li, Andrea Visentin
- **Year:** 2025
- **Source:** Computer-Aided Civil and Infrastructure Engineering 40(26), 4448-4464
- **DOI / link:** https://doi.org/10.1111/mice.70075
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 10

### BD69
- **Title:** Vision language model (VLM)-enabled street view analytics: a systematic literature review
- **Authors:** Ziyu Peng, Weisheng Lu, Hongda An, et al.
- **Year:** 2025
- **Source:** Engineering, Construction and Architectural Management
- **DOI / link:** https://doi.org/10.1108/ecam-07-2025-1133
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### BD70
- **Title:** Automated Building Information Modeling Compliance Check through a Large Language Model Combined with Deep Learning and Ontology
- **Authors:** Nanjiang Chen, Xuhui Lin, Hai Jiang, Yi An
- **Year:** 2024
- **Source:** Buildings 14(7), 1983
- **DOI / link:** https://doi.org/10.3390/buildings14071983
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.
- **Cites (Crossref):** 78

### BD71
- **Title:** VR rehabilitation system evaluator: A fNIRS-based and LLM-enabled evaluation paradigm for Mild Cognitive Impairment
- **Authors:** Yanjie Zhang, Fan Li, Danni Chang
- **Year:** 2024
- **Source:** Advanced Engineering Informatics 62, 102734
- **DOI / link:** https://doi.org/10.1016/j.aei.2024.102734
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 7

### BD72
- **Title:** Large language model-based code generation for the control of construction assembly robots: A hierarchical generation approach
- **Authors:** Hanbin Luo, Jianxin Wu, Jiajing Liu, Maxwell Fordjour Antwi-Afari
- **Year:** 2024
- **Source:** Developments in the Built Environment 19, 100488
- **DOI / link:** https://doi.org/10.1016/j.dibe.2024.100488
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 26

### BD73
- **Title:** Clustering Information Types for Semantic Enrichment of Building Information Models to Support Automated Code Compliance Checking
- **Authors:** Tanya Bloch, Rafael Sacks
- **Year:** 2020
- **Source:** Journal of Computing in Civil Engineering 34(6), 04020040
- **DOI / link:** https://doi.org/10.1061/(asce)cp.1943-5487.0000922
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 66


## BE. BIM query, KG, parametric and generative design (same venues)

### BE01
- **Title:** Generative AI Methodology for the Conceptual Topology Design of Bridges from Topography Images
- **Authors:** Aswin Lal, Chongjie Kang, Baris Özcan, Jörg Blankenbach, Steffen Marx
- **Year:** 2026
- **Source:** Journal of Computing in Civil Engineering 40(6), 04026089
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-7429
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.

### BE02
- **Title:** A generative design framework for automated feasible design generation and decision-making in the early design process for additive manufacturing
- **Authors:** Jungyoon Moon, Kijung Park, Sang-in Park, David W. Rosen
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 72, 104526
- **DOI / link:** https://doi.org/10.1016/j.aei.2026.104526
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 2

### BE03
- **Title:** BIM-LogNet clustering for automated design and drawing productivity measurement
- **Authors:** Yije Kim, Ghang Lee, Ingeon Park, Sangyoon Chin
- **Year:** 2026
- **Source:** Advanced Engineering Informatics 71, 104279
- **DOI / link:** https://doi.org/10.1016/j.aei.2025.104279
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.
- **Cites (Crossref):** 1

### BE04
- **Title:** Semiautomatic IFC-Based BIM Reconstruction for As-Designed Bridges from 2D Plans Leveraging Semantic Segmentation and Enrichment
- **Authors:** Hang Li, Jiansong Zhang
- **Year:** 2025
- **Source:** Journal of Computing in Civil Engineering 39(6), 04025088
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-5931
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.
- **Cites (Crossref):** 2

### BE05
- **Title:** BIM-Based Automated Design Framework for Pavement Structures Considering Economy and Sustainability
- **Authors:** Tao Han, Chengjia Han, Tao Ma
- **Year:** 2025
- **Source:** Journal of Computing in Civil Engineering 39(5), 04025075
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-5929
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.

### BE06
- **Title:** From Scans to Parametric BIM: An Enhanced Framework Using Synthetic Data Augmentation and Parametric Modeling for Highway Bridges
- **Authors:** Liu Yang, Yi-Chun Lin, Hubo Cai, Ayman Habib
- **Year:** 2024
- **Source:** Journal of Computing in Civil Engineering 38(3), 04024008
- **DOI / link:** https://doi.org/10.1061/jccee5.cpeng-5640
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 26

### BE07
- **Title:** Application of Parametric Modeling Techniques for Automated Detailing of Exterior Finishes in Architectural BIM Models: A South Korean Case Study
- **Authors:** Sihyun Kim, Min Htet Myint, Youngsu Yu, Wonbok Lee, Tae Wan Kim, Bonsang Koo
- **Year:** 2024
- **Source:** Buildings 14(12), 4013
- **DOI / link:** https://doi.org/10.3390/buildings14124013
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 2

### BE08
- **Title:** Embodied carbon of BIM bridge models according to the application of off-site prefabrication: Precast concrete applied to superstructure and substructure
- **Authors:** Hyunsik Kim, Seungjun Roh, Jeonghwan Kim
- **Year:** 2024
- **Source:** Developments in the Built Environment 20, 100550
- **DOI / link:** https://doi.org/10.1016/j.dibe.2024.100550
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 9

### BE09
- **Title:** Automated generative design and prefabrication of precast buildings using integrated BIM and graph convolutional neural network
- **Authors:** Kexin Li, Vincent J.L. Gan, Mingkai Li, Maggie Y. Gao, Robert L.K. Tiong, Yaowen Yang
- **Year:** 2024
- **Source:** Developments in the Built Environment 18, 100418
- **DOI / link:** https://doi.org/10.1016/j.dibe.2024.100418
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 30

### BE10
- **Title:** Erratum for “Framework for Developing IFC-Based 3D Documentation from 2D Bridge Drawings” by Temitope Akanbi and Jiansong Zhang
- **Authors:** Temitope Akanbi, Jiansong Zhang
- **Year:** 2022
- **Source:** Journal of Computing in Civil Engineering 36(4), 08222001
- **DOI / link:** https://doi.org/10.1061/(asce)cp.1943-5487.0001033
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.
- **Cites (Crossref):** 1

### BE11
- **Title:** Generative BIM workspace for AEC conceptual design automation: prototype development
- **Authors:** Sepehr Abrishami, Jack Goulding, Farzad Rahimian
- **Year:** 2020
- **Source:** Engineering, Construction and Architectural Management 28(2), 482-509
- **DOI / link:** https://doi.org/10.1108/ecam-04-2020-0256
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 48

### BE12
- **Title:** Automatic As-Built BIM Creation of Precast Concrete Bridge Deck Panels Using Laser Scan Data
- **Authors:** Qian Wang, Hoon Sohn, Jack C. P. Cheng
- **Year:** 2018
- **Source:** Journal of Computing in Civil Engineering 32(3), 04018011
- **DOI / link:** https://doi.org/10.1061/(asce)cp.1943-5487.0000754
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 75


---

**This batch listed:** 85 unique named items (deduped vs Batches 01–07 and earlier 08+).
