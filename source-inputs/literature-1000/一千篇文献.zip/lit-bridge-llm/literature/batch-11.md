# Batch 11 — ICE Bridge Engineering, IABSE SEI, Engineering Structures, SMO, JCSR, Structural Concrete

Scope: unique vs. Batches 01–10. Traditional and computational *bridge design process* papers: conceptual case studies, Eurocode/AASHTO design notes, topology/size optimization, UHPC/composite detailing.


## BF. ICE *Bridge Engineering* and IABSE *Structural Engineering International*

### BF01
- **Title:** Technical improvements in the second-generation Eurocodes for steel and concrete bridge design
- **Authors:** Chris R. Hendy, Chandan Gowda
- **Year:** 2026
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 179(3), 257-278
- **DOI / link:** https://doi.org/10.1680/jbren.24.00055
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BF02
- **Title:** Computational fluid dynamics as an early aerodynamic design tool for a typical bluff bridge deck
- **Authors:** Marko Ðuranović, Anthony Dempsey, Craig Meskell
- **Year:** 2026
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 179(2), 127-152
- **DOI / link:** https://doi.org/10.1680/jbren.24.00023
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BF03
- **Title:** Conceptual Design from Precedents and Holistic Performance Assessment of Free-edge Gridshells
- **Authors:** Sara Bordigoni Pistorello, Fiammetta Venuti, Lorenzo Raffaele
- **Year:** 2026
- **Source:** Structural Engineering International
- **DOI / link:** https://doi.org/10.1080/10168664.2025.2584748
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BF04
- **Title:** On the use of aluminium alloys in sustainable design, construction and rehabilitation of bridges
- **Authors:** Evangelia Georgantzia, Mohammad Mehdi Kashani
- **Year:** 2025
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 178(3), 229-241
- **DOI / link:** https://doi.org/10.1680/jbren.23.00018
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 5

### BF05
- **Title:** Design of Through Arch-beam Composite Landscape Bridge
- **Authors:** Jie Li, Zhongzheng Fu, Bo Zhang
- **Year:** 2025
- **Source:** Structural Engineering International
- **DOI / link:** https://doi.org/10.1080/10168664.2025.2551911
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BF06
- **Title:** Design of Steel-Concrete Hybrid Balanced Arch Bridge - The Kouchigawa Bridge
- **Authors:** Izumi Tanaka, Keiji Yamazaki
- **Year:** 2025
- **Source:** Structural Engineering International 35(1), 15-17
- **DOI / link:** https://doi.org/10.1080/10168664.2024.2437514
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BF07
- **Title:** Planning and design of the Gordie Howe International Bridge, North America
- **Authors:** Leslie A. Martin, Zaher Yousif, Bruce L. Campbell, Martin Furrer, Matt Chynoweth
- **Year:** 2023
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 176(4), 233-249
- **DOI / link:** https://doi.org/10.1680/jbren.21.00057
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 3

### BF08
- **Title:** Feasibility study, design and construction of the 27 km long Temburong Bridge, Brunei
- **Authors:** Sammy Yip, Naeem Hussain
- **Year:** 2023
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 176(3), 154-162
- **DOI / link:** https://doi.org/10.1680/jbren.22.00003
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 2

### BF09
- **Title:** Feasibility study and preliminary design of Bataan–Cavite interlink bridge, Philippines
- **Authors:** Sammy Yip, Naeem Hussain
- **Year:** 2023
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 176(3), 215-223
- **DOI / link:** https://doi.org/10.1680/jbren.22.00004
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BF10
- **Title:** Design of the River Dee Bridge, Aberdeen, UK
- **Authors:** Jessica Sandberg, Louisa Man, David A. Smith
- **Year:** 2022
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 175(2), 73-83
- **DOI / link:** https://doi.org/10.1680/jbren.21.00021
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 3

### BF11
- **Title:** Conceptual Design of the Pedestrian Bridge
- **Authors:** Pengzhen Lu, Yutao Zhou, Qun Lu, Jiahao Wang, Qingtian Shi, Dengguo Li
- **Year:** 2022
- **Source:** Structural Engineering International 32(4), 470-483
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1911610
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 8

### BF12
- **Title:** Form Finding and Structural Optimisation of Tensile Cable Dome Using Parametric Modelling Tools
- **Authors:** Iria Heitel, Feng Fu
- **Year:** 2021
- **Source:** Structural Engineering International 31(2), 271-280
- **DOI / link:** https://doi.org/10.1080/10168664.2020.1750937
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 7

### BF13
- **Title:** The Conceptual Design of Bridges: Form Finding and Aesthetics
- **Authors:** V. N. Heggade
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 622-637
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1899780
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 12

### BF14
- **Title:** Approach to Robust and Elegant Bridge Design
- **Authors:** Peter Tanner, Ramon Hingorani
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 638-648
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1938345
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 10

### BF15
- **Title:** Aesthetics Innovation and Practice of Urban Bridge Design
- **Authors:** Zhenyong Han
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 543-549
- **DOI / link:** https://doi.org/10.1080/10168664.2020.1848368
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 8

### BF16
- **Title:** Conceptual Design of Cable-Supported Bridges with Road and Railway Traffic
- **Authors:** Yingliang Wang, Wanmin Ren, Bing Han, Martin Romberg
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 488-497
- **DOI / link:** https://doi.org/10.1080/10168664.2020.1856019
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 6

### BF17
- **Title:** Koege Nord Station—Conceptual, Aesthetic and Detailed Design of a Futuristic Pedestrian Bridge and Transportation Hub
- **Authors:** Jens Thorup Laursen, Paw Lee Sørensen
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 523-526
- **DOI / link:** https://doi.org/10.1080/10168664.2020.1835451
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 4

### BF18
- **Title:** Less and Better. Elements to Achieve Excellence in Bridge Design
- **Authors:** Juan A. Sobrino
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 610-613
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1968775
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 4

### BF19
- **Title:** Introduction: Special Issue on Bridge Conceptual and Aesthetic Design
- **Authors:** Dongzhou Huang, Ignacio Paya-Zaforteza
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 467-467
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1945802
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 3

### BF20
- **Title:** Minimising Future Surprises at Bridge Conceptual and Aesthetic Design
- **Authors:** David Williams
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 568-576
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1884506
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BF21
- **Title:** Bridge Design, a Creative Process
- **Authors:** Roberto Revilla, Francisco Cambronero, Pablo Cembrero, Patricia Olazábal
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 614-621
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1885322
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BF22
- **Title:** Site, Type, Drawing: Three Keys to Creative Bridge Design
- **Authors:** Jorge Bernabéu Larena, Alejandro Bernabéu Larena
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 654-663
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1948378
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BF23
- **Title:** Bridge Design, Perception, and Emotion
- **Authors:** Héctor Beade-Pereda
- **Year:** 2021
- **Source:** Structural Engineering International 31(4), 668-678
- **DOI / link:** https://doi.org/10.1080/10168664.2021.1936351
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BF24
- **Title:** The integral bridge design concept for the third runway at Heathrow, UK
- **Authors:** Jessica Sandberg, Luca Magnino, Paul Nowak, Michael Wiechecki, Indrasenan Thusyanthan
- **Year:** 2020
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 173(2), 112-120
- **DOI / link:** https://doi.org/10.1680/jbren.19.00044
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 13

### BF25
- **Title:** Definition of a Simplified Design Procedure of Seismic Isolation Systems for Bridges
- **Authors:** Marco Furinghetti, Alberto Pavese
- **Year:** 2020
- **Source:** Structural Engineering International 30(3), 381-386
- **DOI / link:** https://doi.org/10.1080/10168664.2020.1775535
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 21

### BF26
- **Title:** Bridge design for inspection and maintenance – a UK and US perspective
- **Authors:** Barry R. Colford, Shane R. Beabes, Mark J. Bulmer
- **Year:** 2019
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 172(4), 246-256
- **DOI / link:** https://doi.org/10.1680/jbren.18.00061
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 7

### BF27
- **Title:** Behaviour and design of three-tower, self-anchored suspension bridge with a concrete girder
- **Authors:** Shengshan Pan, Yao Cui, Zhe Zhang, Weizhi Zhu
- **Year:** 2019
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 172(3), 190-203
- **DOI / link:** https://doi.org/10.1680/jbren.18.00023
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 3

### BF28
- **Title:** Queensferry Crossing, UK: cable-stayed bridge deck and cables – design and construction
- **Authors:** Peter Curran, Alan Platt, Antonio Vasquez, Paul Baralos
- **Year:** 2019
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 172(2), 135-144
- **DOI / link:** https://doi.org/10.1680/jbren.18.00016
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 7

### BF29
- **Title:** Criteria and guidance for the design of integral bridges
- **Authors:** Moustafa Al-Ani, Alexei Murashev, Alessandro Palermo, et al.
- **Year:** 2018
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 171(3), 143-154
- **DOI / link:** https://doi.org/10.1680/jbren.17.00014
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 8

### BF30
- **Title:** Steel–concrete hybrid bridge decks: rational design models for connection regions
- **Authors:** Pedro M. Esteves, João F. Almeida, José J. Oliveira Pedro
- **Year:** 2018
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 171(4), 252-266
- **DOI / link:** https://doi.org/10.1680/jbren.16.00014
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 3

### BF31
- **Title:** Design of the new pedestrian and cycleway bridge in Strabane, Northern Ireland
- **Authors:** Craig Giaccio, Juan Martin Caracuel, Danny Boothman
- **Year:** 2017
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 170(3), 181-191
- **DOI / link:** https://doi.org/10.1680/jbren.16.00031
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BF32
- **Title:** Management of structural monitoring data of bridges using BIM
- **Authors:** Juan M. Davila Delgado, Liam J. Butler, Niamh Gibbons, Ioannis Brilakis, Mohammed Z. E. B. Elshafie, Campbell Middleton
- **Year:** 2017
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 170(3), 204-218
- **DOI / link:** https://doi.org/10.1680/jbren.16.00013
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.
- **Cites (Crossref):** 47

### BF33
- **Title:** Structural analysis and design of a multispan network arch bridge
- **Authors:** Alessio Pipinato
- **Year:** 2016
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 169(1), 54-66
- **DOI / link:** https://doi.org/10.1680/jbren.14.00013
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 5

### BF34
- **Title:** Planning, design and construction of the Second Penang Bridge
- **Authors:** David Collings
- **Year:** 2016
- **Source:** Proceedings of the Institution of Civil Engineers - Bridge Engineering 169(4), 260-270
- **DOI / link:** https://doi.org/10.1680/bren.14.00037
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 4


## BG. Engineering Structures / SMO / JCSR / Structural Concrete — optimization and type-specific design

### BG01
- **Title:** Vision language models for bridge inspections: A review of applications in image‐based damage documentation
- **Authors:** Rona Firdes Çelik, Ulas Bagci, Sylvia Kessler
- **Year:** 2026
- **Source:** Structural Concrete
- **DOI / link:** https://doi.org/10.1002/suco.70702
- **Why relevant:** LLM applied to bridge engineering (specs, drawings, BrIM or design support) — direct thematic fit.

### BG02
- **Title:** Quantitative evaluation and design of train running safety on bridge based on bridge-track-train damage transfer characterization
- **Authors:** Jian Yu, Yulin Feng, Shusheng Chen, Lizhong Jiang, Wangbao Zhou
- **Year:** 2026
- **Source:** Engineering Structures 355, 122433
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2026.122433
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BG03
- **Title:** Multi-objective optimisation design of inspection vehicle for indirect bridge measurements
- **Authors:** Jinsong Zhu, Teng Shi, Shuai Zhou, Bin Zhou
- **Year:** 2026
- **Source:** Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1080/15732479.2026.2631798
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BG04
- **Title:** Peak and residual displacement-based design method for enhancing seismic performance of bridge bents retrofitted with BRBs
- **Authors:** Yan Shi, Qianzhan Cheng, Jianping Han, Jixin Wang, Yu Ding
- **Year:** 2026
- **Source:** Engineering Structures 366, 123505
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2026.123505
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BG05
- **Title:** Optimised design of rocking rigid-frame bridge piers based on response surface methodology
- **Authors:** Qingtao Zheng, Yuxin Liu, Yang Lyu, Fangfang Li
- **Year:** 2026
- **Source:** Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1080/15732479.2026.2617181
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BG06
- **Title:** Parametric BIM-based environmental and economic performance of high-strength steel in high-rise buildings
- **Authors:** Mudasir Hussain, Zhongnan Ye, Shu-Chien Hsu
- **Year:** 2026
- **Source:** Journal of Constructional Steel Research 237, 110086
- **DOI / link:** https://doi.org/10.1016/j.jcsr.2025.110086
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.
- **Cites (Crossref):** 2

### BG07
- **Title:** A BIM-based preliminary evaluation of seismic capability for low-rise reinforced concrete buildings with soft stories
- **Authors:** Nai-Wen Chi, Chien-Kuo Chiu, Wan-Chun Liao
- **Year:** 2026
- **Source:** Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1080/15732479.2026.2639387
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.

### BG08
- **Title:** Bridge slabs retrofitting with concrete overlay: Codes comparison and parametric design
- **Authors:** Pietro Crespi, Manuela Scamardo, Nicola Longarini, Sara Cattaneo
- **Year:** 2025
- **Source:** Structures 82, 110613
- **DOI / link:** https://doi.org/10.1016/j.istruc.2025.110613
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 1

### BG09
- **Title:** Seismic performance analysis of wind and rain bridge structures and design of a seismic vibration damping program using rubber isolators
- **Authors:** Wenke Yuan, Bocheng Xie, Weizhe Zhou, Zixuan Yin, Zhengwang Wang, Ting Ding
- **Year:** 2025
- **Source:** Structures 79, 109474
- **DOI / link:** https://doi.org/10.1016/j.istruc.2025.109474
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 7

### BG10
- **Title:** Deep-learning-based aesthetic evaluation network for bridge pylon and aesthetics-oriented bridge design
- **Authors:** Cheng Xiang, Airong Chen, Dalei Wang, Yun Ning
- **Year:** 2025
- **Source:** Structures 71, 108167
- **DOI / link:** https://doi.org/10.1016/j.istruc.2024.108167
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 4

### BG11
- **Title:** Conceptual Design of an 800m Span Inverted Extradosed Suspension Bridge Incorporating Prestressed Concrete Butterfly Web Girder
- **Authors:** A. I. Zerin, H. T. Khuyen, H. Uchibori, R. Chamila, H. Shinozaki, A. Kasuga
- **Year:** 2025
- **Source:** IABSE Reports, IABSE Symposium, Tokyo 2025: Environmentally Friendly Technologies and Structures: Focusing on Sustainable Approaches 121, 1142-1149
- **DOI / link:** https://doi.org/10.2749/tokyo.2025.1142
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BG12
- **Title:** Enhancing infrastructure planning and design through BIM-GIS integration
- **Authors:** Sonam Pelden, Saeed Banihashemi, Saeed Reza Mohandes, Mehrdad Arashpour, Mohsen Kalantari
- **Year:** 2025
- **Source:** Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1080/15732479.2025.2461629
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.
- **Cites (Crossref):** 16

### BG13
- **Title:** An open-source GIS app for digitalising bridge inspections and automating BIM model integration
- **Authors:** Fidel Lozano-Galant, Angela Montalvo, Edison Atencio, Rocío Porras, Jose Antonio Lozano-Galant
- **Year:** 2025
- **Source:** Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1080/15732479.2025.2456979
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.
- **Cites (Crossref):** 9

### BG14
- **Title:** Development of BIM-based Bridge Maintenance Digital Transformatiom System
- **Authors:** B. J. Lee, B. S. Ku, M. S. Nam, H. T. Kang
- **Year:** 2025
- **Source:** IABSE Reports, IABSE Symposium, Tokyo 2025: Environmentally Friendly Technologies and Structures: Focusing on Sustainable Approaches 121, 1443-1449
- **DOI / link:** https://doi.org/10.2749/tokyo.2025.1443
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.

### BG15
- **Title:** Performance-based seismic design of Ultra-High-Performance Concrete (UHPC) bridge columns with design example – Powered by explainable machine learning model
- **Authors:** Tadesse G. Wakjira, M. Shahria Alam
- **Year:** 2024
- **Source:** Engineering Structures 314, 118346
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2024.118346
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 54

### BG16
- **Title:** Research on topology optimization strut-and-tie model and prestress construction for cable-pylon anchorage zone of Fengshuba Bridge
- **Authors:** Jingwei Zhu, Ming Wang, Yuan Li, Nannan Cui, Jingchuan Xun
- **Year:** 2024
- **Source:** Structures 68, 107146
- **DOI / link:** https://doi.org/10.1016/j.istruc.2024.107146
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 4

### BG17
- **Title:** Multi-objective optimization of cable force of arch bridge constructed by cable-stayed cantilever cast-in-situ method based on improved NSGA-II
- **Authors:** Zhongchu Tian, Zujun Zhang, Chen Ning, Tao Peng, Yue Guo, Zheng Cao
- **Year:** 2024
- **Source:** Structures 59, 105782
- **DOI / link:** https://doi.org/10.1016/j.istruc.2023.105782
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 39

### BG18
- **Title:** Robustness improvements for 2D reinforced concrete moment resisting frames: Parametric study by means of NLFE analyses
- **Authors:** Elena Miceli, Paolo Castaldo
- **Year:** 2024
- **Source:** Structural Concrete 25(1), 9-31
- **DOI / link:** https://doi.org/10.1002/suco.202300443
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 31

### BG19
- **Title:** A new methodology for pre-camber design of a long-span bridge considering dynamic train load and complex environmental effects
- **Authors:** Ruoyu Li, Qinglie He, Shengyang Zhu, Junfeng Yan, Wanming Zhai
- **Year:** 2024
- **Source:** Engineering Structures 302, 117349
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2023.117349
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 18

### BG20
- **Title:** Multiobjective optimization of bridge and viaduct design: Comparative study of metaheuristics and parameter calibration
- **Authors:** Eduardo Vicente Wolf Trentini, Guilherme Aris Parsekian, Túlio Nogueira Bittencourt
- **Year:** 2024
- **Source:** Engineering Structures 312, 118252
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2024.118252
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 14

### BG21
- **Title:** Direct displacement-based design of skewed bridge isolated with LRBs
- **Authors:** Yan Shi, Jixin Wang, Jianping Han, Hongguo Qin, Changquan Che
- **Year:** 2024
- **Source:** Structures 66, 106912
- **DOI / link:** https://doi.org/10.1016/j.istruc.2024.106912
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 4

### BG22
- **Title:** Optimization of Cable Force for Hybrid Girder Cable-Stayed Bridge Based on Particle Swarm Optimization Algorithm
- **Authors:** Wenhao Xiao
- **Year:** 2024
- **Source:** Sustainable Civil Infrastructures, Structural Safety and Ground Improvement on Bridge
- **DOI / link:** https://doi.org/10.1007/978-3-031-76102-7_13
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BG23
- **Title:** BIM-based intelligent optimization of complex steel joints using SVM and NSGA-II
- **Authors:** Yaping Lai, Ke Ke, Letian Wang, Lufeng Wang
- **Year:** 2024
- **Source:** Journal of Constructional Steel Research 223, 109086
- **DOI / link:** https://doi.org/10.1016/j.jcsr.2024.109086
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.
- **Cites (Crossref):** 14

### BG24
- **Title:** Conceptual design of long span steel-UHPC composite network arch bridge
- **Authors:** Yaping Lai, Yu Li, Maoke Huang, Lijun Zhao, Jiayong Chen, Yi Min Xie
- **Year:** 2023
- **Source:** Engineering Structures 277, 115434
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2022.115434
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 51

### BG25
- **Title:** Parametric analysis of variables influencing the design of I‐girder bridge decks made of high‐performance fiber reinforced concrete
- **Authors:** Rafael Ruiz, Gian Biagio Starchevich, Leonardo Todisco, Hugo Corres
- **Year:** 2023
- **Source:** Structural Concrete 24(4), 4606-4623
- **DOI / link:** https://doi.org/10.1002/suco.202200477
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 2

### BG26
- **Title:** Bridge topology optimization considering stochastic moving traffic
- **Authors:** Thomas Golecki, Fernando Gomez, Juan Carrion, Billie F. Spencer
- **Year:** 2023
- **Source:** Engineering Structures 292, 116498
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2023.116498
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 30

### BG27
- **Title:** Seismic resilient design of rocking tall bridge piers using inerter-based systems
- **Authors:** Xu Chen, Dario De Domenico, Chunxiang LI
- **Year:** 2023
- **Source:** Engineering Structures 281, 115819
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2023.115819
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 113

### BG28
- **Title:** Machine learning driven post-impact damage state prediction for performance-based crashworthiness design of bridge piers
- **Authors:** Chang Zhou, Yazhou Xie, Wenwei Wang, Yuzhou Zheng
- **Year:** 2023
- **Source:** Engineering Structures 292, 116539
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2023.116539
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 57

### BG29
- **Title:** Tyre contact surface for the fatigue design of orthotropic steel bridge decks
- **Authors:** Jorrit D. Rodenburg, Johan Maljaars, Sjoerd T. Hengeveld, Adri H.J.M. Vervuurt
- **Year:** 2023
- **Source:** Engineering Structures 283, 115869
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2023.115869
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 25

### BG30
- **Title:** A novel Genetic algorithm based form-finding approach towards the improved design of tensegrity utility bridge
- **Authors:** Sumit Kumar, Neha Aswal, Subhamoy Sen
- **Year:** 2023
- **Source:** Structures 58, 105401
- **DOI / link:** https://doi.org/10.1016/j.istruc.2023.105401
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 14

### BG31
- **Title:** Performance-based blast-resistant design of RC bridge piers under vehicular bombs
- **Authors:** L.L. Ma, H. Wu, Q. Fang
- **Year:** 2023
- **Source:** Engineering Structures 291, 116492
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2023.116492
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 10

### BG32
- **Title:** Design method for bridge deck link slabs prepared using <scp>BFRP</scp> bar‐reinforced ecological high‐ductility cementitious composites by theoretical calculation and numerical simulation
- **Authors:** Li‐Juan Chai, Bo Chen, Li‐Ping Guo, Kai Li
- **Year:** 2023
- **Source:** Structural Concrete 24(4), 4889-4902
- **DOI / link:** https://doi.org/10.1002/suco.202200898
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 7

### BG33
- **Title:** Innovative design of long-span steel–concrete composite bridge using multi-material topology optimization
- **Authors:** Yu Li, Yaping Lai, Gan Lu, Fucheng Yan, Peng Wei, Yi Min Xie
- **Year:** 2022
- **Source:** Engineering Structures 269, 114838
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2022.114838
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 80

### BG34
- **Title:** The First Step Towards BIM Models in Major Bridge Design
- **Authors:** Uffe Graaskov Ravn, Thomas Löhning, Jesper Warschow Sørensen
- **Year:** 2022
- **Source:** IABSE Congress Reports, IABSE Congress, Nanjing 2022: Bridges and Structures: Connection, Integration and Harmonisation 22, 894-901
- **DOI / link:** https://doi.org/10.2749/nanjing.2022.0894
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BG35
- **Title:** BIM authoring and Data Models for Bridge Maintenance Systems in Korea
- **Authors:** Changsu Shim, Kitae Roh, Ngoc-Son Dang
- **Year:** 2022
- **Source:** IABSE Reports, IABSE Symposium, Prague 2022: Challenges for Existing and Oncoming Structures 118, 1867-1872
- **DOI / link:** https://doi.org/10.2749/prague.2022.1867
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BG36
- **Title:** Fragility-informed seismic design of multi-column bridge bents with post-tensioned concrete columns for accelerated bridge construction
- **Authors:** A. Upadhyay, C.P. Pantelides
- **Year:** 2022
- **Source:** Engineering Structures 269, 114807
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2022.114807
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 16

### BG37
- **Title:** Machine learning driven seismic performance limit state identification for performance-based seismic design of bridge piers
- **Authors:** Borislav Todorov, AHM Muntasir Billah
- **Year:** 2022
- **Source:** Engineering Structures 255, 113919
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2022.113919
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 74

### BG38
- **Title:** Conceptual Design of 5 km-Class Super Long Span Bridge
- **Authors:** Chang Su Kim, Eu Kyeong Cho, Ho Kyung Kim
- **Year:** 2022
- **Source:** IABSE Congress Reports, IABSE Congress, Nanjing 2022: Bridges and Structures: Connection, Integration and Harmonisation 22, 427-434
- **DOI / link:** https://doi.org/10.2749/nanjing.2022.0427
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BG39
- **Title:** State-of-the-art review and design of grouted duct connections for precast bridge columns
- **Authors:** Mostafa Tazarv, Grishma Shrestha, M. Saiid Saiidi
- **Year:** 2021
- **Source:** Structures 30, 895-909
- **DOI / link:** https://doi.org/10.1016/j.istruc.2020.12.091
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 41

### BG40
- **Title:** Size and post-tensioning cable force optimization of cable-stayed footbridge
- **Authors:** Barbaros Atmaca
- **Year:** 2021
- **Source:** Structures 33, 2036-2049
- **DOI / link:** https://doi.org/10.1016/j.istruc.2021.05.050
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 21

### BG41
- **Title:** Conceptual design and experimental verification study of a special-shaped composite arch bridge
- **Authors:** Pengzhen Lu, Junping Zhang, Dengguo Li, Yutao Zhou, Qingtian Shi
- **Year:** 2021
- **Source:** Structures 29, 1380-1389
- **DOI / link:** https://doi.org/10.1016/j.istruc.2020.12.018
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 14

### BG42
- **Title:** Smart design of coupling scissors-type bridge
- **Authors:** Khongkham Chanthamanivong, Ichiro Ario, Yuki Chikahiro
- **Year:** 2021
- **Source:** Structures 30, 206-216
- **DOI / link:** https://doi.org/10.1016/j.istruc.2020.12.044
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 7

### BG43
- **Title:** Quasi-static strength of bridge fingerplates under various design parameters
- **Authors:** Mohammed Mutnbak, Hani Salim, Alaa El-Din El-Sisi
- **Year:** 2021
- **Source:** Structures 32, 2161-2173
- **DOI / link:** https://doi.org/10.1016/j.istruc.2021.04.031
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 4

### BG44
- **Title:** Resistance of curved steel cross-sections for bridge deck applications: Design proposals
- **Authors:** Filip Ljubinković, João Pedro Martins, Helena Gervásio, Luís Simões da Silva
- **Year:** 2021
- **Source:** Journal of Constructional Steel Research 182, 106679
- **DOI / link:** https://doi.org/10.1016/j.jcsr.2021.106679
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 4

### BG45
- **Title:** Resilience-Based Design for Next-Generation Bridge Design and construction
- **Authors:** Mohammad Mehdi Kashani, Saiid Saiidi, Marc O. Eberhard
- **Year:** 2021
- **Source:** Structures 34, 4466
- **DOI / link:** https://doi.org/10.1016/j.istruc.2021.10.054
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 3

### BG46
- **Title:** Towards a Holistic Bridge BIM Solution
- **Authors:** Vanja Samec, Johann Stampler, Jan Osterz, Jaroslav Navrátil, Moonjoo Byun
- **Year:** 2020
- **Source:** IABSE Reports, IABSE Conference, Seoul 2020: Risk Intelligence of Infrastructures 117, 174-180
- **DOI / link:** https://doi.org/10.2749/seoul.2020.174
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 1

### BG47
- **Title:** Life-cycle cost based design of bridge lead-rubber isolators in seismic regions
- **Authors:** Payam Asadi, Davood Nikfar, Iman Hajirasouliha
- **Year:** 2020
- **Source:** Structures 27, 383-395
- **DOI / link:** https://doi.org/10.1016/j.istruc.2020.05.056
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 19

### BG48
- **Title:** A flexure-capacity design method and seismic fragility assessment of FRP/steel double-reinforced bridge piers
- **Authors:** Daoguang Jia, Jize Mao, Qingyong Guo, Zailin Yang, Nailiang Xiang
- **Year:** 2020
- **Source:** Structure and Infrastructure Engineering 16(9), 1311-1325
- **DOI / link:** https://doi.org/10.1080/15732479.2019.1703762
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 11

### BG49
- **Title:** Downsizing weight while upsizing efficiency: An experimental approach to develop optimized ultra‐light UHPC hybrid beams
- **Authors:** Georgios Gaganelis, Peter Mark
- **Year:** 2019
- **Source:** Structural Concrete 20(6), 1883-1895
- **DOI / link:** https://doi.org/10.1002/suco.201900215
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 42

### BG50
- **Title:** BIM for Bridge Design
- **Authors:** Yulin Luo, Yateng Liu
- **Year:** 2016
- **Source:** IABSE Reports, IABSE Conference, Guangzhou 2016: Bridges and Structures Sustainability - Seeking Intelligent Solutions 114, 343-350
- **DOI / link:** https://doi.org/10.2749/222137816819258654
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 5

### BG51
- **Title:** Effect of dynamic impact at modular bridge expansion joints on bridge design
- **Authors:** Yong Ding, Wei Zhang, Francis T.K. Au
- **Year:** 2016
- **Source:** Engineering Structures 127, 645-662
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2016.09.007
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 49


---

**This batch listed:** 85 unique named items (deduped vs Batches 01–07 and earlier 08+).
