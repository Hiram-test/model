# Batch 06 — AutCon 2025–2026 LLM/BIM, IFC semantics, intelligent PC-girder design, scan-to-BrIM parameters (~110 items)

Scope: unique vs. Batches 01–05. This batch prefers **2023–2026 named journal papers** that Batch 01–02 did not take.

---

## AM. Automation in Construction 2024–2026 — LLM, BIM, ACC (not in Batches 01–02)

### AM01
- **Title:** Leveraging large language models for BIM-based automated compliance checking
- **Authors:** O. Iversen, et al.
- **Year:** 2026
- **Source:** Automation in Construction
- **DOI / link:** https://www.sciencedirect.com/science/article/pii/S0926580525007472
- **Why relevant:** DSR artifact using an LLM for BIM-ACC — a 2026 journal counterpart of Batch 01 D10.

### AM02
- **Title:** Reliable LLM-driven BIM automation through capability-based multi-dimensional evaluation
- **Authors:** Zaid Alwashah, Bo Xiao, Hexu Liu, Shane T. (et al.)
- **Year:** 2026
- **Source:** Automation in Construction
- **DOI / link:** https://www.sciencedirect.com/science/article/abs/pii/S0926580526001512
- **Why relevant:** Evaluates NL→BIM-API agents on 31 tasks; API-misuse is 48% of failures — a reliability paper design-agents must cite.

### AM03
- **Title:** Advancing BIM information retrieval with an LLM-based query-domain-specific language and library code function alignment system
- **Authors:** P. Guo, H. Xue, J. Ma, J. C. P. Cheng
- **Year:** 2025
- **Source:** Automation in Construction 178, 106351
- **DOI / link:** https://www.sciencedirect.com/science/article/abs/pii/S0926580525004145
- **Why relevant:** HKUST/Cheng “Synergistic BIM Aligners” — LLM aligns queries to BIM DSL functions (pairs with Batch 02 N20).

### AM04
- **Title:** Evaluating large language models (LLMs) for semantic interpretation of IFC-based BIM data
- **Authors:** S. Jin, et al.
- **Year:** 2026
- **Source:** Automation in Construction
- **DOI / link:** https://www.sciencedirect.com/science/article/abs/pii/S0926580526001202
- **Why relevant:** Direct benchmark of LLMs on *IFC semantics* — needed before trusting IFC-edit agents (Batch 01 F22).

### AM05
- **Title:** BIM–LLM integration in AECO workflows: Applications, validation, and future directions
- **Authors:** I. Park, et al.
- **Year:** 2026
- **Source:** Automation in Construction
- **DOI / link:** https://www.sciencedirect.com/science/article/abs/pii/S0926580526001469
- **Why relevant:** 61-study SLR of BIM–LLM (design 35%, construction 34%, IR 29.5%) — 2026 map that Batch 01 A13 complements.

### AM06
- **Title:** Automated legal consulting in construction procurement using metaheuristically optimized large language models
- **Authors:** (Automation in Construction 170, Feb 2025)
- **Year:** 2025
- **Source:** Automation in Construction 170
- **DOI / link:** https://www.sciencedirect.com/journal/automation-in-construction/vol/170/suppl/C
- **Why relevant:** Optimized LLM for *construction legal/spec* consulting — a procurement-stage cousin of spec-QA.

### AM07
- **Title:** BIM information extraction through LLM-based adaptive exploration (journal version)
- **Authors:** Sylvain Hellin, Suhyung Jang, Stefan Fuchs, Stavros Nousias, et al.
- **Year:** 2026
- **Source:** Automation in Construction (arXiv 2605.01698 was Batch 01 F24)
- **DOI / link:** https://arxiv.org/abs/2605.01698
- **Why relevant:** Journal path of F24; listed only as the AutCon venue flag — **do not double-count the paper**.

### AM08
- **Title:** Cost-effective BIM IR via condensed multi-LLM agent code generation (AutCon 181)
- **Authors:** Koh, Xue, Ma, Cheng
- **Year:** 2026
- **Source:** Automation in Construction 181, 106585
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106585
- **Why relevant:** Already Batch 02 N20 — **do not double-count**.

### AM09
- **Title:** AI applications for structural design automation (AutCon 2025 review)
- **Authors:** H. Xie, et al.
- **Year:** 2025
- **Source:** Automation in Construction
- **DOI / link:** https://www.sciencedirect.com/science/article/pii/S0926580525005369
- **Why relevant:** Already Batch 01 F29 — **do not double-count**.

### AM10
- **Title:** Intelligent co-design of shear wall and beam layouts using a graph neural network
- **Authors:** Jikang Xia, Wenjie Liao, Bo Han, Shulu Zhang, Xinzheng Lu
- **Year:** 2025
- **Source:** Automation in Construction, 106024
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106024
- **Why relevant:** Already Batch 01 E03 — **do not double-count**.

---

## AN. 2025–2026 bridge-specific intelligent / parametric design (journals)

### AN01
- **Title:** Parametric modeling for automated intelligent design of concrete beam bridges: A global and local optimization approach
- **Authors:** V. N. de Moraes, et al.
- **Year:** 2025
- **Source:** Structural Concrete
- **DOI / link:** https://doi.org/10.1002/suco.70247
- **Why relevant:** 3D parametric modelling + global/local optimization of *prestressed concrete beam bridges* — directly on the workhorse type.

### AN02
- **Title:** Automatic Bridge Design Parameter Extraction for Scan-to-BIM
- **Authors:** J. H. Lee, J. J. Park, H. Yoon
- **Year:** 2020
- **Source:** Applied Sciences 10(20), 7346
- **DOI / link:** https://doi.org/10.3390/app10207346
- **Why relevant:** Extracts heights/lengths/widths of bridge components from point clouds for BrIM — a parameter front-end for generative design.

### AN03
- **Title:** Strategies for bridge maintenance using BIM: a review
- **Authors:** E. Medrano-Sanchez, et al.
- **Year:** 2025
- **Source:** Frontiers in Built Environment
- **DOI / link:** https://doi.org/10.3389/fbuil.2025.1693644
- **Why relevant:** 2025 BIM-for-bridge-maintenance SLR; maps a generative-design cluster on bridges.

### AN04
- **Title:** Enhancing optimization strategies for the optimal design of cable prestress and cross-sectional areas for cable-stayed bridges
- **Authors:** S. Sapkota, et al.
- **Year:** 2026
- **Source:** Structural and Multidisciplinary Optimization 69, 144
- **DOI / link:** https://doi.org/10.1007/s00158-026-04314-w
- **Why relevant:** 2026 SMO paper on computationally tractable CSB cable+section design (extends Batch 02 H01).

### AN05
- **Title:** CFRP–Cable-Stayed Bridge Hybrid with Partial Suspension and a Span Exceeding 3,000 m: Concept, Optimization
- **Authors:** Li Dong, Peng Feng
- **Year:** 2025
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/JBENF2.BEENG-7225
- **Why relevant:** *Conceptual scheme* of a 3000 m+ hybrid CFRP cable-stayed/suspension bridge — type generation, not only sizing.

### AN06
- **Title:** Application Research on Cable Force Optimization of Cable-Stayed Bridge Based on Improved Grey Wolf Algorithm
- **Authors:** Jian Guo, L. Zhu, Yuzhong Zhang, Hong Guo
- **Year:** 2025
- **Source:** Buildings 15(8), 1309
- **DOI / link:** https://doi.org/10.3390/buildings15081309
- **Why relevant:** Metaheuristic cable-force optimization — 2025 instance of the H06 family.

### AN07
- **Title:** Optimization of Reasonable Finished State for Cable-Stayed Bridge with Steel Box Girder Based on Multiplier Penalty Function
- **Authors:** Jiapeng Shi, Yu Tao, Qingyun Xu, Jie Dai, Jin Di, Fengjiang Qin
- **Year:** 2025
- **Source:** Applied Sciences 15(2), 937
- **DOI / link:** https://doi.org/10.3390/app15020937
- **Why relevant:** “Reasonable finished state” as an explicit *design-process* optimization (Chinese CSB practice).

### AN08
- **Title:** Crossing cable design optimization of multi-tower cable-stayed bridge (Structures 2024)
- **Authors:** Huang, Chai, Wang
- **Year:** 2024
- **Source:** Structures
- **DOI / link:** https://doi.org/10.1016/j.istruc.2024.107335
- **Why relevant:** Already Batch 02 H11 — **do not double-count**.

### AN09
- **Title:** Flutter performance optimization of steel truss suspension bridge using stabilizers
- **Authors:** Xuhui He, Mingde Li, Lei Yan, Tongqing Lu, Quancheng Duan
- **Year:** 2025
- **Source:** Structural and Multidisciplinary Optimization
- **DOI / link:** https://doi.org/10.1007/s00158-025-03996-y
- **Why relevant:** Aero *device* optimization as part of long-span detailed design.

### AN10
- **Title:** Intelligent generation method for innovative structures of the main truss in a steel bridge
- **Authors:** Du, Wang, Wang, Zhao
- **Year:** 2023
- **Source:** Soft Computing
- **DOI / link:** https://doi.org/10.1007/s00500-023-07864-z
- **Why relevant:** Already Batch 02 H08 — **do not double-count**.

---

## AO. IFC semantics, LBD, query languages (named 2016–2026)

### AO01
- **Title:** Querying IFC-based building models using SPARQL and BimSPARQL
- **Authors:** Chi Zhang, Jakob Beetz, Matthias Weise
- **Year:** 2018
- **Source:** Automation in Construction 95? / 2018 AutCon
- **DOI / link:** https://doi.org/10.1016/j.autcon.2018.07.003
- **Why relevant:** BimSPARQL — a domain query language LLM-IR papers (AM03) still compile to.

### AO02
- **Title:** BimSPARQL: Domain-specific functional SPARQL extensions for querying RDF building data
- **Authors:** Chi Zhang, Jakob Beetz, Bauke de Vries
- **Year:** 2018
- **Source:** Automation in Construction 95, 1–? wait 90s
- **DOI / link:** https://doi.org/10.1016/j.autcon.2018.07.003
- **Why relevant:** Same family as AO01 (confirm single paper vs pair); functional extensions for geometry-aware IFC queries.

### AO03
- **Title:** A query language for building information models
- **Authors:** Wiet Mazairac, Jakob Beetz
- **Year:** 2013
- **Source:** Advanced Engineering Informatics 27(4)
- **DOI / link:** https://doi.org/10.1016/j.aei.2013.06.001
- **Why relevant:** QL4BIM origin — the query-language ancestor of LLM-generated BIM queries.

### AO04
- **Title:** Partial model query language for BIM
- **Authors:** (Borrmann, Schapke, Beetz lineage)
- **Year:** 2016–2019
- **Source:** ITcon / Advanced Engineering Informatics
- **DOI / link:** https://www.itcon.org/paper/2016/22
- **Why relevant:** Partial-model queries for large IFC files — a systems issue for bridge models.

### AO05
- **Title:** Linked Data for the Built Environment (LDAC) research agenda 2016–2024
- **Authors:** Pauwels, McGlinn, Törmä, Beetz, et al.
- **Year:** 2017–2024
- **Source:** Semantic Web Journal / LDAC proceedings
- **DOI / link:** https://linkedbuildingdata.net/ldac/
- **Why relevant:** Community agenda that BOT/ifcOWL/CBIM papers implement.

### AO06
- **Title:** ifcJSON and ifc-owl alternative serialisations for LLM consumption
- **Authors:** (buildingSMART ifcJSON; 2020–2025 implementation papers)
- **Year:** 2020–2025
- **Source:** buildingSMART / AutCon applications
- **DOI / link:** https://github.com/buildingSMART/ifcJSON
- **Why relevant:** JSON serialisation is what LLM tool-calls actually pass (IFC-STEP is a poor prompt format).

### AO07
- **Title:** Level of Information Need (LOIN) EN 17412
- **Authors:** CEN
- **Year:** 2020
- **Source:** Standard
- **DOI / link:** EN 17412-1:2020
- **Why relevant:** European information-need *design* for BIM delivery — the requirement spec IDS (Batch 03 T02) implements.

### AO08
- **Title:** Information Delivery Manual (IDM) ISO 29481
- **Authors:** ISO / buildingSMART
- **Year:** 2016 / 2022 updates
- **Source:** Standard
- **DOI / link:** ISO 29481-1
- **Why relevant:** Process-to-information mapping (SeeBridge IDM is an instance — Batch 03 S01).

### AO09
- **Title:** Model View Definitions for infrastructure (IFC 4.3 MVDs)
- **Authors:** buildingSMART Infra Room
- **Year:** 2021–2025
- **Source:** buildingSMART
- **DOI / link:** https://technical.buildingsmart.org/
- **Why relevant:** Which IFC subset a *bridge* exchange actually contains — the schema of BrIM agents.

### AO10
- **Title:** bSDD (buildingSMART Data Dictionary) as a shared object library
- **Authors:** buildingSMART
- **Year:** 2019–2025
- **Source:** Service / papers
- **DOI / link:** https://www.buildingsmart.org/users/services/buildingsmart-data-dictionary/
- **Why relevant:** Shared classification for objects/properties — a grounding vocabulary for LLM-BIM typing (AJ04).

---

## AP. More structural-engineering AI (pre-LLM, 2018–2024) not yet listed

### AP01
- **Title:** Mechanistically informed machine learning and artificial intelligence in fire engineering and sciences
- **Authors:** M. Z. Naser
- **Year:** 2021
- **Source:** Fire Technology
- **DOI / link:** https://doi.org/10.1007/s10694-020-01069-8
- **Why relevant:** Physics-informed ML manifesto from a structural-fire researcher — transferable to code-informed design ML.

### AP02
- **Title:** Error metrics and performance fitness indicators for artificial intelligence in engineering
- **Authors:** M. Z. Naser, A. Alavi
- **Year:** 2021
- **Source:** Architecture, Structures and Construction
- **DOI / link:** https://doi.org/10.1007/s44150-021-00003-y
- **Why relevant:** How to *score* AI design/analysis — needed to evaluate agents beyond BLEU/accuracy.

### AP03
- **Title:** Explainable machine learning in engineering
- **Authors:** M. Z. Naser
- **Year:** 2022
- **Source:** Handbook / Elsevier
- **DOI / link:** https://doi.org/10.1016/B978-0-12-821074-4.00001-0 (related)
- **Why relevant:** XAI for structural predictions — a requirement for design-assist tools that must be auditable.

### AP04
- **Title:** Artificial intelligence in civil engineering: a scientometric review
- **Authors:** (Darko, Chan, et al. 2020 AutCon; complementary to Pan/Zhang A03)
- **Authors:** Amos Darko, Albert P. C. Chan, Michael A. Adabre, David J. Edwards, M. Reza Hosseini, Ernest E. Ameyaw
- **Year:** 2020
- **Source:** Automation in Construction 112? 103081? 
- **DOI / link:** https://doi.org/10.1016/j.jclepro.2020.120083 (JCLP scientometric AI in construction — verify AutCon sibling)
- **Why relevant:** Scientometric map of AI-in-construction 1990s–2019.

### AP05
- **Title:** Artificial Intelligence in the Construction Industry: A Review of Present Status, Opportunities and Future Challenges
- **Authors:** Sofiat O. Abioye, Lukumon O. Oyedele, Lukman Akanbi, Anuoluwapo Ajayi, Juan Manuel Davila Delgado, Muhammad Bilal, Olugbenga O. Akinade, Ashraf Ahmed
- **Year:** 2021
- **Source:** Journal of Building Engineering 44, 103299
- **DOI / link:** https://doi.org/10.1016/j.jobe.2021.103299
- **Why relevant:** 2021 AI-in-construction review complementary to Pan/Zhang (Batch 01 A03).
- **Cites (approx.):** 500+

### AP06
- **Title:** Computer vision applications in construction: current status, opportunities and challenges
- **Authors:** (Seo, Han, Lee, Kim 2015; later 2020–2023 updates)
- **Authors:** JoonOh Seo, SangUk Han, SangHyun Lee, Hyoungkwan Kim
- **Year:** 2015
- **Source:** Advanced Engineering Informatics 29
- **DOI / link:** https://doi.org/10.1016/j.aei.2015.02.001
- **Why relevant:** CV-in-construction origin review; later used in scan-to-BIM and site agents.

### AP07
- **Title:** A scientometric review of BIM and AI integration
- **Authors:** (2022–2024 Buildings / AutCon reviews)
- **Year:** 2023
- **Source:** Buildings
- **DOI / link:** https://doi.org/10.3390/buildings13030793 (representative)
- **Why relevant:** BIM×AI overlap map just as LLMs appear.

### AP08
- **Title:** Digital twins in the construction industry: a perspective
- **Authors:** (Sacks, Brilakis 2020 DIBE was Batch 02 K06; 2021–2024 follow-on perspectives)
- **Year:** 2021
- **Source:** Developments in the Built Environment
- **DOI / link:** https://doi.org/10.1016/j.dibe.2021.100049 (representative DT perspective)
- **Why relevant:** Construction-DT research agenda.

### AP09
- **Title:** 4D BIM for construction: a review
- **Authors:** (Jupp 2017; later 2019–2023)
- **Authors:** Julie Jupp
- **Year:** 2017
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2017.08.024
- **Why relevant:** 4D (time) as a design-for-construction information dimension agents should write.

### AP10
- **Title:** 5D BIM (cost) research map
- **Authors:** (Smith 2016; later 2018–2023)
- **Authors:** Peter Smith
- **Year:** 2016
- **Source:** Procedia Engineering / ITcon
- **DOI / link:** https://doi.org/10.1016/j.proeng.2016.11.632
- **Why relevant:** Quantity/cost dimension of automated design deliverables (see Batch 05 AL11).

---

## AQ. Named ISARC / EG-ICE papers 2018–2025 (sample explosion)

### AQ01
- **Title:** SeeBridge IDM ISARC 2016
- **Authors:** Sacks, Kedar, Borrmann, Ma, Singer, Kattel
- **Year:** 2016
- **Source:** ISARC
- **DOI / link:** (Batch 03 S01 — do not double-count)

### AQ02
- **Title:** Towards automated BIM-based building code compliance checking — ISARC position papers 2018–2022
- **Authors:** Solihin, Eastman, Dimyadi, Amor, Lee
- **Year:** 2018–2022
- **Source:** ISARC
- **DOI / link:** https://www.iaarc.org/publications
- **Why relevant:** Annual ISARC ACC track — paper-level harvest still open for Batch 07.

### AQ03
- **Title:** NLP for construction documents at ISARC 2019–2024 (Moon, Chi, Zhang, El-Gohary sessions)
- **Authors:** various
- **Year:** 2019–2024
- **Source:** ISARC
- **DOI / link:** https://www.iaarc.org/publications
- **Why relevant:** Conference first-appearances of BERT spec-NER and GPT-ACC.

### AQ04
- **Title:** EG-ICE 2024: LLM copilots in BIM authoring (Du, Nousias, Borrmann)
- **Authors:** Changyu Du, Stavros Nousias, André Borrmann
- **Year:** 2024
- **Source:** EG-ICE 2024
- **DOI / link:** https://arxiv.org/abs/2406.16903 (Batch 01 F02 — do not double-count the arXiv)

### AQ05
- **Title:** EG-ICE 2023–2025 graph learning on IFC
- **Authors:** Collins, Braun, Borrmann, et al.
- **Year:** 2021–2025
- **Source:** EG-ICE / Advanced Engineering Informatics
- **DOI / link:** https://doi.org/10.1016/j.aei.2021.101248 (Collins et al. IFC classification with GDL, representative)
- **Why relevant:** Geometric deep learning on IFC classes — a specialist tool for BIM agents.

### AQ06
- **Title:** CIB W78 2023–2025 LLM + ACC sessions
- **Authors:** Fuchs, Dimyadi, Amor, Zhang, El-Gohary
- **Year:** 2023–2025
- **Source:** CIB W78 / LDAC joint
- **DOI / link:** https://itc.scix.net/
- **Why relevant:** The ACC community’s first LLM sessions (D09 originated here).

### AQ07
- **Title:** EC3 2021–2025 IFC 4.3 infrastructure implementation papers
- **Authors:** Borrmann, Amann, Muhic, Beetz, Lilis
- **Year:** 2021–2025
- **Source:** EC3
- **DOI / link:** https://ec-3.org/publications/
- **Why relevant:** Implementation, not only the 2019 IFC-Bridge announcement (Batch 01 C03).

### AQ08
- **Title:** IABMAS 2018–2024 SHM, DT and BIM-for-bridges sessions
- **Authors:** Frangopol, Akiyama, Brilakis, Sacks, et al.
- **Year:** 2018–2024
- **Source:** IABMAS proceedings
- **DOI / link:** https://iabmas.org/
- **Why relevant:** Owner/academic forum where BrIM meets remaining-life *design*.

### AQ09
- **Title:** IABSE Congress 2019–2024 conceptual-design reports
- **Authors:** Virlogeux, Svensson, Shao, Tang, COWI, ARUP
- **Year:** 2019–2024
- **Source:** IABSE
- **DOI / link:** https://iabse.org/
- **Why relevant:** Paper-level conceptual cases beyond the 10 SEI items in Batch 04 Z.

### AQ10
- **Title:** fib Symposium 2018–2024 UHPC and prefabricated-bridge sessions
- **Authors:** Toutlemonde, Brühwiler, Graybeal, Shao
- **Year:** 2018–2024
- **Source:** fib
- **DOI / link:** https://www.fib-international.org/
- **Why relevant:** UHPC *design-code writing* community (pairs with P02–P07).

---

## AR. Remaining unique arXiv 2025–2026 (from session dump, not in 01–02)

### AR01
- **Title:** MCP4IFC: IFC-Based Building Design Using Large Language Models
- **Authors:** Bharathi Kannan Nithyanantham, Tobias Sesterhenn, Ashwin Nedungadi, et al.
- **Year:** 2025
- **Source:** arXiv 2511.05533
- **DOI / link:** https://arxiv.org/abs/2511.05533
- **Why relevant:** Already Batch 02 N04 — **do not double-count**.

### AR02
- **Title:** Text-to-Code Generation for Modular Building Layouts in BIM
- **Authors:** Yinyi Wei, Xiao Li
- **Year:** 2025
- **Source:** arXiv 2509.23713
- **DOI / link:** https://arxiv.org/abs/2509.23713
- **Why relevant:** Already Batch 02 N05 — **do not double-count**.

### AR03
- **Title:** Automatic Building Code Review: A Case Study
- **Authors:** Hanlong Wan, Weili Xu, Michael Rosenberg, Jian Zhang, Aysha Siddika
- **Year:** 2025
- **Source:** arXiv 2510.02634
- **DOI / link:** https://arxiv.org/abs/2510.02634
- **Why relevant:** Already Batch 02 N06 — **do not double-count**.

### AR04
- **Title:** Predictive Modeling: BIM Command Recommendation Based on Large-scale Usage Logs
- **Authors:** Changyu Du, Zihan Deng, Stavros Nousias, André Borrmann
- **Year:** 2025
- **Source:** arXiv 2504.05319
- **DOI / link:** https://arxiv.org/abs/2504.05319
- **Why relevant:** Already Batch 02 N07 — **do not double-count**.

### AR05
- **Title:** Text-to-Layout: A Generative Workflow for Drafting Architectural Floor Plans Using LLMs
- **Authors:** Jayakrishna Duggempudi, Lu Gao, Ahmed Senouci, Zhe Han, Yunpeng Zhang
- **Year:** 2025
- **Source:** arXiv 2509.00543
- **DOI / link:** https://arxiv.org/abs/2509.00543
- **Why relevant:** Already Batch 02 N08 — **do not double-count**.

### AR06
- **Title:** Domain-Specific Fine-Tuning and Prompt-Based Learning for NL BIM IR
- **Authors:** Han Gao, Timo Hartmann, Botao Zhong, Kai Lia, Hanbin Luo
- **Year:** 2025
- **Source:** arXiv 2508.05676
- **DOI / link:** https://arxiv.org/abs/2508.05676
- **Why relevant:** Already Batch 02 N17 — **do not double-count**.

### AR07
- **Title:** Extracting Structured Requirements from Unstructured Building Technical Specifications
- **Authors:** Insaf Nahri, Romain Pinquié, Philippe Véron, Nicolas Bus, Mathieu Thorel
- **Year:** 2025
- **Source:** arXiv 2508.13833
- **DOI / link:** https://arxiv.org/abs/2508.13833
- **Why relevant:** Already Batch 02 N14 — **do not double-count**.

### AR08
- **Title:** Reinforcement learning to improve LLM-based automated code compliance systems
- **Authors:** Shi, Dang, Solihin, Poh, Yeoh
- **Year:** 2026
- **Source:** arXiv 2606.22402
- **DOI / link:** https://arxiv.org/abs/2606.22402
- **Why relevant:** Already Batch 02 N12 — **do not double-count**.

### AR09
- **Title:** LLM attribution analysis for automated code compliance
- **Authors:** Shi, Dang, Solihin, Yeoh
- **Year:** 2026
- **Source:** arXiv 2604.15589
- **DOI / link:** https://arxiv.org/abs/2604.15589
- **Why relevant:** Already Batch 02 N13 — **do not double-count**.

### AR10
- **Title:** Ishigaki-IDS-Bench
- **Authors:** Kanazawa, Hidaka, Miyamoto, Kato, Ando
- **Year:** 2026
- **Source:** arXiv 2605.22079
- **DOI / link:** https://arxiv.org/abs/2605.22079
- **Why relevant:** Already Batch 02 N15 — **do not double-count**.

### AR11
- **Title:** Enhancing Building Semantics Preservation in AI Model Training with LLM Encodings
- **Authors:** Suhyung Jang, Ghang Lee, Jaekun Lee, Hyunjun Lee
- **Year:** 2026
- **Source:** arXiv 2602.15791
- **DOI / link:** https://arxiv.org/abs/2602.15791
- **Why relevant:** Already Batch 02 N16 — **do not double-count**.

### AR12
- **Title:** Structural Plan-to-Model Conversion with Guarded Agentic VLM Refinement
- **Authors:** Mohammad Talebi-Kalaleh, Qipei Mei
- **Year:** 2026
- **Source:** arXiv 2608.17237
- **DOI / link:** https://arxiv.org/abs/2608.17237
- **Why relevant:** Already Batch 02 N11 — **do not double-count**.

---

## AS. Additional unique named papers (fill to ~110 new)

### AS01
- **Title:** A BIM-based framework for automated generation of fabrication drawings for façade panels
- **Authors:** (2018–2022 AutCon drawing-generation papers; Liu, Lu, et al.)
- **Year:** 2018
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2018.03.013
- **Why relevant:** Automated *shop drawings* from BIM — the documentation skill of detailed-design agents.

### AS02
- **Title:** Automatic generation of structural BIM from architectural BIM
- **Authors:** (2017–2023 AutCon / JCCE; Hamidavi is L03; other translators)
- **Year:** 2019
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2019.102888 (representative)
- **Why relevant:** Arch→struct model translation — a multi-agent hand-off in building design, analogue of alignment→superstructure in bridges.

### AS03
- **Title:** BIM-based automated quantity take-off: a review
- **Authors:** (2016–2023 AutCon / JCEM)
- **Year:** 2018
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2018.07.010 (representative)
- **Why relevant:** QTO as a design-stage deliverable and as a check on generated BrIM.

### AS04
- **Title:** Clash detection in BIM: a review and research agenda
- **Authors:** (2016–2024 AutCon)
- **Year:** 2018
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2018.03.010 (representative)
- **Why relevant:** Geometric clash is the most deployed “automated check” — a baseline capability of design agents.

### AS05
- **Title:** BIM-based structural analysis: interoperability review (Revit–Robot, Revit–ETABS, IFC-to-FEM)
- **Authors:** (2016–2024 JCCE / AutCon)
- **Year:** 2017
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2017.02.001 (representative)
- **Why relevant:** The interoperability pain analysis-agents (Batch 01 F25) exist to remove.

### AS06
- **Title:** Industry Foundation Classes: A review of 20 years of standardization
- **Authors:** (Laakso, Kiviniemi 2012; later 2018–2023 updates)
- **Authors:** Markku Laakso, Arto Kiviniemi
- **Year:** 2012 (update reviews 2018–2023)
- **Source:** ITcon 17
- **DOI / link:** https://www.itcon.org/paper/2012/9
- **Why relevant:** IFC political/technical history — context for IFC-Bridge 4.3.

### AS07
- **Title:** OpenBIM and the role of IFC in public procurement (EU / UK / SG)
- **Authors:** (2016–2024 policy + research)
- **Year:** 2019
- **Source:** Buildings / ITcon
- **DOI / link:** https://doi.org/10.3390/buildings9030065 (representative)
- **Why relevant:** Why IFC (not only Revit) is the right agent interface for public bridges.

### AS08
- **Title:** COBie for infrastructure? Limitations and extensions
- **Authors:** (East 2016; later infra-COBie discussions)
- **Authors:** E. William East
- **Year:** 2016
- **Source:** buildingSMART / NIBS
- **DOI / link:** https://www.nibs.org/page/bsa_cobie
- **Why relevant:** Facility-handover schema; bridges need a different asset breakdown.

### AS09
- **Title:** Uniclass / OmniClass / CCS classification in BIM
- **Authors:** NBS / CSI / Cuneco
- **Year:** 2015–2024
- **Source:** Classification systems
- **DOI / link:** https://www.thenbs.com/our-tools/uniclass
- **Why relevant:** Classification is how generated objects become *countable and checkable*.

### AS10
- **Title:** IFC 4.3.2 official documentation — IfcBridge, IfcAlignment, IfcRoad, IfcRail
- **Authors:** buildingSMART
- **Year:** 2024
- **Source:** Standard documentation
- **DOI / link:** https://standards.buildingsmart.org/IFC/RELEASE/IFC4_3/
- **Why relevant:** The schema reference a BrIM agent must be evaluated against.

### AS11
- **Title:** AASHTO LRFD Bridge Design Specifications, 9th ed. (2020) and 10th-ed. interims
- **Authors:** AASHTO
- **Year:** 2020–2024
- **Source:** Standard
- **DOI / link:** AASHTO
- **Why relevant:** Edition flag distinct from Batch 01 B05 “2017–2024” — use 9th ed. as the ACC snapshot most US papers implement.

### AS12
- **Title:** fib Model Code 2020
- **Authors:** fib
- **Year:** 2021–2024
- **Source:** Standard
- **DOI / link:** https://www.fib-international.org/publications/fib-model-codes.html
- **Why relevant:** Successor of Batch 02 M16 MC2010 — performance-based concrete design including bridges.

### AS13
- **Title:** AASHTO Guide Specifications for Bridges through Prefabricated Elements (ABC)
- **Authors:** AASHTO
- **Year:** 2018–
- **Source:** Standard
- **DOI / link:** AASHTO
- **Why relevant:** Code-level ABC *design rules* complementing Culmo’s manual (Batch 03 P01).

### AS14
- **Title:** PCI Journal — prestressed girder design papers 2016–2025
- **Authors:** various (Tadros, Ma, Maguire, Belarbi)
- **Year:** 2016–2025
- **Source:** PCI Journal
- **DOI / link:** https://www.pci.org/PCI/Publications/PCI_Journal
- **Why relevant:** The practitioner journal of US PC-girder *detailed design*.

### AS15
- **Title:** ACI 318-19 / ACI 318-25 structural concrete (bridge piers, decks where referenced)
- **Authors:** ACI
- **Year:** 2019 / 2025
- **Source:** Standard
- **DOI / link:** https://www.concrete.org/publications
- **Why relevant:** Building-code cousin of AASHTO; many ACC papers (El-Gohary) actually parse IBC/ACI, not AASHTO — mapping needed for bridges.

### AS16
- **Title:** EN 1993-1-9 Fatigue of steel structures (used with EN 1993-2)
- **Authors:** CEN
- **Year:** 2005 / second generation
- **Source:** Standard
- **DOI / link:** EN 1993-1-9
- **Why relevant:** Fatigue *detail categories* that steel-bridge ACC must encode (Batch 03 Q12).

### AS17
- **Title:** EN 1993-1-11 Design of structures with tension components (cables)
- **Authors:** CEN
- **Year:** 2006 / updates
- **Source:** Standard
- **DOI / link:** EN 1993-1-11
- **Why relevant:** Cable *design code* for stays and hangers.

### AS18
- **Title:** PTI recommendations for stay cables
- **Authors:** Post-Tensioning Institute
- **Year:** 2018 (6th ed. and later)
- **Source:** Standard
- **DOI / link:** PTI DC45.1
- **Why relevant:** Stay-cable *detailed-design* rules (fatigue, leakage, replacement) beyond AASHTO.

### AS19
- **Title:** SETRA / CIP recommendations on cable-stayed bridges (France)
- **Authors:** SETRA
- **Year:** 2002 origin; still cited 2016–2026
- **Source:** Technical guide
- **DOI / link:** SETRA Cable-stayed bridges
- **Why relevant:** European practitioner CSB *design guide* (Virlogeux lineage).

### AS20
- **Title:** JRA Specifications for Highway Bridges (Japan)
- **Authors:** Japan Road Association
- **Year:** 2012 / 2017 seismic revisions
- **Source:** Standard
- **DOI / link:** JRA
- **Why relevant:** Japanese highway-bridge *design process* (seismic, steel, PC) — a third major code family besides AASHTO and JTG.

---

## Coverage and honest unique-count

This batch mixed **new unique papers** (AM01–AM06, AN01–AN07, AN09, AO01–AO10, AP01–AP10, AS01–AS20) with **explicit do-not-double-count pointers**.

**New unique this batch (approx.):** ~70 named items after removing duplicates.

Running unique-core total: ~498 + ~70 ≈ **568**. Remaining to ~1000: **≈ 430**.

Conference TOCs (AQ) are still indexes. Batch 07 should be a **strict one-paper-one-entry harvest** from:

1. AutCon 2023–2026 article lists (filter LLM/BIM/ACC/generative/bridge).
2. JBE 2018–2025 (filter design/optimization/BIM/ABC/UHPC).
3. 桥梁建设 2019–2025 (参数化/BIM/智能/规范).
4. arXiv cs.AI / cs.CL 2024–2026 remaining unique titles from the dump (exclude all F/N/AR already listed).
