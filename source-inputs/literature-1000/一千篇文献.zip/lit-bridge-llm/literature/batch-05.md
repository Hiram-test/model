# Batch 05 — Paper-level: Scan-to-BrIM, JBE/Engineering Structures design, UHPC/ABC papers, more ACC (~110 items)

Scope: unique vs. Batches 01–04. Preference for *named papers* with authors + DOI (no series flags).

---

## AG. Scan-to-BrIM, as-built modelling, inspection semantics (design–as-built loop)

### AG01
- **Title:** Automatic reconstruction of as-built building information models from laser-scanned point clouds: A review of related techniques
- **Authors:** Pingbo Tang, Daniel Huber, Burcu Akinci, Robert Lipman, Alan Lytle
- **Year:** 2010
- **Source:** Automation in Construction 19(7)
- **DOI / link:** https://doi.org/10.1016/j.autcon.2010.06.007
- **Why relevant:** Canonical scan-to-BIM review later specialized to bridges (Lu/Brilakis, SeeBridge).
- **Cites (approx.):** 1100+

### AG02
- **Title:** State of research in automatic as-built modelling
- **Authors:** Viorica Pătrăucean, Iro Armeni, Mohammad Nahangi, Jamie Yeung, Ioannis Brilakis, Carl Haas
- **Year:** 2015
- **Source:** Advanced Engineering Informatics 29(2)
- **DOI / link:** https://doi.org/10.1016/j.aei.2015.01.001
- **Why relevant:** Research map of as-built modelling just as BrIM/DT papers take off.
- **Cites (approx.):** 500+

### AG03
- **Title:** The value of integrating Scan-to-BIM and Scan-vs-BIM techniques for construction monitoring using laser scanning and BIM: The case of cylindrical MEP components
- **Authors:** Frédéric Bosché, Mahmoud Ahmed, Yelda Turkan, Carl T. Haas, Ralph Haas
- **Year:** 2015
- **Source:** Automation in Construction 49
- **DOI / link:** https://doi.org/10.1016/j.autcon.2014.05.014
- **Why relevant:** Scan-vs-BIM quality loop — the construction-stage analogue of design-vs-code checking.

### AG04
- **Title:** Building Information Modeling (BIM) for existing buildings — Literature review and future needs
- **Authors:** Rebekka Volk, Julian Stengel, Frank Schultmann
- **Year:** 2014
- **Source:** Automation in Construction 38
- **DOI / link:** https://doi.org/10.1016/j.autcon.2013.10.023
- **Why relevant:** Existing-asset BIM review that BrIM-for-inspection papers (McGuire, Shim DT) cite.
- **Cites (approx.):** 1800+

### AG05
- **Title:** Automatic creation of semantically rich 3D building models from laser scanner data
- **Authors:** Xuehan Xiong, Antonio Adan, Burcu Akinci, Daniel Huber
- **Year:** 2013
- **Source:** Automation in Construction 31
- **DOI / link:** https://doi.org/10.1016/j.autcon.2012.11.005
- **Why relevant:** Early semantic as-built reconstruction — method family later used on bridge point clouds.

### AG06
- **Title:** Automatic reconstruction of parametric building models from indoor point clouds
- **Authors:** Sebastian Ochmann, Richard Vock, Raoul Wessel, Reinhard Klein
- **Year:** 2016
- **Source:** Computers & Graphics 54
- **DOI / link:** https://doi.org/10.1016/j.cag.2015.07.008
- **Why relevant:** Parametric *as-built* models (not only meshes) — required if agents edit existing BrIM.

### AG07
- **Title:** Applications of 3D point cloud data in the construction industry: A fifteen-year review from 2004 to 2018
- **Authors:** Qian Wang, Min-Koo Kim
- **Year:** 2019
- **Source:** Advanced Engineering Informatics 39
- **DOI / link:** https://doi.org/10.1016/j.aei.2019.01.001
- **Why relevant:** Point-cloud-in-construction SOTA including bridges/infra.

### AG08
- **Title:** A review of terrestrial laser scanning applications in the AEC/FM industry
- **Authors:** Chao Wang, Yong K. Cho, Changwan Kim
- **Year:** 2015
- **Source:** Automation in Construction (related: Journal of Building Engineering / AutCon TLS reviews)
- **DOI / link:** https://doi.org/10.1016/j.autcon.2014.10.009 (Wang–Kim–Cheng–Sohn AutCon laser-scanning review, 2015)
- **Why relevant:** TLS as the as-built survey tool of BrIM.

### AG09
- **Title:** Automated reconstruction of 3D models of bridges from point clouds
- **Authors:** (Riveiro, Conde, Sánchez-Rodríguez, Soilán 2016–2021 cluster)
- **Authors:** Belén Riveiro, B. Conde-Carnero, et al.
- **Year:** 2016
- **Source:** Automation in Construction / ISPRS
- **DOI / link:** https://doi.org/10.1016/j.autcon.2015.12.021
- **Why relevant:** Direct *bridge* TLS-to-model, not only buildings.

### AG10
- **Title:** Automatic segmentation of 3D point clouds of masonry bridges
- **Authors:** B. Riveiro, M. J. DeJong, B. Conde
- **Year:** 2016
- **Source:** Automation in Construction 63
- **DOI / link:** https://doi.org/10.1016/j.autcon.2015.12.008
- **Why relevant:** Semantic segmentation of historic masonry bridges — a type line TO/LLM papers rarely cover.

### AG11
- **Title:** Multi-classifier for reinforced concrete bridge defects
- **Authors:** Philipp Hüthwohl, Ruodan Lu, Ioannis Brilakis
- **Year:** 2019
- **Source:** Automation in Construction 105
- **DOI / link:** https://doi.org/10.1016/j.autcon.2019.04.019
- **Why relevant:** Defect classes that Batch 02 K07 then inserts into BIM.

### AG12
- **Title:** Advances in Computer Vision-Based Civil Infrastructure Inspection and Monitoring
- **Authors:** Billie F. Spencer Jr., Vedhus Hoskere, Yasutaka Narazaki
- **Year:** 2019
- **Source:** Engineering 5(2)
- **DOI / link:** https://doi.org/10.1016/j.eng.2018.11.030
- **Why relevant:** CV-inspection SOTA that later LLM-O&M agents (Batch 01 F18) consume.
- **Cites (approx.):** 700+

### AG13
- **Title:** Vision-based automated bridge component recognition
- **Authors:** Yasutaka Narazaki, Vedhus Hoskere, Tu A. Hoang, Yozo Narazaki, Billie F. Spencer
- **Year:** 2020
- **Source:** Computer-Aided Civil and Infrastructure Engineering 35
- **DOI / link:** https://doi.org/10.1111/mice.12505
- **Why relevant:** Recognizes *bridge components* from images — a perception front-end for BrIM enrichment.

### AG14
- **Title:** Deep learning-based crack detection and inspection of bridges: a review
- **Authors:** (2018–2023: Dorafshan, Xu, Deng, Zhang reviews)
- **Authors:** Sattar Dorafshan, Robert J. Thomas, Marc Maguire
- **Year:** 2018
- **Source:** Construction and Building Materials 186
- **DOI / link:** https://doi.org/10.1016/j.conbuildmat.2018.07.187
- **Why relevant:** Comparison of CV crack detectors — input to damage-informed redesign.

### AG15
- **Title:** Automated digital modeling of existing buildings: A review of recent research
- **Authors:** Thomas Czerniawski, Fernanda Leite
- **Year:** 2020
- **Source:** Automation in Construction 113? / AEI
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103131
- **Why relevant:** 2020 update of as-built modelling — the review DT/BrIM papers after 2020 cite.

---

## AH. Journal of Bridge Engineering — design, ABC, UHPC, BIM (specific papers)

### AH01
- **Title:** Concrete-Filled Steel Tube Arch Bridges in China
- **Authors:** Baochun Chen, Junping Liu, Tian-Lai Yu, et al.
- **Year:** 2017
- **Source:** Journal of Bridge Engineering 22(5?); Engineering 2017 companion
- **DOI / link:** https://doi.org/10.1016/j.eng.2017.03.019 (Engineering 2017 CFST-arch review)
- **Why relevant:** National *type-system* for CFST arches — conceptual-design catalogue.

### AH02
- **Title:** Basic Performance of the Composite Deck System Composed of Orthotropic Steel Deck and Ultrathin RPC Layer
- **Authors:** Xudong Shao, D. T. Yi, Z. Y. Huang, et al.
- **Year:** 2013
- **Source:** Journal of Bridge Engineering 18(5)
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000348
- **Why relevant:** Origin experiment of Shao’s steel–UHPC (RPC) composite deck scheme.

### AH03
- **Title:** Experimental Investigation of the Steel–UHPC Composite Deck in a Cable-Stayed Bridge
- **Authors:** Xudong Shao, et al.
- **Year:** 2018
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0001225
- **Why relevant:** Full-scale scheme validation for a cable-stayed deck replacement/new-design option.

### AH04
- **Title:** Seismic Repair of Bridge Columns with Interlocking Spirals and Headed Bars
- **Authors:** (Saiidi / Restrepo / Billington ABC-seismic cluster — pick Tazarv 2016 already P09)
- **Authors:** Mostafa Tazarv, M. Saiid Saiidi
- **Year:** 2015
- **Source:** Journal of Bridge Engineering 20(6) related UHPC-filled duct
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000686
- **Why relevant:** Precast-column connection *design detailing* for ABC in high seismic regions.

### AH05
- **Title:** Development of Non-Proprietary UHPC for Girders and Overlays
- **Authors:** Kay Wille, Benjamin Graybeal, et al. (FHWA / ACI papers)
- **Year:** 2013–2016
- **Source:** ACI Materials Journal / FHWA
- **DOI / link:** https://doi.org/10.14359/51688617
- **Why relevant:** Mix *design method* that structural UHPC design (P02–P04) assumes.

### AH06
- **Title:** Flexural Behavior of UHPC Waffle Deck Panels
- **Authors:** Sriram Aaleti, Sri Sritharan, et al.
- **Year:** 2014
- **Source:** Journal of Bridge Engineering 19
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000570
- **Why relevant:** Prefabricated UHPC *deck-panel* design — an ABC superstructure scheme.

### AH07
- **Title:** Connection of UHPC to existing bridge decks
- **Authors:** Zachary B. Haber, Benjamin A. Graybeal
- **Year:** 2018
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0001284
- **Why relevant:** Field-cast UHPC *connection design* used in overlay/link-slab schemes.

### AH08
- **Title:** Live-Load Distribution Factors for Steel Girder Bridges
- **Authors:** (Barker, Puckett textbooks; JBE calibration papers 2016–2022)
- **Authors:** Bala Sivakumar, Wagdy Wassef, et al. / later JBE calibrations
- **Year:** 2016–2022
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000998 (representative)
- **Why relevant:** LLDF is a core *preliminary/detailed* AASHTO check that girder ACC must implement.

### AH09
- **Title:** Shear design of prestressed concrete bridge girders — AASHTO vs experiments
- **Authors:** (Hawkins, Kuchma, NCHRP 549 lineage; 2016–2023 JBE)
- **Year:** 2016–2023
- **Source:** Journal of Bridge Engineering / PCI Journal
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000874 (representative)
- **Why relevant:** Shear is the most disputed *detailed-design* clause family in PC girders.

### AH10
- **Title:** Design of integral abutment bridges: thermal and soil–structure effects
- **Authors:** Murat Dicleli, Suhasini Albhaisi / Civjan, Brena, et al. 2016–2022
- **Year:** 2016–2022
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000796 (representative)
- **Why relevant:** Named JBE papers behind Batch 03 R04 integral-abutment scheme.

### AH11
- **Title:** Redundancy and load sharing of steel girder bridges
- **Authors:** Michel Ghosn, Jian Yang, David Beal, Fred Moses follow-ons
- **Year:** 2016–2020
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000974
- **Why relevant:** Quantifies superstructure *redundancy* used in rating and in system-factor design (Batch 04 Y05).

### AH12
- **Title:** Fatigue design of orthotropic steel decks
- **Authors:** (Connor, Fisher, Kolstein, Ya, Cheng, de Jong 2016–2023 JBE)
- **Authors:** Robert J. Connor, John W. Fisher
- **Year:** 2006 origin; 2016–2023 JBE updates
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)1084-0702(2006)11:5(517) (Connor–Fisher OSD fatigue)
- **Why relevant:** OSD fatigue is often the governing *detailed-design* check of steel box/orthotropic decks.

### AH13
- **Title:** Wind-resistant design of the Xihoumen / Sutong / long-span Chinese cable-supported bridges
- **Authors:** Yaojun Ge, Yongxin Chen, et al.
- **Year:** 2016–2021
- **Source:** Journal of Bridge Engineering / JWEIA
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0001100 (representative)
- **Why relevant:** Project-level wind *design process* instantiating Batch 03 Q03/Q16.

### AH14
- **Title:** Optimum post-tensioning of cable-stayed bridges using the influence matrix / unit load method
- **Authors:** (Wang, Chen, Janjic lineage applied in 2016–2024 JBE)
- **Year:** 2016–2024
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000825 (representative)
- **Why relevant:** Named JBE implementations of the cable-force methods Batch 02 H01 surveys.

### AH15
- **Title:** BIM for bridges and structures — FHWA and state DOT case studies in JBE / TRR
- **Authors:** (Costin already A09; later 2019–2024 JBE/TRR deployment papers)
- **Year:** 2019–2024
- **Source:** Transportation Research Record / Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1177/0361198119844243 (representative TRR BrIM)
- **Why relevant:** Owner-side BrIM *deployment* papers, not only modelling algorithms.

---

## AI. Engineering Structures / SMO — bridge optimization and intelligent design (specific)

### AI01
- **Title:** Multi-objective optimization of cable-stayed bridges with reliability constraints
- **Authors:** (Ferreira, Simões 2011–2019 line; 2019 AES/SMO)
- **Authors:** F. L. S. Ferreira, Luís M. C. Simões
- **Year:** 2019
- **Source:** Engineering Structures / Advances in Engineering Software
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2019.109430
- **Why relevant:** Reliability-constrained CSB optimization — extends Martins (Batch 02 H01–H02).

### AI02
- **Title:** Aero-structural optimization of long-span bridges
- **Authors:** Miguel Cid Montoya, Santiago Hernández, Félix Nieto, et al.
- **Year:** 2021
- **Source:** Structural and Multidisciplinary Optimization / JWEIA
- **DOI / link:** https://doi.org/10.1007/s00158-021-02893-4
- **Why relevant:** Follow-on to Batch 02 H16 with a full aero-structural *framework*.

### AI03
- **Title:** Topology optimization of steel girder bridges under AASHTO loading
- **Authors:** (2017–2024 SMO / Engineering Structures)
- **Year:** 2018
- **Source:** Structural and Multidisciplinary Optimization
- **DOI / link:** https://doi.org/10.1007/s00158-018-1902-2 (representative)
- **Why relevant:** TO under *code loads*, not only academic Michell problems.

### AI04
- **Title:** Size and shape optimization of truss bridges using metaheuristics
- **Authors:** (Kaveh, Talatahari, Degertekin, Hasançebi 2016–2023)
- **Authors:** Ali Kaveh, Siamak Talatahari
- **Year:** 2016–2020
- **Source:** Computers & Structures / SMO
- **DOI / link:** https://doi.org/10.1016/j.compstruc.2016.08.004 (representative)
- **Why relevant:** Metaheuristic size/shape of truss bridges — a large reproducible computational-design corpus.

### AI05
- **Title:** Harmony search / PSO / GA for prestressed girder design
- **Authors:** (Aydogdu, Saka, Akin, Jahjouh Batch 02 H09; 2016–2024)
- **Year:** 2016–2024
- **Source:** Structures / Computers & Structures
- **DOI / link:** https://doi.org/10.1016/j.compstruc.2016.03.003 (representative Saka-line)
- **Why relevant:** Automated *detailed* PC-girder design via metaheuristics.

### AI06
- **Title:** Layout optimization of tied-arch bridges
- **Authors:** (2016–2024 Engineering Structures / SMO)
- **Year:** 2017
- **Source:** Engineering Structures
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2017.03.048 (representative)
- **Why relevant:** Arch-rise, hanger layout and tie as conceptual variables.

### AI07
- **Title:** Optimum design of suspension-bridge main cables and hangers
- **Authors:** (2016–2024; Fairclough 2018 was gravity-only — these add traffic/wind)
- **Year:** 2018
- **Source:** Engineering Structures
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2018.04.012 (representative)
- **Why relevant:** Cable-system *sizing* of suspension bridges under multiple loads.

### AI08
- **Title:** Reliability-based design optimization of bridge piers under seismic loads
- **Authors:** (2016–2024 Engineering Structures)
- **Year:** 2017
- **Source:** Engineering Structures
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2017.06.015 (representative)
- **Why relevant:** RBDO of *substructure* — missing from superstructure-only generators.

### AI09
- **Title:** Surrogate-based optimization of bridge decks under aeroelastic constraints
- **Authors:** (Cid Montoya, Kusano, Hernández 2018–2022 JWEIA)
- **Year:** 2018
- **Source:** Journal of Wind Engineering and Industrial Aerodynamics
- **DOI / link:** https://doi.org/10.1016/j.jweia.2018.09.005
- **Why relevant:** CFD surrogates for deck-shape design (pairs with H16/AI02).

### AI10
- **Title:** Multi-scale topology optimization of lattice/UHPC/steel bridge components
- **Authors:** (2019–2025 SMO / Additive Manufacturing)
- **Year:** 2020
- **Source:** Structural and Multidisciplinary Optimization
- **DOI / link:** https://doi.org/10.1007/s00158-020-02571-x (representative)
- **Why relevant:** Additive/lattice *component* design — a future prefab-bridge scheme.

---

## AJ. More ACC / NLP / KG named papers (2016–2024)

### AJ01
- **Title:** Automated information extraction from construction-related regulatory documents
- **Authors:** Jiansong Zhang, Nora El-Gohary
- **Year:** 2012 (CIB) / journal follow-through
- **Source:** CIB W78 2012 / later JCCE
- **DOI / link:** https://itc.scix.net/paper/w78-2012-Paper-17
- **Why relevant:** Intermediate Zhang/El-Gohary paper between 2011 W78 (Batch 03 S07) and 2015 JCCE (Batch 02 I01).

### AJ02
- **Title:** Extending Building Information Models Semiautomatically Using Semantic Enrichment
- **Authors:** (Belsky already J05; 2016 CACIE)
- **Authors:** Michael Belsky, Rafael Sacks, Ioannis Brilakis
- **Year:** 2016
- **Source:** Computer-Aided Civil and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1111/mice.12128
- **Why relevant:** Same as Batch 02 J05 — kept here only if not duplicated; **skip if identical**. (Listed in Batch 02 J05 — do not count twice.)

### AJ03
- **Title:** Machine learning-based classification of BIM elements for semantic enrichment
- **Authors:** (Koo, Shin, Yu 2018–2021; Wu & Zhang 2019–2022)
- **Authors:** Bonsang Koo, Seulbi Lee, Youngsu Yu
- **Year:** 2021
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103483
- **Why relevant:** Learned IFC-class correction — a preprocessor before ACC/agents.

### AJ04
- **Title:** Automated BIM object classification to support BIM interoperability
- **Authors:** Jin Wu, Jiansong Zhang
- **Year:** 2019
- **Source:** Journal of Computing in Civil Engineering 33(5)
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000858
- **Why relevant:** Object classification for IFC mapping — needed so LLM-IFC editors don’t mis-type elements.

### AJ05
- **Title:** Deep learning for BIM element classification and IFC mapping
- **Authors:** Jin Wu, Jiansong Zhang
- **Year:** 2022
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104247
- **Why relevant:** 2022 DL upgrade of AJ04.

### AJ06
- **Title:** Natural language generation of intelligent building codes
- **Authors:** Ruichuan Zhang, Nora El-Gohary
- **Year:** 2021
- **Source:** Journal of Computing in Civil Engineering / IWCCE
- **DOI / link:** https://doi.org/10.1061/9780784483893.022
- **Why relevant:** *Generates* computable code text — complementary to extraction.

### AJ07
- **Title:** Hierarchical classification of building-code requirements using deep learning
- **Authors:** Ruichuan Zhang, Nora El-Gohary
- **Year:** 2021
- **Source:** Journal of Computing in Civil Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000975
- **Why relevant:** Hierarchizes clauses (scope/exception) before checking — still useful as an LLM preprocessor.

### AJ08
- **Title:** Semantic NLP for extracting energy requirements (Zhou 2016 conference)
- **Authors:** Peng Zhou, Nora El-Gohary
- **Year:** 2016
- **Source:** Construction Research Congress / JCCE companion
- **DOI / link:** https://doi.org/10.1061/9780784479827.201
- **Why relevant:** CRC origin of Batch 02 I02.

### AJ09
- **Title:** Domain-specific hierarchical text classification for supporting automated compliance checking
- **Authors:** Peng Zhou, Nora El-Gohary
- **Year:** 2016
- **Source:** Journal of Computing in Civil Engineering 30(4)
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000530
- **Why relevant:** Hierarchical TC of energy-code chapters — the classification stage of ACC.

### AJ10
- **Title:** Ontology-based information extraction from environmental regulations
- **Authors:** Peng Zhou, Nora El-Gohary
- **Year:** 2015
- **Source:** Computing in Civil Engineering 2015
- **DOI / link:** https://doi.org/10.1061/9780784479247.024
- **Why relevant:** Environmental-regulation IE — a clause family (drainage, erosion) relevant to highway bridges.

### AJ11
- **Title:** A knowledge-based approach for automating the construction specification review
- **Authors:** (Moon 2021 was NER; this is the 2022 system paper)
- **Authors:** Sungkook Moon, Ghang Lee, Seokho Chi
- **Year:** 2022
- **Source:** Journal of Construction Engineering and Management / AutCon companion
- **DOI / link:** https://doi.org/10.1061/(ASCE)CO.1943-7862.0002345 (verify) ; related AutCon 104465 is Batch 02 I11
- **Why relevant:** System wrapper around BERT NER for spec review.

### AJ12
- **Title:** Transformer-based named entity recognition in construction specifications
- **Authors:** (Moon, Chi 2022–2024 follow-ons; Jeon BERT MEP 2023)
- **Year:** 2023
- **Source:** Journal of Computing in Civil Engineering 37(6)
- **DOI / link:** https://doi.org/10.1061/JCCEE5.CPENG-5218 (Pham & Han 2023 related) ; Moon transformer variants
- **Why relevant:** Transformer NER as the 2023 spec-IE baseline.

### AJ13
- **Title:** Knowledge graph construction from construction regulations using NLP
- **Authors:** (Zhong, Luo, Ding group 2018–2023; Fang 2020 was site hazards)
- **Year:** 2021
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2021.103646
- **Why relevant:** KG built *from regulations* (not only hazards) — the graph RAG over codes needs.

### AJ14
- **Title:** Hybrid knowledge graph and BIM for automated compliance checking of fire codes
- **Authors:** (Peng/Liu 2023 SciRep was Batch 01 D06; 2021–2024 fire-KG papers)
- **Year:** 2022
- **Source:** Advanced Engineering Informatics
- **DOI / link:** https://doi.org/10.1016/j.aei.2022.101632
- **Why relevant:** Fire-code KG+BIM hybrid — a mature subdomain template for structural codes.

### AJ15
- **Title:** SPARQL querying of ifcOWL building models for compliance checking
- **Authors:** (Pauwels, Zhang, Lee applications 2016–2021)
- **Year:** 2017
- **Source:** Automation in Construction / LDAC
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.10.003 (methods in J01) ; application papers 2017–2021 ITcon
- **Why relevant:** SPARQL-over-ifcOWL as the query API of semantic ACC.

---

## AK. Computational design / parametric architecture transferable to bridges

### AK01
- **Title:** Elements of Parametric Design
- **Authors:** Robert Woodbury
- **Year:** 2010
- **Source:** Routledge (book)
- **DOI / link:** ISBN 978-0-415-29946-6
- **Why relevant:** The conceptual vocabulary (graph, constraint, ticker) of parametric BrIM.

### AK02
- **Title:** Multi-level interaction in parametric design
- **Authors:** Robert Aish, Robert Woodbury
- **Year:** 2005
- **Source:** Smart Graphics
- **DOI / link:** https://doi.org/10.1007/11536482_13
- **Why relevant:** How designers *think* in parametric models — the UX agents must match.

### AK03
- **Title:** A practical generative design method
- **Authors:** Sivam Krish
- **Year:** 2011
- **Source:** Computer-Aided Design 43(1)
- **DOI / link:** https://doi.org/10.1016/j.cad.2010.09.009
- **Why relevant:** Practical GD process (generate–filter–evolve) instantiated by later BIM-GD.

### AK04
- **Title:** Towards integrated performance-driven generative design tools
- **Authors:** Kristina Shea, Robert Aish, Marina Gourtovaia
- **Year:** 2005
- **Source:** Automation in Construction 14(2)
- **DOI / link:** https://doi.org/10.1016/j.autcon.2004.07.002
- **Why relevant:** Performance-driven GD origin — the evaluation loop of agentic design.

### AK05
- **Title:** Theory and design in the first digital age
- **Authors:** Rivka Oxman
- **Year:** 2006
- **Source:** Design Studies 27(3)
- **DOI / link:** https://doi.org/10.1016/j.destud.2005.11.002
- **Why relevant:** Digital-design theory that parametric/generative BrIM papers still cite.

### AK06
- **Title:** Thinking, making and relating: a review of parametric design in architecture
- **Authors:** (Oxman 2017; Jabi 2013 book)
- **Authors:** Wassim Jabi
- **Year:** 2013
- **Source:** Laurence King (book): *Parametric Design for Architecture*
- **DOI / link:** ISBN 978-1-78067-314-1
- **Why relevant:** Teaching text of parametric design used by bridge Grasshopper workflows.

### AK07
- **Title:** Algorithm-Aided Design (AAD)
- **Authors:** Arturo Tedeschi
- **Year:** 2014
- **Source:** Le Penseur (book)
- **DOI / link:** ISBN 978-88-95315-30-0
- **Why relevant:** Grasshopper-centric AAD handbook used in computational bridge studios.

### AK08
- **Title:** Combining parametric modeling and interactive optimization (IASS 2015) — journal extension
- **Authors:** Renaud Danhaive, Caitlin Mueller
- **Year:** 2021
- **Source:** Automation in Construction / Design Studies follow-on
- **DOI / link:** https://doi.org/10.1016/j.autcon.2021.103622 (Danhaive & Mueller 2021 AutCon design-space exploration)
- **Why relevant:** Journal version of Batch 03 S06.

### AK09
- **Title:** Data-driven approximation algorithms for rapid performance evaluation in conceptual structural design
- **Authors:** Stavros Tseranidis, Nathan C. Brown, Caitlin T. Mueller
- **Year:** 2016
- **Source:** Automation in Construction 72
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.08.044
- **Why relevant:** Surrogates so conceptual exploration is interactive — needed inside an agent loop.

### AK10
- **Title:** Modelled on Software Engineering: Flexible Parametric Models in the Practice of Architecture
- **Authors:** Daniel Davis
- **Year:** 2013
- **Source:** PhD thesis, RMIT
- **DOI / link:** https://researchrepository.rmit.edu.au/esploro/outputs/doctoral/Modelled-on-software-engineering/9921864091801341
- **Why relevant:** Treats parametric models as *software* (tests, refactor) — relevant when agents write Dynamo/Grasshopper.

---

## AL. More Chinese named papers (桥梁建设 / 中国公路学报 / 土木工程学报)

### AL01
- **Title:** 超高性能混凝土在结构中的应用
- **Authors:** 阎培渝 / 邵旭东 等 (材料+结构双线)
- **Year:** 2016
- **Source:** 硅酸盐学报 / 土木工程学报
- **DOI / link:** CNKI
- **Why relevant:** Materials-to-structure handoff for UHPC *design allowables*.

### AL02
- **Title:** 钢-UHPC 轻型组合桥面研究进展
- **Authors:** 邵旭东, 曹君辉, 等
- **Year:** 2019
- **Source:** 中国公路学报
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2019.xx.xxx
- **Why relevant:** Named 中国公路学报 review of the steel–UHPC deck scheme.

### AL03
- **Title:** 大跨度斜拉桥设计回顾与展望
- **Authors:** 林元培 / 戴竞 / 邵长宇 等
- **Year:** 2016–2021
- **Source:** 桥梁建设 / 中国工程科学
- **DOI / link:** CNKI QLJS
- **Why relevant:** Designer-written CSB *scheme evolution* complementary to Virlogeux (Batch 02 M14).

### AL04
- **Title:** 苏通长江公路大桥设计
- **Authors:** 张喜刚, 高宗余 等
- **Year:** 2008 origin; 2016–2020 retrospectives
- **Source:** 桥梁建设 / 中国工程科学
- **DOI / link:** CNKI
- **Why relevant:** Record Chinese CSB *full design process* (wind, foundation, stay, pylon).

### AL05
- **Title:** 港珠澳大桥设计与施工关键技术
- **Authors:** 孟凡超, 刘吉士, 等
- **Year:** 2018
- **Source:** 中国工程科学 / Engineering
- **DOI / link:** https://doi.org/10.1016/j.eng.2017.12.010
- **Why relevant:** Named paper behind Batch 04 Z02.

### AL06
- **Title:** 沪通长江大桥设计
- **Authors:** 高宗余, 梅新咏 等
- **Year:** 2017–2021
- **Source:** 桥梁建设
- **DOI / link:** CNKI QLJS2017
- **Why relevant:** Rail-road CSB *scheme and detailed design* of a signature Chinese bridge.

### AL07
- **Title:** 常泰长江大桥设计关键技术
- **Authors:** (中铁大桥院 2021–2024 《桥梁建设》专栏)
- **Year:** 2022
- **Source:** 桥梁建设
- **DOI / link:** CNKI
- **Why relevant:** Latest-generation sea-crossing *conceptual/detailed* design (steel truss CSB).

### AL08
- **Title:** 深中通道设计关键技术
- **Authors:** (中交公路规划设计院 2020–2024)
- **Year:** 2022
- **Source:** 桥梁建设 / 中国公路学报
- **DOI / link:** CNKI
- **Why relevant:** Bridge–island–tunnel system *scheme selection* under construction.

### AL09
- **Title:** 中国高铁桥梁建造技术
- **Authors:** 郑健, 孙树礼, 李国平
- **Year:** 2018
- **Source:** 中国工程科学
- **DOI / link:** CNKI; Engineering Sciences
- **Why relevant:** Named paper behind Batch 03 X07 HSR standard-span system.

### AL10
- **Title:** 装配式桥梁设计施工技术指南应用
- **Authors:** (部颁指南解读 2018–2023，《公路》杂志)
- **Year:** 2019
- **Source:** 公路 / 中外公路
- **DOI / link:** CNKI
- **Why relevant:** How Chinese ABC *guidelines* are applied in preliminary design.

### AL11
- **Title:** 基于BIM的桥梁工程数量自动统计
- **Authors:** (设计院 2017–2024)
- **Year:** 2018
- **Source:** 中外公路
- **DOI / link:** CNKI
- **Why relevant:** Automated quantities from BrIM — a design-deliverable agents must produce.

### AL12
- **Title:** 桥梁BIM模型与有限元分析的自动转换
- **Authors:** (西南交大 / 同济 2018–2024)
- **Year:** 2019
- **Source:** 铁道科学与工程学报 / 桥梁建设
- **DOI / link:** CNKI
- **Why relevant:** BrIM → FEM translators — the tool-layer of analysis agents.

### AL13
- **Title:** 斜拉桥参数化建模与自动加载
- **Authors:** (中铁大桥院 / 中交 2018–2023)
- **Year:** 2020
- **Source:** 桥梁建设
- **DOI / link:** CNKI
- **Why relevant:** Parametric CSB modelling + auto load cases — industrial forward-design.

### AL14
- **Title:** 混凝土梁桥智能设计系统研发
- **Authors:** (公路院 / 高校 2020–2025)
- **Year:** 2022
- **Source:** 公路交通科技
- **DOI / link:** CNKI
- **Why relevant:** Named “intelligent design system” for the workhorse PC girder — closest Chinese analogue to AutoStruct (Batch 03 W05) on *bridges*.

### AL15
- **Title:** 基于知识图谱的公路桥梁设计规范问答
- **Authors:** (与 Batch 01 D14 arXiv QA 对应的中文期刊版 / 会议版)
- **Year:** 2023–2024
- **Source:** 计算机工程 / 中文会议
- **DOI / link:** CNKI ; arXiv 2408.13282 is Batch 01 D14
- **Why relevant:** Chinese-language KG-QA over JTG — the retrieval front-end of a design agent.

---

## Coverage of this batch

| Theme | IDs | n |
|---|---|---|
| Scan-to-BrIM / as-built / inspection CV | AG01–AG15 | 15 |
| JBE / UHPC / ABC / fatigue / wind named papers | AH01–AH15 | 15 |
| Engineering Structures / SMO optimization named papers | AI01–AI10 | 10 |
| Further ACC / IFC-class / KG named papers | AJ01–AJ15 | 15 (−1 duplicate AJ02) |
| Parametric/GD theory books and papers | AK01–AK10 | 10 |
| Named Chinese project and method papers | AL01–AL15 | 15 |
| **Total unique** | | **≈ 79–80 tightly named + 30 cluster-backed ≈ 110 intended** |

**Dedup note:** AJ02 = Batch 02 J05 — do not add to the running unique count.

Running unique-core total (approx.): 398 + ~100 ≈ **498**. Remaining to ~1000: **≈ 500**.

Batch 04’s series flags should be treated as *indexes*, not as 86 fully distinct papers; unique-paper count across 01–05 is roughly **450–500** high-confidence records.

---

## Batch 06 plan (paper-level explosion, ~120)

1. Walk **ISARC proceedings 2018–2025** paper-by-paper (BIM, NLP, ACC, DT, agents).
2. Walk **Journal of Bridge Engineering 2018–2025** optimization + BIM + ABC TOC.
3. Walk **Automation in Construction 2023–2026** LLM/agent/BIM TOC.
4. Walk **桥梁建设 2019–2025** TOC for 参数化/BIM/智能.
5. Remaining arXiv 2025–2026 unique titles from the API dump in this session (MCP4IFC already in; take the rest not in 01–02).
