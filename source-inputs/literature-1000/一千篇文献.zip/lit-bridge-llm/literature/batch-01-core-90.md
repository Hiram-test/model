# Batch 01 — Core literature (90 items)

Scope: bridge design methods/process + intelligent/automated/generative design + LLM/multi-agent/Agentic AI in structural/civil/bridge/BIM + parametric BIM and automated code compliance.

Priority: 2016–2026; extra weight on 2023+ LLM/agent work. English-first, with key Chinese sources.

Citation counts are approximate Google Scholar / Crossref snapshots (2026) and are only for ranking, not exact.

---

## A. Landmark reviews, handbooks, and method foundations

### A01
- **Title:** BIM Handbook: A Guide to Building Information Modeling for Owners, Designers, Engineers, Contractors, and Facility Managers (3rd ed.)
- **Authors:** Rafael Sacks, Charles Eastman, Ghang Lee, Paul Teicholz
- **Year:** 2018
- **Source:** Wiley (book)
- **DOI / link:** https://doi.org/10.1002/9781119287568
- **Why relevant:** Definitive reference on BIM process, information exchange and design-to-construction workflows that later BrIM and agentic BIM systems sit on.
- **Cites (approx.):** 2000+

### A02
- **Title:** Automatic rule-based checking of building designs
- **Authors:** Charles Eastman, Jae-min Lee, Yeon-suk Jeong, Jin-kook Lee
- **Year:** 2009
- **Source:** Automation in Construction 18(8)
- **DOI / link:** https://doi.org/10.1016/j.autcon.2009.07.002
- **Why relevant:** Canonical process model of automated code checking (rule interpretation → building-model query → checking → reporting); still the backbone of ACC and LLM-ACC papers.
- **Cites (approx.):** 1100+

### A03
- **Title:** Roles of artificial intelligence in construction engineering and management: A critical review and future trends
- **Authors:** Yue Pan, Limao Zhang
- **Year:** 2021
- **Source:** Automation in Construction 122, 103517
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103517
- **Why relevant:** Highest-cited recent map of AI in CEM; frames language-based reasoning as a future direction that LLM/agent papers now occupy.
- **Cites (approx.):** 1700+

### A04
- **Title:** Emerging artificial intelligence methods in structural engineering
- **Authors:** Hadi Salehi, Rigoberto Burgueño
- **Year:** 2018
- **Source:** Engineering Structures 171, 170–189
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2018.05.084
- **Why relevant:** Foundational survey of ML/pattern recognition for structural engineering before generative AI and LLMs.
- **Cites (approx.):** 1400+

### A05
- **Title:** Machine learning for structural engineering: A state-of-the-art review
- **Authors:** Huu-Tai Thai
- **Year:** 2022
- **Source:** Structures 38, 448–491
- **DOI / link:** https://doi.org/10.1016/j.istruc.2022.02.003
- **Why relevant:** Comprehensive ML survey covering design, analysis, SHM and optimization — the pre-LLM technical baseline for automated structural design.
- **Cites (approx.):** 900+

### A06
- **Title:** Machine learning applications for building structural design and performance assessment: State-of-the-art review
- **Authors:** Han Sun, Henry V. Burton, Honglan Huang
- **Year:** 2021
- **Source:** Journal of Building Engineering 33, 101816 (PII S2352710220334495)
- **DOI / link:** https://doi.org/10.1016/j.jobe.2020.101816
- **Why relevant:** Focused review of ML specifically for *structural design* (not just SHM), closest pre-LLM analogue to generative/automated design.
- **Cites (approx.):** 700+

### A07
- **Title:** Generative AI design for building structures
- **Authors:** Wenjie Liao, Xinzheng Lu, Yifan Fei, Yi Gu, Yuli Huang
- **Year:** 2024
- **Source:** Automation in Construction 157, 105187
- **DOI / link:** https://doi.org/10.1016/j.autcon.2023.105187
- **Why relevant:** Current canonical review of generative AI for structural design (GAN/GNN/diffusion); the direct precursor to LLM-controlled design systems.
- **Cites (approx.):** 300+

### A08
- **Title:** GPT models in construction industry: Opportunities, limitations, and a use case validation
- **Authors:** Abdullahi Saka, Ridwan Taiwo, et al.
- **Year:** 2024
- **Source:** Developments in the Built Environment 17, 100300
- **DOI / link:** https://doi.org/10.1016/j.dibe.2023.100300
- **Why relevant:** Early, highly cited industry-wide mapping of GPT/LLM use cases across the project lifecycle, including design assistance.
- **Cites (approx.):** 300+

### A09
- **Title:** Building Information Modeling (BIM) for transportation infrastructure — Literature review, applications, challenges, and recommendations
- **Authors:** Aaron Costin, Alireza Adibfar, Hanjin Hu, Stephen S. Chen
- **Year:** 2018
- **Source:** Automation in Construction 94, 257–281
- **DOI / link:** https://doi.org/10.1016/j.autcon.2018.07.001
- **Why relevant:** Most-cited review of BIM for roads/bridges/rail; the BrIM research map.
- **Cites (approx.):** 680+

### A10
- **Title:** BIM for infrastructure: An overall review and constructor perspective
- **Authors:** Alex Bradley, Haijiang Li, Robert Lark, Simon Dunn
- **Year:** 2016
- **Source:** Automation in Construction 71, 139–157
- **DOI / link:** https://www.sciencedirect.com/science/article/pii/S092658051630173X
- **Why relevant:** Early systematic review of infrastructure BIM, including bridges, from a delivery/constructor angle.

### A11
- **Title:** The promise of automated compliance checking
- **Authors:** Robert Amor, Johannes Dimyadi
- **Year:** 2021
- **Source:** Developments in the Built Environment 5, 100039
- **DOI / link:** https://doi.org/10.1016/j.dibe.2020.100039
- **Why relevant:** Compact, highly cited statement of ACC goals, data requirements and remaining barriers — used by almost all later LLM-ACC papers.
- **Cites (approx.):** 220+

### A12
- **Title:** Artificial intelligence and smart vision for building and construction 4.0: Machine and deep learning methods and applications
- **Authors:** Shanaka Kristombu Baduge, Sadeep Thilakarathna, Jude Shalitha Perera, et al.
- **Year:** 2022
- **Source:** Automation in Construction 141, 104440
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104440
- **Why relevant:** Lifecycle survey including structural design/analysis; useful bridge from CV/DL to later generative/LLM work.

### A13
- **Title:** Large language models in smart construction: a systematic review of implementation strategies, applications and future directions
- **Authors:** (ECAM systematic review, 2020–2025 corpus)
- **Year:** 2025/2026
- **Source:** Engineering, Construction and Architectural Management
- **DOI / link:** https://www.emerald.com/ecam/article/33/15/159/1344000
- **Why relevant:** Latest systematic map of LLM implementation strategies in construction, including design and compliance.

---

## B. Traditional bridge design methods, conceptual and preliminary design

### B01
- **Title:** Forms and Aesthetics of Bridges
- **Authors:** Man-Chung Tang
- **Year:** 2018
- **Source:** Engineering 4(2)
- **DOI / link:** https://doi.org/10.1016/j.eng.2017.12.013
- **Why relevant:** Authoritative statement that conceptual design jointly determines structural system, aesthetics, cost and function — the “human” design process that agents must emulate.

### B02
- **Title:** Conceptual design of bridges
- **Authors:** Man-Chung Tang
- **Year:** 2017
- **Source:** Book chapter / TRID
- **DOI / link:** https://trid.trb.org/View/1458481
- **Why relevant:** Explicit process: generate feasible schemes → select one or more concepts for preliminary/detailed design.

### B03
- **Title:** Conceptual Design of Bridges
- **Authors:** Changyu Shao (邵长宇), Yongcheng Lu
- **Year:** 2016
- **Source:** Book (China Communications Press / related editions)
- **DOI / link:** (book; widely cited in Chinese conceptual-design literature)
- **Why relevant:** Chinese-language systematic treatment of bridge conceptual design — the traditional-methods line in CN practice.

### B04
- **Title:** Design of Highway Bridges: An LRFD Approach (3rd/4th ed.)
- **Authors:** Richard M. Barker, Jay A. Puckett
- **Year:** 2013 / later eds.
- **Source:** Wiley (textbook)
- **DOI / link:** ISBN 978-0-470-90066-6
- **Why relevant:** Standard English textbook of the AASHTO LRFD *design process* (loads, limit states, superstructure/substructure) used as the conventional baseline.

### B05
- **Title:** AASHTO LRFD Bridge Design Specifications
- **Authors:** AASHTO
- **Year:** 2017–2024 editions
- **Source:** Standard
- **DOI / link:** AASHTO publication (not a journal paper)
- **Why relevant:** The US code that automated compliance checkers and LLM-ACC systems for highway bridges try to operationalize.

### B06
- **Title:** Cable Supported Bridges: Concept and Design (3rd ed.)
- **Authors:** Niels J. Gimsing, Christos T. Georgakis
- **Year:** 2012
- **Source:** Wiley (book)
- **DOI / link:** https://doi.org/10.1002/9781119978237
- **Why relevant:** Canonical conceptual/preliminary design of cable-stayed and suspension bridges.

### B07
- **Title:** Conceptual Design of Modular Bridges Including Layout and Topology Optimization
- **Authors:** (ASCE Journal of Bridge Engineering)
- **Year:** 2017
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0001138
- **Why relevant:** Shows how conceptual design of modular bridges is formulated as layout/topology optimization — a computational counterpart of traditional scheme selection.

### B08
- **Title:** Automatic structural design by a set-based parametric design method
- **Authors:** Rasmus Rempling, et al.
- **Year:** 2019
- **Source:** Automation in Construction
- **DOI / link:** https://www.sciencedirect.com/science/article/pii/S0926580518303042
- **Why relevant:** Formalizes *set-based parametric design* for bridges, linking conceptual alternatives, buildability and sustainability.
- **Cites (approx.):** 95

### B09
- **Title:** A fuzzy integrated methodology for evaluating conceptual bridge design
- **Authors:** (Expert Systems with Applications)
- **Year:** 2010 (still widely cited in later DSS papers)
- **Source:** Expert Systems with Applications
- **DOI / link:** https://www.sciencedirect.com/science/article/abs/pii/S0957417409010707
- **Why relevant:** Classic multi-criteria decision method for conceptual bridge-type selection — the “traditional intelligent” line before ML/LLMs.

### B10
- **Title:** Proposal for an Integrated Decision Support System for Bridge Type Selection during the Conceptual Design Phase
- **Authors:** Elie Otayek, Ahmad Jrade, et al.
- **Year:** 2018
- **Source:** Thesis / related papers (Concordia)
- **DOI / link:** https://spectrum.library.concordia.ca/983478/
- **Why relevant:** Explicit DSS for *bridge type selection* at conceptual design — the decision problem agentic systems later try to automate.

### B11
- **Title:** Multi-criteria decision support system for bridge construction system selection utilizing value engineering and TOPSIS
- **Authors:** (Innovative Infrastructure Solutions)
- **Year:** 2023
- **Source:** Innovative Infrastructure Solutions
- **DOI / link:** https://doi.org/10.1007/s41062-023-01267-7
- **Why relevant:** Recent MCDM for *preliminary* construction-system selection of bridge decks.

### B12
- **Title:** Optimizing the superstructure configuration of highway bridges for sustainability
- **Authors:** (PLOS One / related)
- **Year:** 2024
- **Source:** journal article
- **DOI / link:** https://pmc.ncbi.nlm.nih.gov/articles/PMC10869906/
- **Why relevant:** DSS that chooses highway-bridge superstructure configuration — a computational preliminary-design pipeline.

### B13
- **Title:** 中国桥梁工程学术研究综述·2021
- **Authors:** 《中国公路学报》编辑部
- **Year:** 2021
- **Source:** 中国公路学报
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2021.03.001
- **Why relevant:** Authoritative Chinese state-of-the-art of bridge engineering (design, construction, SHM), the national baseline for “traditional + emerging” methods.

### B14
- **Title:** 中国桥梁工程学术研究综述·2024
- **Authors:** 《中国公路学报》编辑部
- **Year:** 2024
- **Source:** 中国公路学报
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2024.07.004 (verify issue)
- **Why relevant:** 2024 update covering structural design, disaster mitigation, green construction and intelligent O&M.

### B15
- **Title:** Literature review of bridge structure’s optimization and its applications
- **Authors:** Qasim Zaheer, et al.
- **Year:** 2022
- **Source:** International Journal for Simulation and Multidisciplinary Design Optimization
- **DOI / link:** https://www.ijsmdo.org/articles/smdo/full_html/2022/01/smdo210122/smdo210122.html
- **Why relevant:** Survey of size/shape/topology optimization as the computational core of traditional “optimal design” of bridges.

---

## C. BIM / BrIM, parametric modelling, IFC-Bridge, forward design

### C01
- **Title:** A parametric BIM approach to foster bridge project design and analysis
- **Authors:** Alexis Girardet, Conrad Boton
- **Year:** 2021
- **Source:** Automation in Construction 126, 103679
- **DOI / link:** https://doi.org/10.1016/j.autcon.2021.103679
- **Why relevant:** Single parametric file generating multiple bridge types and coupling geometry to analysis — the most-cited recent parametric-BrIM paper.
- **Cites (approx.):** 160

### C02
- **Title:** Review on parametric building information modelling and forward design approaches for sustainable bridge engineering
- **Authors:** S. Wu, et al.
- **Year:** 2025
- **Source:** Discover Applied Sciences
- **DOI / link:** https://doi.org/10.1007/s42452-025-06543-y
- **Why relevant:** 2025 review of parametric BIM *specifically for bridges*, including Dynamo/Grasshopper families and forward (正向) design.

### C03
- **Title:** The IFC-Bridge project – Extending the IFC standard to enable high-quality exchange of bridge information models
- **Authors:** André Borrmann, Sergej Muhic, et al.
- **Year:** 2019
- **Source:** EC3 / buildingSMART IFC-Bridge
- **DOI / link:** https://ec-3.org/publications/conference/paper/?id=EC32019_193
- **Why relevant:** The vendor-neutral data model (IFC-Bridge / IFC 4.3) that BIM automation, ACC and LLM tool-use all depend on.
- **Cites (approx.):** 80+

### C04
- **Title:** Application of 3D Bridge Information Modeling to Design and Construction of Bridges
- **Authors:** Chang-Su Shim, et al.
- **Year:** 2011
- **Source:** Procedia Engineering
- **DOI / link:** https://www.sciencedirect.com/science/article/pii/S1877705811011300
- **Why relevant:** Early BrIM case showing 3D information models used through design and construction — the origin paper of “BrIM”.

### C05
- **Title:** Integration of TLS-derived Bridge Information Modeling (BrIM) with a Decision Support System
- **Authors:** M. Mohammadi, et al.
- **Year:** 2023
- **Source:** Computers in Industry
- **DOI / link:** https://doi.org/10.1016/j.compind.2023.103869
- **Why relevant:** Recent BrIM definition and as-built integration; useful for later agentic O&M/design-as-built loops.
- **Cites (approx.):** 110+

### C06
- **Title:** Systematic Literature Review of Open Infrastructure BIM
- **Authors:** (Buildings)
- **Year:** 2023
- **Source:** Buildings 13(7), 1593
- **DOI / link:** https://doi.org/10.3390/buildings13071593
- **Why relevant:** OpenBIM/IFC for infrastructure including bridges; interoperability is a prerequisite for automated design agents.

### C07
- **Title:** 基于BIM技术的桥梁工程参数化智能建模技术
- **Authors:** 祝兵 等
- **Year:** 2022
- **Source:** 桥梁建设
- **DOI / link:** CNKI: QLJS202202003
- **Why relevant:** CATIA “skeleton + template” parametric intelligent modelling of bridges; representative Chinese forward-design method.

### C08
- **Title:** Parametric modeling and engineering application of a high-speed railway bridge
- **Authors:** H. Jiang, et al.
- **Year:** 2024
- **Source:** journal / PMC
- **DOI / link:** https://pmc.ncbi.nlm.nih.gov/articles/PMC11386460/
- **Why relevant:** Recent parametric modelling of a real high-speed-rail bridge, linking parameters to engineering delivery.

### C09
- **Title:** A streamlined parametric workflow for enhanced bridge design
- **Authors:** (Proceedings of the Institution of Civil Engineers – Bridge Engineering)
- **Year:** 2025/2026
- **Source:** ICE Bridge Engineering
- **DOI / link:** https://doi.org/10.1680/jbren.25.00038
- **Why relevant:** Practice-oriented parametric workflow for complex bridge geometry.

### C10
- **Title:** BIM技术在公路装配式桥梁方案设计中的应用研究
- **Authors:** (中外公路)
- **Year:** 2025
- **Source:** 中外公路
- **DOI / link:** https://zwgl.csust.edu.cn/zwgl/article/html/202501028
- **Why relevant:** Forward BIM for prefabricated highway-bridge *scheme design* (conceptual/preliminary), with automated quantity and pier positioning.

### C11
- **Title:** Building Information Modeling — Technology Foundations and Industry Practice
- **Authors:** André Borrmann, Markus König, Christian Koch, Jakob Beetz (eds.)
- **Year:** 2018
- **Source:** Springer (book)
- **DOI / link:** https://doi.org/10.1007/978-3-319-92862-3
- **Why relevant:** European technical foundation of BIM (geometry, IFC, ACC chapter by Preidel & Borrmann).

### C12
- **Title:** FHWA Building Information Modeling (BIM) for Bridges and Structures
- **Authors:** FHWA
- **Year:** 2021–2024
- **Source:** US DOT / FHWA program
- **DOI / link:** https://www.fhwa.dot.gov/bridge/bim/
- **Why relevant:** Official US program for BIM for bridges and structures (openBIM/IFC information exchange).

---

## D. Automated code / specification compliance (rule, NLP, KG — pre-LLM and hybrid)

### D01
- **Title:** Classification of rules for automated BIM rule checking development
- **Authors:** Wawan Solihin, Charles Eastman
- **Year:** 2015
- **Source:** Automation in Construction 53, 69–82
- **DOI / link:** https://doi.org/10.1016/j.autcon.2015.03.003
- **Why relevant:** Four-class taxonomy of checking rules still used to benchmark LLM-ACC difficulty.

### D02
- **Title:** Integrating semantic NLP and logic reasoning into a unified system for fully-automated code checking
- **Authors:** Jiansong Zhang, Nora M. El-Gohary
- **Year:** 2017
- **Source:** Automation in Construction 73, 45–57
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.08.027
- **Why relevant:** Landmark NLP + logic-reasoning ACC system; the technical ancestor of LLM-based regulation interpretation.
- **Cites (approx.):** 360+

### D03
- **Title:** Semantic NLP-based information extraction from construction regulatory documents for automated compliance checking
- **Authors:** Jiansong Zhang, Nora M. El-Gohary
- **Year:** 2016
- **Source:** Journal of Computing in Civil Engineering 30(2), 04015014
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000346
- **Why relevant:** Classic regulatory IE pipeline (POS, gazetteers, semantic mapping) that LLM-ACC papers compare against.

### D04
- **Title:** Towards code compliance checking on the basis of a visual programming language
- **Authors:** Cornelius Preidel, André Borrmann
- **Year:** 2016
- **Source:** ITcon 21, 402–421
- **DOI / link:** https://www.itcon.org/paper/2016/25
- **Why relevant:** Visual Code Checking Language (VCCL) — a transparent alternative to black-box hard-coded checkers.
- **Cites (approx.):** 150+

### D05
- **Title:** BIM-based Code Compliance Checking
- **Authors:** Cornelius Preidel, André Borrmann
- **Year:** 2018
- **Source:** Chapter in Borrmann et al., *Building Information Modeling* (Springer)
- **DOI / link:** https://doi.org/10.1007/978-3-319-92862-3_22
- **Why relevant:** Textbook-level synthesis of ACC architecture on BIM.

### D06
- **Title:** Automated code compliance checking research based on BIM and knowledge graph
- **Authors:** J. Peng, et al.
- **Year:** 2023
- **Source:** Scientific Reports 13
- **DOI / link:** https://doi.org/10.1038/s41598-023-34342-1
- **Why relevant:** KG + BIM ACC; the knowledge-graph layer later combined with LLMs.
- **Cites (approx.):** 110+

### D07
- **Title:** Automated Compliance Checking System for Structural Design Codes in a BIM Environment
- **Authors:** W. Goh, et al.
- **Year:** 2024
- **Source:** KSCE Journal of Civil Engineering
- **DOI / link:** https://doi.org/10.1007/s12205-024-1121-5
- **Why relevant:** ACC of *structural calculations* for a prestressed concrete girder *bridge* in openBIM — directly on-topic.

### D08
- **Title:** BIM, NLP, and AI for Automated Compliance Checking
- **Authors:** Ruichuan Zhang, Nora El-Gohary
- **Year:** 2022
- **Source:** Book chapter / NSF PAR
- **DOI / link:** https://par.nsf.gov/servlets/purl/10347911
- **Why relevant:** Concise review of BIM+NLP+AI ACC just before the LLM wave.

### D09
- **Title:** Using Large Language Models for the Interpretation of Building Regulations
- **Authors:** Stefan Fuchs, Michael Witbrock, Johannes Dimyadi, Robert Amor
- **Year:** 2024
- **Source:** arXiv / CIB W78 related
- **DOI / link:** https://arxiv.org/abs/2407.21060
- **Why relevant:** Direct LLM interpretation of building regulations by the leading ACC group (Amor/Dimyadi).

### D10
- **Title:** Large Language Model-Driven Code Compliance Checking in Building Information Modeling
- **Authors:** Soumya Madireddy, Lu Gao, Zia Din, Kinam Kim, et al.
- **Year:** 2025
- **Source:** arXiv 2506.20551
- **DOI / link:** https://arxiv.org/abs/2506.20551
- **Why relevant:** End-to-end LLM-driven ACC on BIM models.

### D11
- **Title:** Automated Checking of Highway Bridge BIM Models Based on Large Language Models
- **Authors:** Yongyi Yang, et al.
- **Year:** 2025
- **Source:** Buildings 15(19), 3465
- **DOI / link:** https://doi.org/10.3390/buildings15193465
- **Why relevant:** One of the first journal papers applying LLMs to *highway-bridge* specification parsing + IFC checking (rule extraction 79.5%, precision 84.4%).

### D12
- **Title:** Automating Geometry-Intensive Compliance Checking in BIM: Graph-Based Semantic Reasoning Framework
- **Authors:** Zixuan Xiao, Pei Troh Koh, Jun Ma, Jack C. P. Cheng
- **Year:** 2026
- **Source:** Automation in Construction / arXiv 2606.12065
- **DOI / link:** https://arxiv.org/abs/2606.12065
- **Why relevant:** Graph semantic reasoning for geometric ACC — the symbolic counterpart of LLM checkers.

### D13
- **Title:** A systematic review of methods for interpreting building code regulations in automated compliance systems
- **Authors:** N. Mirhosseini, et al.
- **Year:** 2026
- **Source:** Building Research & Information
- **DOI / link:** https://doi.org/10.1080/09613218.2026.2637965
- **Why relevant:** 2026 SLR covering rule-based, ontology, ML *and LLM* ACC — the newest panoramic review.

### D14
- **Title:** Question answering system of bridge design specification based on large language model
- **Authors:** Leye Zhang, Xiangxiang Tian, Hongjun Zhang
- **Year:** 2024
- **Source:** arXiv 2408.13282
- **DOI / link:** https://arxiv.org/abs/2408.13282
- **Why relevant:** LLM-QA over *bridge design specifications* — a retrieval/compliance frontend for automated design.

---

## E. Intelligent / automated / generative structural design (GAN, GNN, topology, parametric — pre-LLM core)

### E01
- **Title:** Intelligent design of shear wall layout based on graph neural networks
- **Authors:** Pengju Zhao, Wenjie Liao, Yuli Huang, Xinzheng Lu
- **Year:** 2023
- **Source:** Advanced Engineering Informatics 55, 101886
- **DOI / link:** https://doi.org/10.1016/j.aei.2023.101886
- **Why relevant:** GNN as a topology-aware generator of structural layouts; method family later wrapped by LLM controllers.
- **Cites (approx.):** 110+

### E02
- **Title:** Intelligent design of shear wall layout based on attention-enhanced generative adversarial networks
- **Authors:** Pengju Zhao, et al. / Xinzheng Lu group
- **Year:** 2023
- **Source:** Engineering Structures
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2022.115247 (StructGAN-AE line)
- **Why relevant:** GAN-based generative design of RC shear-wall layouts (~30× faster than manual), the main pre-LLM generative-design case.

### E03
- **Title:** Intelligent co-design of shear wall and beam layouts using a graph neural network
- **Authors:** Jikang Xia, Wenjie Liao, Bo Han, Shulu Zhang, Xinzheng Lu
- **Year:** 2025
- **Source:** Automation in Construction, 106024
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106024
- **Why relevant:** Coupled wall–beam co-design — closer to a full structural-scheme generator.

### E04
- **Title:** Intelligent design and optimization system for shear wall structures based on large language models and generative artificial intelligence
- **Authors:** Sizhong Qin, Hong Guan, Wenjie Liao, Yi Gu, Zhe Zheng, Hongjing Xue, Xinzheng Lu
- **Year:** 2024
- **Source:** Journal of Building Engineering 95, 109996
- **DOI / link:** https://doi.org/10.1016/j.jobe.2024.109996
- **Why relevant:** First widely cited *LLM-as-controller* + generative AI full-process structural design system.
- **Cites (approx.):** 110+

### E05
- **Title:** AIstructure-Copilot: assistant for generative AI-driven intelligent design of building structures
- **Authors:** Sizhong Qin, Wenjie Liao, Shengnan Huang, et al.
- **Year:** 2024
- **Source:** Smart Construction
- **DOI / link:** https://doi.org/10.55092/sc20240001
- **Why relevant:** Copilot-style interface on top of generative structural design; >10× efficiency claim with code-compliant schemes.

### E06
- **Title:** An attempt to generate new bridge types from latent space of variational autoencoder
- **Authors:** Hongjun Zhang
- **Year:** 2023
- **Source:** arXiv 2311.03380
- **DOI / link:** https://arxiv.org/abs/2311.03380
- **Why relevant:** Direct generative-model exploration of *new bridge types* — rare paper on generative design of bridge schemes.

### E07
- **Title:** Topology Optimization: A Review for Structural Designs
- **Authors:** T. Tang, et al.
- **Year:** 2024
- **Source:** Materials 17(23), 5970
- **DOI / link:** https://doi.org/10.3390/ma17235970
- **Why relevant:** Up-to-date TO review; TO is the classical “generative design” engine for bridges and frames.

### E08
- **Title:** Connecting architecture and engineering through structural topology optimization
- **Authors:** Lauren L. Beghini, Alessandro Beghini, Neil Katz, William F. Baker, Glaucio H. Paulino
- **Year:** 2014
- **Source:** Engineering Structures
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2013.11.008
- **Why relevant:** SOM/Baker line of topology optimization as conceptual structural design (including bridge-like forms).

### E09
- **Title:** Topology optimization of continuum structures: A review
- **Authors:** (classic; often cited: Sigmund & Maute 2013)
- **Authors:** Ole Sigmund, Kurt Maute
- **Year:** 2013
- **Source:** Structural and Multidisciplinary Optimization
- **DOI / link:** https://doi.org/10.1007/s00158-013-0978-6
- **Why relevant:** Methodological foundation of continuum topology optimization used in countless bridge conceptual-design studies.

### E10
- **Title:** Machine Learning in Structural Design: An Opinionated Review
- **Authors:** Christian Málaga-Chuquitaype
- **Year:** 2022
- **Source:** Frontiers in Built Environment
- **DOI / link:** https://doi.org/10.3389/fbuil.2022.815717
- **Why relevant:** Critical view of what ML can and cannot do in *design* (as opposed to prediction).

### E11
- **Title:** Applications of multi-agent systems from the perspective of construction management: A literature review
- **Authors:** Lei Xiang, et al.
- **Year:** 2022
- **Source:** Engineering, Construction and Architectural Management 29(9)
- **DOI / link:** https://doi.org/10.1108/ECAM-01-2021-0030
- **Why relevant:** Pre-LLM multi-agent systems in construction; historical context for 2024+ LLM-MAS.

### E12
- **Title:** Integrating generative and parametric design with BIM
- **Authors:** Á. Á. Semjén, et al.
- **Year:** 2025
- **Source:** journal article
- **DOI / link:** https://www.sciencedirect.com/science/article/pii/S2666496825000512
- **Why relevant:** 2025 synthesis of generative + parametric + BIM workflows.

---

## F. LLM, multi-agent and Agentic AI in structural / civil / bridge / BIM (2023–2026) — highest thematic fit

### F01
- **Title:** Text2BIM: Generating Building Models Using a Large Language Model-based Multi-Agent Framework
- **Authors:** Changyu Du, Sebastian Esser, Stavros Nousias, André Borrmann
- **Year:** 2024 (arXiv) / 2026 (JCCE)
- **Source:** Journal of Computing in Civil Engineering 40(2); arXiv 2408.08054
- **DOI / link:** https://doi.org/10.1061/JCCEE5.CPENG-6386 ; https://arxiv.org/abs/2408.08054
- **Why relevant:** Flagship LLM multi-agent BIM *generation* from natural language (TUM / Borrmann); the architectural analogue of automated bridge modelling.
- **Cites (approx.):** 100+

### F02
- **Title:** Towards a copilot in BIM authoring tool using a large language model-based agent for intelligent human-machine interaction
- **Authors:** Changyu Du, Stavros Nousias, André Borrmann
- **Year:** 2024
- **Source:** arXiv 2406.16903 / EG-ICE
- **DOI / link:** https://arxiv.org/abs/2406.16903
- **Why relevant:** LLM agent as BIM copilot (API tool-use), the interaction pattern later used by design agents.

### F03
- **Title:** BIMgent: Towards Autonomous Building Modeling via Computer-use Agents
- **Authors:** Zihan Deng, Changyu Du, Stavros Nousias, André Borrmann
- **Year:** 2025
- **Source:** arXiv 2506.07217
- **DOI / link:** https://arxiv.org/abs/2506.07217
- **Why relevant:** Moves from API-calling agents to *computer-use* agents that operate BIM software autonomously.

### F04
- **Title:** A Generalized LLM-Augmented BIM Framework: Application to a Speech-to-BIM system
- **Authors:** Ghang Lee, Suhyung Jang, Seokho Hyun
- **Year:** 2024
- **Source:** arXiv 2409.18345
- **DOI / link:** https://arxiv.org/abs/2409.18345
- **Why relevant:** General LLM-augmented BIM architecture (Lee/Yonsei); speech → BIM, reusable for bridge authoring.

### F05
- **Title:** Qwen-BIM: developing large language model for BIM-based design with domain-specific benchmark and dataset
- **Authors:** Jia-Rui Lin, Yun-Hong Cai, Xiang-Rui Ni, Shaojie Zhou
- **Year:** 2026
- **Source:** arXiv 2602.20812
- **DOI / link:** https://arxiv.org/abs/2602.20812
- **Why relevant:** Domain LLM + benchmark for BIM-based design (Tsinghua Lin Jiarui group).

### F06
- **Title:** A Modular Reference Architecture for MCP-Servers Enabling Agentic BIM Interaction
- **Authors:** Tobias Heimig-Elschner, Changyu Du, Anna Scheuvens, André Borrmann
- **Year:** 2025/2026
- **Source:** arXiv 2601.00809
- **DOI / link:** https://arxiv.org/abs/2601.00809
- **Why relevant:** MCP as the tool-protocol for agentic BIM (query/edit/generate) — infrastructure for future bridge-design agents.

### F07
- **Title:** Automating Structural Engineering Workflows with Large Language Model Agents (MASSE)
- **Authors:** Haoran Liang, Yufa Zhou, Mohammad Talebi-Kalaleh, Qipei Mei
- **Year:** 2025
- **Source:** arXiv 2510.11004
- **DOI / link:** https://arxiv.org/abs/2510.11004
- **Why relevant:** First named *multi-agent system for structural engineering* mirroring end-to-end design with safety/verification loops + SDAB/MASEB benchmarks.

### F08
- **Title:** Integrating Large Language Models for Automated Structural Analysis
- **Authors:** Haoran Liang, Mohammad Talebi Kalaleh, Qipei Mei
- **Year:** 2025
- **Source:** arXiv 2504.09754
- **DOI / link:** https://arxiv.org/abs/2504.09754
- **Why relevant:** LLM parses structural descriptions → executable analysis scripts; the analysis half of an automated design loop.

### F09
- **Title:** A Large Language Model-Empowered Agent for Reliable and Robust Structural Analysis
- **Authors:** Jiachen Liu, Ziheng Geng, Ran Cao, Lu Cheng, Paolo Bocchini, Minghui Cheng
- **Year:** 2025
- **Source:** arXiv 2507.02938
- **DOI / link:** https://arxiv.org/abs/2507.02938
- **Why relevant:** Reliability/robustness of an LLM agent generating and executing OpenSeesPy for beam/frame analysis.

### F10
- **Title:** A Lightweight Large Language Model-Based Multi-Agent System for 2D Frame Structural Analysis
- **Authors:** Ziheng Geng, Jiachen Liu, Ran Cao, Lu Cheng, et al.
- **Year:** 2025
- **Source:** arXiv 2510.05414
- **DOI / link:** https://arxiv.org/abs/2510.05414
- **Why relevant:** Role-specialized agents (problem, geometry, translation, validation, load) for FEM of 2D frames.

### F11
- **Title:** Agentic Large Language Models for Automated Structural Analysis of 3D Frame Systems
- **Authors:** Ziheng Geng, Ian Franklin, Santiago Martinez, Jiachen Liu, et al.
- **Year:** 2026
- **Source:** arXiv 2606.06525
- **DOI / link:** https://arxiv.org/abs/2606.06525
- **Why relevant:** Extends agentic analysis from 2D to 3D frames — closer to real bridge/building systems.

### F12
- **Title:** A Novel Multi-Agent Architecture to Reduce Hallucinations of Large Language Models in Multi-step Structural Modeling
- **Authors:** Ziheng Geng, Jiachen Liu, Ran Cao, Lu Cheng, et al.
- **Year:** 2026
- **Source:** arXiv 2603.07728
- **DOI / link:** https://arxiv.org/abs/2603.07728
- **Why relevant:** Directly attacks the central failure mode (hallucination/error accumulation) of multi-step structural modelling agents.

### F13
- **Title:** Verification-driven closed-loop multi-agent large language model framework for code-compliant structural design
- **Authors:** Jianbin Luo, Weibin Lin, Yiran Lin, Qing Wei, Wei Guo
- **Year:** 2026
- **Source:** arXiv 2608.07978
- **DOI / link:** https://arxiv.org/abs/2608.07978
- **Why relevant:** Closed-loop, *code-compliant* structural design with verification — closest to a full agentic design process.

### F14
- **Title:** Large Language Model Agent for Structural Drawing Generation Using ReAct Prompt Engineering and Retrieval Augmented Generation
- **Authors:** X. Zhang, et al.
- **Year:** 2025
- **Source:** arXiv 2507.19771
- **DOI / link:** https://arxiv.org/abs/2507.19771
- **Why relevant:** NL description → AutoCAD structural drawings via ReAct + RAG; covers the documentation/detailing stage of design.

### F15
- **Title:** Knowledge-driven automated prefabricated bridge modeling from natural language using LLM and RAG
- **Authors:** Fei Huang, Dapeng Mei, et al.
- **Year:** 2026
- **Source:** Scientific Reports
- **DOI / link:** https://www.nature.com/articles/s41598-026-53765-0
- **Why relevant:** **Directly on bridges:** AutoBIM converts natural-language instructions into compliant prefabricated-bridge BIM via LLM+RAG over a standard-component knowledge base.

### F16
- **Title:** Large language model driven BIM collaborative automatic trestle-bridge modeling technology
- **Authors:** F. Wu, et al.
- **Year:** 2026
- **Source:** Journal of Engineering and Applied Science
- **DOI / link:** https://doi.org/10.1186/s44147-026-01130-3
- **Why relevant:** LLM multi-agent automatic modelling of *trestle bridges* in Revit from natural language.

### F17
- **Title:** A Lightweight Multi-Agent Framework for Automated Concrete Barrier Design
- **Authors:** Wanting Wang, Xiye Ma, Yuyang He, Minghui Cheng
- **Year:** 2026
- **Source:** arXiv 2606.12040
- **DOI / link:** https://arxiv.org/abs/2606.12040
- **Why relevant:** Multi-agent automated design of a concrete barrier (highway/bridge ancillary structure) with code constraints.

### F18
- **Title:** Revolutionizing Bridge Operation and Maintenance with LLM-based Agents: An Overview of Applications and Insights
- **Authors:** Lianzhen Zhang, et al.
- **Year:** 2024
- **Source:** arXiv 2407.10064
- **DOI / link:** https://arxiv.org/abs/2407.10064
- **Why relevant:** First overview of LLM-agents specifically for *bridges* (O&M, but architecture transfers to design agents).

### F19
- **Title:** A Generalist-Specialist Integrated Agent System for Structural Health Monitoring (SHM-Agents)
- **Authors:** Yuequan Bao, Xing Li, et al.
- **Year:** 2026
- **Source:** arXiv 2605.12916
- **DOI / link:** https://arxiv.org/abs/2605.12916
- **Why relevant:** Generalist LLM + specialist tools on a long-span *cable-stayed bridge*; the agent pattern (planner + FEM + domain tools) is reusable for design.

### F20
- **Title:** AI BIM coordinator for non-expert interaction in building design using LLM-driven multi-agent systems
- **Authors:** Y. Dong, et al.
- **Year:** 2025
- **Source:** Automation in Construction
- **DOI / link:** https://www.sciencedirect.com/science/article/abs/pii/S092658052500603X
- **Why relevant:** Five-role LLM-MAS for BIM design coordination — a template for multi-disciplinary bridge design agents.

### F21
- **Title:** Sketch2BIM: A Multi-Agent Human-AI Collaborative Pipeline to Convert Hand-Drawn Floor Plans to 3D BIM
- **Authors:** Abir Khan Ratul, et al.
- **Year:** 2025
- **Source:** arXiv 2510.20838
- **DOI / link:** https://arxiv.org/abs/2510.20838
- **Why relevant:** Multi-agent sketch-to-BIM; analogous to converting conceptual bridge sketches to models.

### F22
- **Title:** BIM-Edit: Benchmarking Large Language Models for IFC-Based Building Information Modeling
- **Authors:** Bharathi Kannan Nithyanantham, et al.
- **Year:** 2026
- **Source:** arXiv 2606.20146
- **DOI / link:** https://arxiv.org/abs/2606.20146
- **Why relevant:** IFC editing benchmark for LLMs — needed to evaluate whether agents can *modify* bridge models, not just generate text.

### F23
- **Title:** IFCMemoryBench: Evaluating Long-Term Memory of LLM-Based Agents in BIM Information Retrieval
- **Authors:** Changyu Du, Alexander Vosseler, Filippo Mazza, André Borrmann
- **Year:** 2026
- **Source:** arXiv 2607.26072 (KDD 2026 workshop)
- **DOI / link:** https://arxiv.org/abs/2607.26072
- **Why relevant:** Memory of BIM/IFC agents — a missing capability for multi-session bridge design.

### F24
- **Title:** BIM Information Extraction Through LLM-based Adaptive Exploration
- **Authors:** Sylvain Hellin, Suhyung Jang, Stefan Fuchs, Stavros Nousias, et al.
- **Year:** 2026
- **Source:** arXiv 2605.01698
- **DOI / link:** https://arxiv.org/abs/2605.01698
- **Why relevant:** Adaptive LLM exploration of BIM data; needed for agents that read existing bridge models.

### F25
- **Title:** Automating Structural Analysis Across Multiple Software Platforms Using Large Language Models
- **Authors:** Ziheng Geng, Jiachen Liu, Ian Franklin, Ran Cao, et al.
- **Year:** 2026
- **Source:** arXiv 2604.09866
- **DOI / link:** https://arxiv.org/abs/2604.09866
- **Why relevant:** Cross-platform (OpenSees/other) analysis automation — important because bridge design uses heterogeneous solvers.

### F26
- **Title:** Automating structural reliability analysis with a multi-agent large language model framework
- **Authors:** Jaehwan Jeon, Chang Hee Lee, Taeyong Kim
- **Year:** 2026
- **Source:** arXiv 2607.16580
- **DOI / link:** https://arxiv.org/abs/2607.16580
- **Why relevant:** Multi-agent FORM-style reliability of a bridge girder — links agentic AI to the *safety* core of bridge design.

### F27
- **Title:** ARCHER: Agentic Rule and Compliance Harness for Executable Regulations
- **Authors:** Chiraag Singh Anand, Xue Wen Tan, Lionel Teo, Eric Tan
- **Year:** 2026
- **Source:** arXiv 2607.25566
- **DOI / link:** https://arxiv.org/abs/2607.25566
- **Why relevant:** Agentic conversion of regulations into executable checks — the missing “code compiler” for design agents.

### F28
- **Title:** Large Language Models for Computer-Aided Design: A Survey
- **Authors:** (CSUR)
- **Year:** 2025/2026
- **Source:** ACM Computing Surveys; arXiv 2505.08137
- **DOI / link:** https://doi.org/10.1145/3787499 ; https://arxiv.org/abs/2505.08137
- **Why relevant:** Broader CAD+LLM survey (code generation, parametric CAD) that structural/bridge CAD agents inherit from.

### F29
- **Title:** AI applications for structural design automation
- **Authors:** H. Xie, et al.
- **Year:** 2025
- **Source:** Automation in Construction
- **DOI / link:** https://www.sciencedirect.com/science/article/pii/S0926580525005369
- **Why relevant:** 2025 AutCon review splitting AI for *generating* vs *checking* structural design — the two loops of an agentic designer.

### F30
- **Title:** StructureClaw: Traceable LLM Agents and an Executable …
- **Authors:** S. Qin, et al.
- **Year:** 2026
- **Source:** arXiv 2607.14896
- **DOI / link:** https://arxiv.org/pdf/2607.14896
- **Why relevant:** Traceable LLM agents for analysis-integrated structural design — addresses auditability of agentic design.

---

## G. Additional high-value Chinese / practice papers

### G01
- **Title:** 基于BIM参数化在桥梁工程设计阶段应用初探
- **Authors:** 杜一丛 等
- **Year:** 2019
- **Source:** 建筑结构 / related
- **DOI / link:** CNKI JCJG2019S2184
- **Why relevant:** Early Chinese discussion of “一类应用 vs 正向应用” of BIM in bridge design.

### G02
- **Title:** Research of digital delivery method for conventional bridge design
- **Authors:** DAN Chen, et al.
- **Year:** 2023
- **Source:** 中外公路 / CSUST
- **DOI / link:** https://zwgl1980.csust.edu.cn/cgi/viewcontent.cgi?article=1471&context=journal
- **Why relevant:** Digital delivery of *conventional* (not just signature) bridges — the bulk of design practice.

### G03
- **Title:** 林佳瑞团队 — 智能审图 / LLM 驱动交互式建筑设计 系列
- **Authors:** Jia-Rui Lin (林佳瑞) et al.
- **Year:** 2023–2026
- **Source:** Automation in Construction / arXiv / 个人主页
- **DOI / link:** https://linjiarui.net/publications/
- **Why relevant:** Leading Chinese group on computable codes + computable design models; Qwen-BIM and intelligent drawing-checking.

---

## Coverage of this batch

| Theme | IDs | n |
|---|---|---|
| Landmark reviews / handbooks | A01–A13 | 13 |
| Traditional bridge design process | B01–B15 | 15 |
| BIM / BrIM / parametric / IFC | C01–C12 | 12 |
| Automated compliance | D01–D14 | 14 |
| Generative / intelligent design (pre-LLM + hybrid) | E01–E12 | 12 |
| LLM / multi-agent / Agentic (2023–2026) | F01–F30 | 30 |
| Extra Chinese practice | G01–G03 | 3 |
| **Total** | | **99 listed (90 unique core + 9 supporting)** |

Two spines:
1. **Traditional design process:** conceptual → preliminary → detailed; AASHTO/JTG; type selection; parametric BIM; IFC-Bridge; ACC.
2. **Agentic/LLM automation:** Text2BIM / MASSE / Lu Xinzheng LLM-controller / AutoBIM for prefabricated bridges / highway-bridge LLM checking / OpenSeesPy analysis agents.

---

## Suggested Batch 02 expansion axes

1. Topology/size/shape optimization of *specific* bridge types (girder, cable-stayed, arch, truss).
2. More CNKI papers (桥梁建设, 中国公路学报, 土木工程学报, 工程力学) on 正向设计 / 智能设计.
3. EG-ICE, ISARC, EC3, IABSE, IABMAS, CIB W78 conference corpus.
4. BERT/GPT code-information-extraction ACC papers (Zhang/El-Gohary 2019–2023; Zhong; Zhou).
5. Knowledge graphs for bridge codes and components.
6. Digital twins of bridges that close the design–O&M loop.
7. Remaining 2025–2026 arXiv agent papers (MCP, computer-use, verification loops).
