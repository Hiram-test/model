# Batch 08 — Automation in Construction 2023–2026: LLM / agentic / ACC / generative / BrIM

Scope: unique vs. Batches 01–07. TOC-level harvest of *Automation in Construction* (and a few AutCon-adjacent 2023–2026 items) on large language models, multi-agent systems, automated compliance checking, generative/parametric structural design, and bridge BIM.


## AY. AutCon 2023–2026 — LLM, multi-agent, Agentic BIM

### AY01
- **Title:** Automated building component alterations driven by LLM-formalized human strategies to achieve code compliance
- **Authors:** Jiabin Wu, Stefan Fuchs, Pieter Pauwels, André Borrmann
- **Year:** 2026
- **Source:** Automation in Construction 190, 107148
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107148
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.

### AY02
- **Title:** Automated compliance checking in AEC in the era of AI and LLMs: A review (2022–2025)
- **Authors:** Youssef Senousy, Franco Cheung, Thomas Beach, Ogerta Elezaj, Edlira Vakaj
- **Year:** 2026
- **Source:** Automation in Construction 191, 107165
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107165
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.

### AY03
- **Title:** Visual question answering for bridge damage inspection using a multi-modal large language model
- **Authors:** Minghao Dang, Jack Wei Lun Shi, Yapeng Guo, Hongtao Cui, Justin K.W. Yeoh, Shunlong Li
- **Year:** 2026
- **Source:** Automation in Construction 190, 107125
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107125
- **Why relevant:** LLM applied to bridge engineering (specs, drawings, BrIM or design support) — direct thematic fit.

### AY04
- **Title:** Automated carbon-aware assessment of openBIM-based ductwork design using knowledge graph–augmented LLM multi-agent framework
- **Authors:** Yuqing Xu, Ang Li, Xiaowen Guo, et al.
- **Year:** 2026
- **Source:** Automation in Construction 181, 106611
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106611
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 5

### AY05
- **Title:** LLM-enabled multi-agent framework for automated Scan-to-BIM and Scan-to-Graph reconstruction
- **Authors:** Yuandong Pan, Mudan Wang, Jiechao Gao, Jie Wang, Michael D. Lepech, Ioannis Brilakis
- **Year:** 2026
- **Source:** Automation in Construction 188, 107003
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107003
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 1

### AY06
- **Title:** Multi-agent framework for schema-guided reasoning and tool-augmented interaction with IFC models
- **Authors:** Yan Gao, Fuji Hu, Chengzhang Chai, Yiwei Weng, Haijiang Li
- **Year:** 2026
- **Source:** Automation in Construction 186, 106888
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106888
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 1

### AY07
- **Title:** Multi-agent human-AI collaborative framework for converting hand-drawn floor plans to 3D BIM
- **Authors:** Abir Khan Ratul, Sanjay Acharjee, Somin Park, Md Nazmus Sakib
- **Year:** 2026
- **Source:** Automation in Construction 189, 106984
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106984
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### AY08
- **Title:** Automated environmental assessment of construction sites using multimodal large language model (MLLM)-based point cloud segmentation and instance-level scan-vs-BIM
- **Authors:** Xingbo Gong, Boyu Wang, Yuqing Xu, et al.
- **Year:** 2026
- **Source:** Automation in Construction 187, 106949
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106949
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### AY09
- **Title:** Toward generalizable foundation models for 3D BIM geometry using a joint embedding predictive architecture
- **Authors:** Jack Wei Lun Shi, Wawan Solihin, Yufeng Weng, et al.
- **Year:** 2026
- **Source:** Automation in Construction 191, 107169
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107169
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### AY10
- **Title:** Automated rebar arrangement in prefabricated concrete components using multi-agent transfer reinforcement learning
- **Authors:** Zijing Wan, Chengran Xu, Xuefeng Chen, Hongtuo Qi, Jiepeng Liu, Liang Feng
- **Year:** 2026
- **Source:** Automation in Construction 181, 106590
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106590
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY11
- **Title:** Integrating vision-language model and point cloud processing for automated precast connection inspection and assembly optimization
- **Authors:** Maggie Y. Gao, Qian Wang, Chengjia Han, Jianping Li, Gaoming Zhu
- **Year:** 2026
- **Source:** Automation in Construction 191, 107200
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107200
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY12
- **Title:** Multitask unified large vision-language model for post-earthquake structural damage assessment of buildings
- **Authors:** Yongqing Jiang, Jianze Wang, Xinyi Shen, Kaoshan Dai, Qingzi Ge
- **Year:** 2026
- **Source:** Automation in Construction 182, 106720
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106720
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 9

### AY13
- **Title:** LLM-enabled multi-agent framework for natural language interaction with graph-based digital twins
- **Authors:** Yuandong Pan, Mudan Wang, Linjun Lu, et al.
- **Year:** 2026
- **Source:** Automation in Construction 183, 106791
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106791
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 8

### AY14
- **Title:** Multimodal LLM-driven language-embedded 3D gaussian splatting for semantic and realistic digitization of historical buildings
- **Authors:** Zhenyu Liang, Jeff Chak Fu Chan, Jiaying Zhang, et al.
- **Year:** 2026
- **Source:** Automation in Construction 181, 106628
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106628
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 7

### AY15
- **Title:** Multimodal large language model-driven framework for road crack assessment
- **Authors:** Haoyang Zhang, Xiao Pan, Mahdi Asgarinejad, Taoran Song
- **Year:** 2026
- **Source:** Automation in Construction 185, 106872
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106872
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 6

### AY16
- **Title:** Enhancing LLM-based building data query with chain-of-thought, retrieval-augmented generation, and fine-tuning
- **Authors:** Mingchen Li, Ziqi Hu, Parastoo Mohebi, Shuhao Li, Zhe Wang
- **Year:** 2026
- **Source:** Automation in Construction 182, 106738
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106738
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 5

### AY17
- **Title:** LLM-based multi-agent system for dam structural health monitoring
- **Authors:** Changwei Liu, Ruiyang Qu, Chunrui Liu, Jinting Wang, Jianwen Pan
- **Year:** 2026
- **Source:** Automation in Construction 186, 106895
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106895
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 3

### AY18
- **Title:** LLM-driven multi-agent framework for enhancing human-digital twin interaction in built infrastructure management
- **Authors:** Linjun Lu, Peihang Luo, Brian Sheil, Ioannis Brilakis
- **Year:** 2026
- **Source:** Automation in Construction 187, 106896
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106896
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 3

### AY19
- **Title:** Early-stage architecture design assistance by LLMs and knowledge graphs
- **Authors:** Danrui Li, Yichao Shi, Mathew Schwartz, Mubbasir Kapadia
- **Year:** 2026
- **Source:** Automation in Construction 182, 106756
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106756
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 2

### AY20
- **Title:** LLM-powered natural language interaction for voxel-based underground digital twin using task-aware retrieval and prompt engineering
- **Authors:** Muhammad Shoaib Khan, Usama Khalid, Jelena Ninic, Jongwon Seo
- **Year:** 2026
- **Source:** Automation in Construction 189, 107072
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107072
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY21
- **Title:** Multi-agent integration of LLMs and graph-based method for automated MEP constructability checking
- **Authors:** Ang Li, Boyu Wang, Xingbo Gong, et al.
- **Year:** 2026
- **Source:** Automation in Construction 187, 106886
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106886
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY22
- **Title:** Integrating machine learning and multi-agent deep reinforcement learning for performance-driven urban design
- **Authors:** Zewei Shi, Jiahong Ye, Chenyu Huang, Jinyu Wang, Jiawei Yao
- **Year:** 2026
- **Source:** Automation in Construction 186, 106892
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106892
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY23
- **Title:** Retrieval-augmented LLM with structured sampling for Building Management Systems point tagging under minimal context
- **Authors:** Zhiyu Zheng, Sylvain Marié, Sylvain Kubler
- **Year:** 2026
- **Source:** Automation in Construction 185, 106884
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106884
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY24
- **Title:** Multimodal large language model (MLLM) benchmark for intelligent construction in underground engineering
- **Authors:** Tianhao Li, Xuri Ge, Zhaoyang Wang, Pengjie Ren, Zhenhao Xu
- **Year:** 2026
- **Source:** Automation in Construction 188, 106997
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106997
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY25
- **Title:** Fusing enhanced YOLO and knowledge graph-based large language models for automatic risk perception in tower crane operations
- **Authors:** Lingxiao Wang, Jingfeng Yuan, Shu Su, Hongxing Ding, Yu Bai, Miroslaw J. Skibniewski
- **Year:** 2026
- **Source:** Automation in Construction 183, 106823
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106823
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY26
- **Title:** From geometric labels to semantic understanding of indoor building components using multimodal large language models
- **Authors:** Shuju Jing, Chao Yin
- **Year:** 2026
- **Source:** Automation in Construction 190, 107117
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107117
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY27
- **Title:** LLM-assisted quality-aware GA–multi-agent deep deterministic policy gradient framework for multi-robot collaborative scheduling in construction quality control
- **Authors:** Meihao Zhu, Zhansheng Liu, Hao Zhou, Weiyi Li, Song Wang, Qingwen Zhang
- **Year:** 2026
- **Source:** Automation in Construction 191, 107203
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107203
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY28
- **Title:** Graph-driven embedding reinforcement and traceable LLM agent for reliable element alignment in construction report generation
- **Authors:** Zhenzhao Xia, Botao Zhong, Shuai Zhang, Tonghui Zhao, Miroslaw J. Skibniewski
- **Year:** 2026
- **Source:** Automation in Construction 183, 106816
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106816
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY29
- **Title:** Agent-orchestrated domain-specific large language model for large-scale database-driven geotechnical site characterizations
- **Authors:** Qiujing Pan, Guangcan Sun, Zehang Qian, Xiaosong Tang, Mingfei Lei, Chao Shi
- **Year:** 2026
- **Source:** Automation in Construction 189, 107064
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107064
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY30
- **Title:** LLM-enabled automation of CAD–structural analysis via Model Context Protocol
- **Authors:** Ermal Elbasani, Tran B. Tran, Seunghye Lee, Jaehong Lee
- **Year:** 2026
- **Source:** Automation in Construction 188, 107030
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107030
- **Why relevant:** LLM tool-use on structural analysis/CAD — the verification loop of an agentic design process.

### AY31
- **Title:** From architectural sketches to fabrication-ready documentation: Agentic framework for planar truss structures
- **Authors:** Xianchuan Meng, Ziyu Tong, Chen Zhao
- **Year:** 2026
- **Source:** Automation in Construction 188, 107010
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107010
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY32
- **Title:** Human-AI collaborative decision-making for pavement maintenance using Hierarchical Multi-Agent Optimization
- **Authors:** Jinze Luo, Chenglong Liu, Yuchuan Du, Wenyuan Cai
- **Year:** 2026
- **Source:** Automation in Construction 190, 107088
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107088
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY33
- **Title:** Human-operational 3D indoor layout generation with LLM-driven anthropometric simulation
- **Authors:** Semin Jin, Kyung Hoon Hyun
- **Year:** 2026
- **Source:** Automation in Construction 184, 106846
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106846
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY34
- **Title:** Artifact-driven LLM integration for mouseless design workflows
- **Authors:** Ghang Lee, Sejin Park, Soo-in Yang
- **Year:** 2026
- **Source:** Automation in Construction 183, 106766
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106766
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY35
- **Title:** Dialectical systems framework for LLM applications in intelligent construction and operation
- **Authors:** Xiaoxiao Xu, Zonglin Li
- **Year:** 2026
- **Source:** Automation in Construction 191, 107186
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107186
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY36
- **Title:** Retrieval-augmented LLM framework for automated construction site layout planning
- **Authors:** Rongyan Li, Haolei Lin, Hung-Lin Chi, Fangzheng Li, Wen Yi, Linyan Chen
- **Year:** 2026
- **Source:** Automation in Construction 192, 107211
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107211
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY37
- **Title:** Multi-task crack foundation model for engineering-reliable crack representation and topology preservation in civil infrastructure
- **Authors:** Blessing Agyei Kyem, Joshua Kofi Asamoah, Eugene Denteh, Armstrong Aboah
- **Year:** 2026
- **Source:** Automation in Construction 191, 107190
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107190
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY38
- **Title:** Mixed Reality Assembly Orchestration for cross-laminated timber construction driven by zero-shot vision and LLM-based reasoning
- **Authors:** Qi Wang, Maowei Jiang, Zhiyong Dong, et al.
- **Year:** 2026
- **Source:** Automation in Construction 190, 107105
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107105
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY39
- **Title:** Physics-constrained and LLM-driven framework for cross-project deformation prediction in deep foundation pits
- **Authors:** Yue Pan, Zonghang He, Jin-Jian Chen, Xiang Li, Jianfeng Zhou
- **Year:** 2026
- **Source:** Automation in Construction 190, 107099
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107099
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY40
- **Title:** Integrating knowledge graphs and LLMs for intelligent full-chain safety risk pre-control in large hydropower projects
- **Authors:** Yingliu Yang, Ke Chen, S. Thomas Ng, Pengcheng Xiang, Zhikang Bao
- **Year:** 2026
- **Source:** Automation in Construction 191, 107194
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107194
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY41
- **Title:** Few-shot concrete surface extraction for automated UAV-based building inspection using vision foundation models
- **Authors:** Seungbo Shim, Yeongjin Kim, Hyeongmo Park
- **Year:** 2026
- **Source:** Automation in Construction 191, 107162
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107162
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY42
- **Title:** Lightweight graph retrieval-augmented generation agent for safety monitoring digital twins in small- and medium-scale hydropower projects
- **Authors:** Chenfei Shao, Xiangnan Qin, Xing Li, Meng Yang, Dongyang Yuan, Sen Zheng
- **Year:** 2026
- **Source:** Automation in Construction 188, 107041
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107041
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY43
- **Title:** Comprehensive benchmark of large language models for construction engineering and management
- **Authors:** Yue Li, Shaoheng Li, Duantengchuan Li, Feng Chen, Yu Liu
- **Year:** 2026
- **Source:** Automation in Construction 190, 107101
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.107101
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### AY44
- **Title:** Vision-language model-based intelligent assistant for onsite construction safety inspection
- **Authors:** Rahat Hussain, Doyeop Lee, Muhammad Sibtain Abbas, Syed Farhan Alam Zaidi, Akeem Pedro, Chansik Park
- **Year:** 2026
- **Source:** Automation in Construction 182, 106728
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106728
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 9

### AY45
- **Title:** Crack image classification and information extraction in steel bridges using multimodal large language models
- **Authors:** Xiao Wang, Qingrui Yue, Xiaogang Liu
- **Year:** 2025
- **Source:** Automation in Construction 171, 105995
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.105995
- **Why relevant:** LLM applied to bridge engineering (specs, drawings, BrIM or design support) — direct thematic fit.
- **Cites (Crossref):** 36

### AY46
- **Title:** Multi-agent large language model framework for code-compliant automated design of reinforced concrete structures
- **Authors:** Jinxin Chen, Yi Bao
- **Year:** 2025
- **Source:** Automation in Construction 177, 106331
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106331
- **Why relevant:** LLM/multi-agent generative structural design with code awareness — precursor to agentic bridge design.
- **Cites (Crossref):** 30

### AY47
- **Title:** From design to operation: Multi-agent AI for virtual in-situ modeling of digital twins in BIM
- **Authors:** Jeyoon Lee, Jiteng Li, Sungmin Yoon
- **Year:** 2025
- **Source:** Automation in Construction 179, 106477
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106477
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 8

### AY48
- **Title:** Large language model-empowered paradigm for automated geotechnical site planning and geological characterization
- **Authors:** Zehang Qian, Chao Shi
- **Year:** 2025
- **Source:** Automation in Construction 173, 106103
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106103
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 50

### AY49
- **Title:** Automating construction contract review using knowledge graph-enhanced large language models
- **Authors:** Chunmo Zheng, Saika Wong, Xing Su, Yinqiu Tang, Ahsan Nawaz, Mohamad Kassem
- **Year:** 2025
- **Source:** Automation in Construction 175, 106179
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106179
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 47

### AY50
- **Title:** Automated safety risk management guidance enhanced by retrieval-augmented large language model
- **Authors:** Seungwon Baek, Chan Young Park, Wooyong Jung
- **Year:** 2025
- **Source:** Automation in Construction 176, 106255
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106255
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 43

### AY51
- **Title:** Multimodal framework integrating multiple large language model agents for intelligent geotechnical design
- **Authors:** Hao-Rao Xu, Ning Zhang, Zhen-Yu Yin, Pierre Guy Atangana Njock
- **Year:** 2025
- **Source:** Automation in Construction 176, 106257
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106257
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 36

### AY52
- **Title:** Large language model-based agent Schema and library for automated building energy analysis and modeling
- **Authors:** Liang Zhang, Xiaoqin Fu, Yanfei Li, Jianli Chen
- **Year:** 2025
- **Source:** Automation in Construction 176, 106244
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106244
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 31

### AY53
- **Title:** Efficient fine-tuning of large language models for automated building energy modeling in complex cases
- **Authors:** Gang Jiang, Jianli Chen
- **Year:** 2025
- **Source:** Automation in Construction 175, 106223
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106223
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 30

### AY54
- **Title:** Named entity recognition for construction documents based on fine-tuning of large language models with low-quality datasets
- **Authors:** Junyu Zhou, Zhiliang Ma
- **Year:** 2025
- **Source:** Automation in Construction 174, 106151
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106151
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 26

### AY55
- **Title:** Context-aware vision-language model agent enriched with domain-specific ontology for construction site safety monitoring
- **Authors:** Chak-Fu Chan, Peter Kok-Yiu Wong, Xiaowen Guo, et al.
- **Year:** 2025
- **Source:** Automation in Construction 177, 106305
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106305
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 23

### AY56
- **Title:** Integrating domain-specific knowledge and fine-tuned general-purpose large language models for question-answering in construction engineering management
- **Authors:** Shenghua Zhou, Xuefan Liu, Dezhi Li, et al.
- **Year:** 2025
- **Source:** Automation in Construction 175, 106206
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106206
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 19

### AY57
- **Title:** Knowledge-based cross-modal fusion for long-term forecasting of grouting construction parameters using large language model
- **Authors:** Tianhong Zhang, Hongling Yu, Xiaoling Wang, Jiajun Wang, Binyu Ren
- **Year:** 2025
- **Source:** Automation in Construction 172, 106036
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106036
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 17

### AY58
- **Title:** Enhancing visual-LLM for construction site safety compliance via prompt engineering and Bi-stage retrieval-augmented generation
- **Authors:** Koi Xiaowen Guo, Peter Kok-Yiu Wong, Jack C.P. Cheng, Chak-Fu Chan, Pak-Him Leung, Xingyu Tao
- **Year:** 2025
- **Source:** Automation in Construction 179, 106490
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106490
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 16

### AY59
- **Title:** Optimizing large vision-language models for context-aware construction safety assessment
- **Authors:** Taegeon Kim, Seokhwan Kim, Wei-Chih Chern, Somin Park, Daeho Kim, Hongjo Kim
- **Year:** 2025
- **Source:** Automation in Construction 180, 106510
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106510
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 14

### AY60
- **Title:** LLM agent framework for intelligent change analysis in urban environment using remote sensing imagery
- **Authors:** Zixuan Xiao, Jun Ma
- **Year:** 2025
- **Source:** Automation in Construction 177, 106341
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106341
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 12

### AY61
- **Title:** Intelligent quality assessment of concrete vibration using computer vision and large language models
- **Authors:** Tan Li, Hong Wang, Jiasheng Tan, et al.
- **Year:** 2025
- **Source:** Automation in Construction 180, 106507
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106507
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 12

### AY62
- **Title:** Integrating hierarchical segmentation and vision-language reasoning for spatially complex and occluded MEP point clouds
- **Authors:** Mingkai Li, Vincent J.L. Gan, Boyu Wang
- **Year:** 2025
- **Source:** Automation in Construction 179, 106455
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106455
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 11

### AY63
- **Title:** LLM-based framework for automated and customized floor plan design
- **Authors:** Zijin Qiu, Jiepeng Liu, Yantao Wu, et al.
- **Year:** 2025
- **Source:** Automation in Construction 180, 106512
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106512
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 8

### AY64
- **Title:** Automated aggregation of dwelling units and traffic cores in high-rise residential floor plans using genetic algorithm and multi-agent cooperative deep Q-network
- **Authors:** Xuhong Zhou, Gan Luo, Yunzhu Liao, et al.
- **Year:** 2025
- **Source:** Automation in Construction 177, 106329
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106329
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 1

### AY65
- **Title:** Performance comparison of retrieval-augmented generation and fine-tuned large language models for construction safety management knowledge retrieval
- **Authors:** Jungwon Lee, Seungjun Ahn, Daeho Kim, Dongkyun Kim
- **Year:** 2024
- **Source:** Automation in Construction 168, 105846
- **DOI / link:** https://doi.org/10.1016/j.autcon.2024.105846
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 111

### AY66
- **Title:** Automated architectural spatial composition via multi-agent deep reinforcement learning for building renovation
- **Authors:** Zihuan Zhang, Zhe Guo, Hao Zheng, Zao Li, Philip F. Yuan
- **Year:** 2024
- **Source:** Automation in Construction 167, 105702
- **DOI / link:** https://doi.org/10.1016/j.autcon.2024.105702
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 29

### AY67
- **Title:** Augmented reality, deep learning and vision-language query system for construction worker safety
- **Authors:** Haosen Chen, Lei Hou, Shaoze Wu, et al.
- **Year:** 2024
- **Source:** Automation in Construction 157, 105158
- **DOI / link:** https://doi.org/10.1016/j.autcon.2023.105158
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 70

### AY68
- **Title:** Optimized multimodal logistics planning of modular integrated construction using hybrid multi-agent and metamodeling
- **Authors:** Mohamed Hussein, Ahmed Karam, Abdelrahman E.E. Eltoukhy, Amos Darko, Tarek Zayed
- **Year:** 2023
- **Source:** Automation in Construction 145, 104637
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104637
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 60

### AY69
- **Title:** Metaheuristic planner for cooperative multi-agent wall construction with UAVs
- **Authors:** Basel Elkhapery, Robert Pěnička, Michal Němec, Mohsin Siddiqui
- **Year:** 2023
- **Source:** Automation in Construction 152, 104908
- **DOI / link:** https://doi.org/10.1016/j.autcon.2023.104908
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 13


## AZ. AutCon 2023–2026 — ACC, generative/parametric design, IFC/KG, bridge BIM

### AZ01
- **Title:** Framework for automated building code compliance checking to improve transparency, trust, validation, and design interpretation
- **Authors:** Nishanth Purushotham, Chethan Kailashnath, Ivan Mutis
- **Year:** 2026
- **Source:** Automation in Construction 181, 106598
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106598
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 5

### AZ02
- **Title:** Automated compliance checking across the building lifecycle: Systematic and semantic review integrating PRISMA and deep search
- **Authors:** Ju Hyun Lee, Seung Yeul Ji, Michael J. Ostwald
- **Year:** 2026
- **Source:** Automation in Construction 185, 106859
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106859
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 4

### AZ03
- **Title:** Control strategies for Cellular Automata-based generative design in architecture and urbanism
- **Authors:** Yiming Liu, Christiane M. Herr
- **Year:** 2026
- **Source:** Automation in Construction 183, 106754
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106754
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.
- **Cites (Crossref):** 2

### AZ04
- **Title:** Multi-objective scientific approach to problem solving-inspired optimization integrated with the finite element method for automated structural design
- **Authors:** Dinh-Nhat Truong, Jui-Sheng Chou
- **Year:** 2026
- **Source:** Automation in Construction 183, 106770
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106770
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.
- **Cites (Crossref):** 1

### AZ05
- **Title:** Computational Design Methods for geometry-driven upcycling of found objects in construction
- **Authors:** Qiming Sun, Dominik Reisach, Silke Langenberg, Benjamin Dillenburger
- **Year:** 2026
- **Source:** Automation in Construction 183, 106803
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106803
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.
- **Cites (Crossref):** 1

### AZ06
- **Title:** Reasoning-driven multimodal generative design for tunnel portals
- **Authors:** Yao Li, Shikui Wei, Wei Su, et al.
- **Year:** 2026
- **Source:** Automation in Construction 188, 106990
- **DOI / link:** https://doi.org/10.1016/j.autcon.2026.106990
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.

### AZ07
- **Title:** Intelligent design of steel-concrete composite box girder bridge cross-sections based on generative models
- **Authors:** Yingjie Zhu, Liying Chen, Guorui Huang, Jiaji Wang, Si Fu, Yan Bai
- **Year:** 2025
- **Source:** Automation in Construction 176, 106292
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106292
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 2

### AZ08
- **Title:** Semantic BIM enrichment using a hybrid ML and rule-based framework for automated tenement compliance checking
- **Authors:** Ankan Karmakar, Venkata Santosh Kumar Delhi
- **Year:** 2025
- **Source:** Automation in Construction 177, 106369
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106369
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 12

### AZ09
- **Title:** Design of deployable bridge using multistable miura-ori structure for emergency rescue
- **Authors:** Wei Wang, Xu Li, Peng Yan, Hailin Huang, Bing Li
- **Year:** 2025
- **Source:** Automation in Construction 176, 106233
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106233
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 7

### AZ10
- **Title:** Parametric design methodology for developing BIM object libraries in construction site modeling
- **Authors:** Vito Getuli, Alessandro Bruttini, Farzad Rahimian
- **Year:** 2025
- **Source:** Automation in Construction 170, 105897
- **DOI / link:** https://doi.org/10.1016/j.autcon.2024.105897
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.
- **Cites (Crossref):** 13

### AZ11
- **Title:** AI-driven generative design and optimization in prefabricated construction
- **Authors:** Veerakumar Rangasamy, Jyh-Bin Yang
- **Year:** 2025
- **Source:** Automation in Construction 177, 106350
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106350
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 13

### AZ12
- **Title:** Design Healing framework for automated code compliance
- **Authors:** Jiabin Wu, Stavros Nousias, André Borrmann
- **Year:** 2025
- **Source:** Automation in Construction 171, 106004
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106004
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 7

### AZ13
- **Title:** Long context window-based zero-shot legal interpretation of building codes and regulations
- **Authors:** Jaekun Lee, Ghang Lee
- **Year:** 2025
- **Source:** Automation in Construction 179, 106450
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106450
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 5

### AZ14
- **Title:** GNN-based spatial relationship modeling for automated scaffold component function recognition and intelligent compliance checking
- **Authors:** Xiaochun Luo, Yutong Tang, Yongqi Wei, Chengqian Li, Qi Fang
- **Year:** 2025
- **Source:** Automation in Construction 180, 106557
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106557
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 3

### AZ15
- **Title:** BIM-based preassembly analysis for design for manufacturing and assembly of prefabricated bridges
- **Authors:** Duy-Cuong Nguyen, Chi-Ho Jeon, Gitae Roh, Chang-su Shim
- **Year:** 2024
- **Source:** Automation in Construction 160, 105338
- **DOI / link:** https://doi.org/10.1016/j.autcon.2024.105338
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 53

### AZ16
- **Title:** Automatic compliance checking of BIM models against quality standards based on ontology technology
- **Authors:** Zhiliang Ma, Honggang Zhu, Xinglei Xiang, Žiga Turk, Robert Klinc
- **Year:** 2024
- **Source:** Automation in Construction 166, 105656
- **DOI / link:** https://doi.org/10.1016/j.autcon.2024.105656
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 25

### AZ17
- **Title:** Robust localization of shear connectors in accelerated bridge construction with neural radiance field
- **Authors:** Gyumin Lee, Ali Turab Asad, Khurram Shabbir, Sung-Han Sim, Junhwa Lee
- **Year:** 2024
- **Source:** Automation in Construction 168, 105843
- **DOI / link:** https://doi.org/10.1016/j.autcon.2024.105843
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 3

### AZ18
- **Title:** Question-answering framework for building codes using fine-tuned and distilled pre-trained transformer models
- **Authors:** Xiaorui Xue, Jiansong Zhang, Yunfeng Chen
- **Year:** 2024
- **Source:** Automation in Construction 168, 105730
- **DOI / link:** https://doi.org/10.1016/j.autcon.2024.105730
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 31

### AZ19
- **Title:** Automation of escape route analysis for BIM-based building code checking
- **Authors:** Simon Fischer, Christian Schranz, Harald Urban, Daniel Pfeiffer
- **Year:** 2023
- **Source:** Automation in Construction 156, 105092
- **DOI / link:** https://doi.org/10.1016/j.autcon.2023.105092
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 22

### AZ20
- **Title:** Semantic rule checking of cross-domain building data in information containers for linked document delivery using the shapes constraint language
- **Authors:** Philipp Hagedorn, Pieter Pauwels, Markus König
- **Year:** 2023
- **Source:** Automation in Construction 156, 105106
- **DOI / link:** https://doi.org/10.1016/j.autcon.2023.105106
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 24

### AZ21
- **Title:** Capabilities of rule representations for automated compliance checking in healthcare buildings
- **Authors:** Zijing Zhang, Nicholas Nisbet, Ling Ma, Tim Broyd
- **Year:** 2023
- **Source:** Automation in Construction 146, 104688
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104688
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 19


---

**This batch listed:** 90 unique named items (deduped vs Batches 01–07 and earlier 08+).
