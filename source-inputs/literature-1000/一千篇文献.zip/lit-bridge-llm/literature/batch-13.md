# Batch 13 — Chinese journals, theses and design-practice papers (named items)

Scope: unique vs. Batches 01–12. Named 中文文献 (journals, theses, books) on 桥梁设计方法、参数化/正向 BIM、智能设计、规范自动审查、大模型测评. English-titled CN venues included where the work is China-authored.

DOI strings of the form `10.19721/…` and `10.14048/…` are the journals’ official identifiers; many are **not** in Crossref (use the journal URL).

---

## BJ. 《中国公路学报》2025–2026 — 数字孪生 / IFC / 大模型 / 抗疲劳设计

### BJ01
- **Title:** 基于Civil-Eval的土木和交通工程大模型中文测评方法
- **Authors:** 张云开, 陈颖, 黄永, 苏亚武, 卢闪闪, 魏世银, 陈文礼
- **Year:** 2026
- **Source:** 中国公路学报 39(1), 148–161
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2026.01.012
- **Why relevant:** First Chinese-language LLM benchmark for civil/transport exams (Civil-Eval, CivilGPT) — the evaluation layer any 桥梁规范/设计 agent must pass.

### BJ02
- **Title:** 面向无人机智能巡检的桥梁数字孪生系统：基于IFC知识图谱与游戏引擎的协同方法
- **Authors:** 刘玖财, 李海江, 王达磊
- **Year:** 2026
- **Source:** 中国公路学报 39(1), 173–185
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2026.01.014
- **Why relevant:** IFC-graph as the semantic store of a bridge digital twin — the same graph a design/O&M agent would query.

### BJ03
- **Title:** 基于数字孪生的复杂风场下斜拉-悬索桥建造过程虚拟仿真方法
- **Authors:** (中国公路学报 2025, 38(6))
- **Year:** 2025
- **Source:** 中国公路学报 38(6)
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2025.06.007
- **Why relevant:** BIM parametric model + IFC-3D Tiles + CAE for a cable-supported bridge — design–construction digital thread.

### BJ04
- **Title:** 钢桥面顶板与加劲肋焊接细节抗疲劳性能研究进展与数字孪生疲劳试验
- **Authors:** 王春生, 吴庆霖, 李璞玉, 林路宇, 黄育亮, 刘海军
- **Year:** 2026
- **Source:** 中国公路学报 39(1), 1–19
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2026.01.001
- **Why relevant:** Digital-twin fatigue tests that feed *anti-fatigue design* of orthotropic decks (JTG D64 detailing).

### BJ05
- **Title:** 基于协同优化方法的钢桥面沥青铺装抗疲劳延寿设计研究
- **Authors:** 任海生, 钱振东, 薄雾, 黄卫, 陈春
- **Year:** 2026
- **Source:** 中国公路学报 39(1), 235–243
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2026.01.019
- **Why relevant:** Concurrent material–structure *detailed design* of steel-deck pavement — a computational detailed-design workflow.

### BJ06
- **Title:** 数字孪生驱动的智慧梁厂智能排产与调度研究
- **Authors:** 李文昊, 勾红叶, 郭敏, 王君明, 许国敏
- **Year:** 2026
- **Source:** 中国公路学报 39(1), 124–135
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2026.01.010
- **Why relevant:** Prefabricated-girder (ABC) production planning as the factory-side of parametric girder design.

### BJ07
- **Title:** 面向工程结构数字孪生的智能虚拟传感技术
- **Authors:** 赵昊阳, 樊健生, 王琛
- **Year:** 2026
- **Source:** 中国公路学报 39(1), 42–52
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2026.01.003
- **Why relevant:** AI-ROM virtual sensing that closes the design–as-built loop for a composite pylon (狮子洋大桥).

### BJ08
- **Title:** 融合数字孪生的桥梁巡检技术：综述与展望
- **Authors:** 潘玥, 庄骁磊, 王达磊, 陈艾荣
- **Year:** 2026
- **Source:** 中国公路学报 39(1), 20–41
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.2026.01.002
- **Why relevant:** Maps how as-designed BIM/IFC is reused in inspection twins — the O&M half of a BrIM design agent.

### BJ09
- **Title:** 桥梁数字孪生与元宇宙专栏导语
- **Authors:** 《中国公路学报》编辑部 / 王春生 组稿
- **Year:** 2026
- **Source:** 中国公路学报 39(1), 4
- **DOI / link:** https://zgglxb.chd.edu.cn/CN/Y2026/V39/I1
- **Why relevant:** Editorial map of CN research on bridge twins, IFC-graphs and civil foundation models.

---

## BK. 《中外公路》2023–2025 — 参数化 BIM、装配式方案、数字化交付、规范审查

### BK01
- **Title:** 考虑架设负载扰动的钢拱肋虚拟预拼装技术
- **Authors:** 王晓明 等
- **Year:** 2025
- **Source:** 工程力学
- **DOI / link:** https://doi.org/10.6052/j.issn.1000-4750.2025.06.0268
- **Why relevant:** Revit parametric geometry of steel-arch segments for virtual trial assembly — design-to-erection automation.

### BK02
- **Title:** Research on Parametric Method of Highway BIM Based on Digital Delivery
- **Authors:** LI Jinlong, WANG Xinnan
- **Year:** 2025
- **Source:** 中外公路 45(3), Art. 26, 215–220
- **DOI / link:** https://doi.org/10.14048/j.issn.1671-2579.2025.03.026
- **Why relevant:** Parameter taxonomy (“overall / local / section / element”) for lifecycle highway BIM — the data contract of parametric BrIM.

### BK03
- **Title:** 基于BIM+GIS技术的常规桥梁设计信息数字化交付方法研究
- **Authors:** 但晨, 朱明, 肖春红
- **Year:** 2023
- **Source:** 中外公路 43(5), 141–147
- **DOI / link:** https://zwgl1980.csust.edu.cn/ (search 43(5)); cited as [5] in BK02
- **Why relevant:** Digital *design-information delivery* of ordinary highway bridges via BIM+GIS.

### BK04
- **Title:** 基于知识图谱的公路BIM模型自动审查方法研究
- **Authors:** 王吾愚, 邵克博, 张峰
- **Year:** 2025
- **Source:** 中外公路 (online first)
- **DOI / link:** CNKI kcms detail 43.1363.U.20250114.1822.002
- **Why relevant:** KG-based automatic checking of highway BIM — CN counterpart of LLM-ACC.

### BK05
- **Title:** Industrial Design and Economic Analysis of Steel Box Girder Bridge with Conventional Span
- **Authors:** CUI Bing, CHEN Kun
- **Year:** 2025
- **Source:** 中外公路 45(1), Art. 28
- **DOI / link:** https://doi.org/10.14048/j.issn.1671-2579.2025.01.028
- **Why relevant:** Industrialized *detailed design* of conventional-span steel box girders (type-selection + economics).

### BK06
- **Title:** Calculation of Socket Depth for Circular Pipe Pier-Bearing Platform Socket Connection
- **Authors:** CHEN Jingli, XIAO Feng, WANG Zhigang, WANG Zhihai, XU Yan
- **Year:** 2025
- **Source:** 中外公路 45(1), Art. 17
- **DOI / link:** https://doi.org/10.14048/j.issn.1671-2579.2025.01.017
- **Why relevant:** Closed-form *detailed design* rule for ABC socket piers.

### BK07
- **Title:** Installation Direction Design and Construction Control of Sliding Bearing of Continuous Girder Bridge
- **Authors:** GUAN Changlu, SUN Xiudong, DONG Hao, WANG Xingzhou
- **Year:** 2025
- **Source:** 中外公路 45(1), Art. 15
- **DOI / link:** https://doi.org/10.14048/j.issn.1671-2579.2025.01.015
- **Why relevant:** Bearing-layout design rule for continuous girders — a typical detailed-design check.

### BK08
- **Title:** Theoretical and Experimental Studies on Adaptive Spatial Rotating Main Cable Saddle
- **Authors:** CHEN Yuanlin, HUANG Anming, CHEN Long, XIE Jun
- **Year:** 2025
- **Source:** 中外公路 45(1), Art. 22
- **DOI / link:** https://doi.org/10.14048/j.issn.1671-2579.2025.01.022
- **Why relevant:** Component-level *detailed design* of a suspension-bridge saddle.

### BK09
- **Title:** Static Performance and Stability of a Multi-Span Hybrid Continuous Rigid Frame Bridge with High Piers
- **Authors:** HUANG Yu, LIU Guanyu, YI Jianbo, XING Xuan, SU Miao, PENG Hui
- **Year:** 2025
- **Source:** 中外公路 45(1), Art. 20
- **DOI / link:** https://doi.org/10.14048/j.issn.1671-2579.2025.01.020
- **Why relevant:** High-pier rigid-frame *preliminary/detailed* stability design.

### BK10
- **Title:** Reliability Analysis of Long-Span Concrete Box Arch Bridge under Temperature Effect Combinations
- **Authors:** ZHENG Junlin, JIANG Youbao, ZHENG Xinhao, LU Naiwei
- **Year:** 2025
- **Source:** 中外公路 45(1), Art. 19
- **DOI / link:** https://doi.org/10.14048/j.issn.1671-2579.2025.01.019
- **Why relevant:** Reliability-based *detailed design* of a long-span box arch under temperature combinations.

### BK11
- **Title:** Key Techniques for Constructing Flexible Geosynthetic Reinforced Soil Abutments
- **Authors:** YU Xiaoxiao, XU Chao, LI Haoyu, ZUO Binli
- **Year:** 2025
- **Source:** 中外公路 45(1), Art. 18
- **DOI / link:** https://doi.org/10.14048/j.issn.1671-2579.2025.01.018
- **Why relevant:** GRS integral-abutment *design/construction* method.

### BK12
- **Title:** 基于BIM的道路信息模型参数化构建技术研究
- **Authors:** 秦涛, 龚晓晖, 于洪武, 等
- **Year:** 2017
- **Source:** 中外公路 37(1), 302–304
- **DOI / link:** cited in BK02
- **Why relevant:** Early CN parametric road-information-model paper that later BrIM parameter schemes cite.

---

## BL. 《世界桥梁》《桥梁建设》及铁路信息化 — 全寿命 BIM、参数化、自动建模

### BL01
- **Title:** 基于BIM的桥梁全生命期管理技术及应用研究
- **Authors:** 吴巨峰, 祁江波, 方黎君, 等
- **Year:** 2020
- **Source:** 世界桥梁 48(4), 75–80
- **DOI / link:** 世界桥梁 2020, 48(4)
- **Why relevant:** Lifecycle BrIM from design through O&M — Chinese practice baseline.

### BL02
- **Title:** 设计参数驱动的桥梁工程自动建模与编码方法
- **Authors:** 菅三虎 等
- **Year:** 2026
- **Source:** 铁路计算机应用 35(3)
- **DOI / link:** https://doi.org/10.3969/j.issn.1005-8451.2026.03.12
- **Why relevant:** Parameter-driven automatic modelling + coding of PC box-girder bridges (section+path lofting).

### BL03
- **Title:** 基于BIM的三维参数化桥梁标准建模方法研究
- **Authors:** (重庆交通大学学报 自然科学版)
- **Year:** 2019
- **Source:** 重庆交通大学学报(自然科学版) 38(10), 19–24
- **DOI / link:** https://doi.org/10.3969/j.issn.1674-0696.2019.10.04
- **Why relevant:** Standard parametric modelling method for 3D bridge BIM.

### BL04
- **Title:** Development and Application of Revit-ANSYS Model Conversion Interface
- **Authors:** Z. Wang 等
- **Year:** 2026
- **Source:** Industrial Construction / 工业建筑 (10.3724)
- **DOI / link:** https://doi.org/10.3724/j.gyjzG26011404
- **Why relevant:** Parametric APDL generation from Revit — the design–analysis link a structural agent must automate.

### BL05
- **Title:** 基于BIM技术的大跨度桥梁施工管理平台研发及应用
- **Authors:** 马少雄 等
- **Year:** 2017
- **Source:** 图学学报
- **DOI / link:** https://doi.org/10.11996/JG.j.2095-302X.2017030439
- **Why relevant:** Early CN BIM platform that already uses the model for *scheme comparison and design optimization*.

### BL06
- **Title:** 公路工程集成数字化交付模式研究
- **Authors:** 李辉, 雷俊, 丁罕, 等
- **Year:** 2022
- **Source:** 公路 67(8), 291–297
- **DOI / link:** 《公路》2022, 67(8)
- **Why relevant:** Integrated digital delivery mode that parametric BrIM design must target.

---

## BM. 学位论文与专著 — 参数化/正向设计（可被期刊论文引用的源头）

### BM01
- **Title:** 基于BIM的混凝土箱梁桥参数化设计研究
- **Authors:** 渠川锋
- **Year:** 2021
- **Source:** 东南大学硕士学位论文
- **DOI / link:** 东南大学 / CNKI
- **Why relevant:** Full parametric *design* (not only modelling) of a concrete box-girder bridge in BIM.

### BM02
- **Title:** 基于Dynamo可视化编程的桥梁BIM模型参数化布设方法研究
- **Authors:** 张柳柳
- **Year:** 2021
- **Source:** 浙江大学硕士学位论文
- **DOI / link:** 浙江大学 / CNKI
- **Why relevant:** Dynamo-driven parametric *layout* of bridge BIM — the Grasshopper/Dynamo line of BrIM.

### BM03
- **Title:** 基于BIM的桥梁参数化建模及模型转换研究
- **Authors:** 朱江华
- **Year:** 2020
- **Source:** 西安建筑科技大学硕士学位论文
- **DOI / link:** 西安建筑科技大学 / CNKI
- **Why relevant:** Parametric modelling + model conversion (BIM↔analysis) for bridges.

### BM04
- **Title:** 基于BIM的钢桥正向设计与应用
- **Authors:** (人民交通 / 相关专著)
- **Year:** 2020s
- **Source:** Book
- **DOI / link:** Google Books id=viXyzgEACAAJ
- **Why relevant:** Monograph on *steel-bridge forward (正向) design* plus AI-assisted design.

### BM05
- **Title:** 基于BIM技术的高速公路设计应用研究：以苏锡常南部高速公路为例
- **Authors:** 王昊平
- **Year:** 2018
- **Source:** 东南大学硕士学位论文
- **DOI / link:** 东南大学 / CNKI
- **Why relevant:** Highway BIM including structures — early CN forward-design case.

---

## BN. 智能设计 / 规范审查 / 行业大模型（中文综述与工程院咨询）

### BN01
- **Title:** 人工智能在土木工程领域的应用研究现状及展望
- **Authors:** 刘红波, 张帆, 陈志华, 王龙轩
- **Year:** 2024
- **Source:** 土木与环境工程学报（中英文） 46(1), 14–32
- **DOI / link:** https://doi.org/10.11835/j.issn.2096-6717.2022.016
- **Why relevant:** CN survey that explicitly lists *intelligent design* (智能设计) as an AI-in-civil pillar.

### BN02
- **Title:** New-Generation Quality and Safety Management of the Construction Industry: Development Research
- **Authors:** 谢先启 等
- **Year:** 2021
- **Source:** 中国工程科学 / Chinese Journal of Engineering Science
- **DOI / link:** https://doi.org/10.15302/J-SSCAE-2021.04.008
- **Why relevant:** CAE consulting paper that includes quality-oriented *intelligent design* using digital twins and scheme libraries.

### BN03
- **Title:** Development of Construction Technology and Equipment for Marine Bridges
- **Authors:** 张瑞霞 等
- **Year:** 2019
- **Source:** 中国工程科学
- **DOI / link:** https://doi.org/10.15302/J-SSCAE-2019.03.015
- **Why relevant:** Marine long-span (cable-stayed) *construction/design* technology map.

### BN04
- **Title:** 基于Revit平台的连续梁桥参数化建模方法
- **Authors:** (发明专利 CN107609321B)
- **Year:** 2019 (grant)
- **Source:** Chinese patent
- **DOI / link:** https://patents.google.com/patent/CN107609321B
- **Why relevant:** Patented Revit parametric method for continuous girder bridges — industrialised design automation.

### BN05
- **Title:** 基于BIM技术的桥梁工程设计分析
- **Authors:** (建筑工程与设计 / 开放获取短文)
- **Year:** 2024
- **Source:** 建筑工程与设计
- **DOI / link:** https://www.2winpub.com/static/uploads/journalArticle/jzgcysj0306019.pdf
- **Why relevant:** Practice note on parametric BIM for bridge members in the design stage.

### BN06
- **Title:** BIM技术在桥梁工程设计阶段的应用研究
- **Authors:** (ResearchGate 2026 CN practice paper)
- **Year:** 2026
- **Source:** 工程实践 / ResearchGate
- **DOI / link:** https://www.researchgate.net/publication/405028839_BIMjishuzaiqiaolianggongchengshejijieduandeyingyongyanjiu
- **Why relevant:** Design-stage BIM application (scheme, quantities, checking, drawing, FEA).

### BN07
- **Title:** 绿色低碳技术在桥梁工程中的应用综述
- **Authors:** 贾宏宇 等
- **Year:** 2026
- **Source:** 西南交通大学学报
- **DOI / link:** https://doi.org/10.3969/j.issn.0258-2724.20260011
- **Why relevant:** Low-carbon *design choices* for long-span cable-stayed/suspension bridges.

---

**This batch listed:** 39 unique named Chinese items (theses/patents included; none are Batch 01–07 title duplicates).
