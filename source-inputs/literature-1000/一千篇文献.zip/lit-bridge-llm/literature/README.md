# Literature corpus — bridge design methods × agentic / LLM automation

Target: ~1000 unique records (journals, conferences, important preprints, codes/handbooks).
Window: 2016–2026, extra weight on 2023+ LLM/agent work. English-first, Chinese included.

## Status (this pass)

Title-normalized unique across **all** `batch-*.md` files: **≈ 1127**.
Listed entries: **1134** (7 internal dups live only inside Batches 01–06, already flagged there).

Batches 08–13 added **≈ 509** new unique titles vs Batches 01–07 (which sat at ~620 unique / ~625 listed). That crosses the ~1000 target without inventing placeholder clusters.

## Files

| File | Focus | Listed | Unique vs previous (honest) |
|---|---|---|---|
| [batch-01-core-90.md](batch-01-core-90.md) | Landmarks, traditional process, BrIM, ACC, generative, LLM/agent flagship | 99 | ~90 core |
| [batch-02.md](batch-02.md) | Type-specific optimization, NLP-ACC, KG, DT, remaining LLM | 122 | ~114 |
| [batch-03.md](batch-03.md) | ABC/UHPC, wind–seismic–fatigue, IFC/IDS/OpenSees, conferences | 108 | ~100 |
| [batch-04.md](batch-04.md) | Life-cycle/rating, IABSE, APIs, CNKI forward-design *series flags* | 76 | ~60 |
| [batch-05.md](batch-05.md) | Scan-to-BrIM, named JBE/UHPC, SMO, named CN projects | 80 | ~80 |
| [batch-06.md](batch-06.md) | AutCon 2025–26 LLM/BIM, IFC query, extra codes | 82 | ~70 (dups marked) |
| [batch-07.md](batch-07.md) | NADIA, JCCE LLM-QA, fine-tune ACC, House-GAN, extra Eurocodes | 58 | ~55 (dups marked) |
| [batch-08.md](batch-08.md) | AutCon 2023–2026 TOC: LLM / agent / ACC / generative / BrIM | 90 | **90 new** |
| [batch-09.md](batch-09.md) | *Journal of Bridge Engineering* design / ABC / UHPC / parametric / optimization | 90 | **90 new** |
| [batch-10.md](batch-10.md) | AEI, JCCE, Buildings, ECAM, ITcon, CACAIE: LLM, ACC, KG, BIM | 85 | **85 new** |
| [batch-11.md](batch-11.md) | ICE *Bridge Engineering*, IABSE SEI, Eng. Structures, SMO, JCSR, *Structural Concrete* | 85 | **85 new** |
| [batch-12.md](batch-12.md) | ISARC 2025–2026 filtered full papers + leftover high-fit journals/preprints | 120 | **120 new** |
| [batch-13.md](batch-13.md) | Named CNKI / 《中国公路学报》《中外公路》《世界桥梁》/ theses | 39 | **~39 new** |
| **Running unique (title-normalized)** | | **1134 listed** | **≈ 1127** |

Series flags in Batches 04–05 are *indexes* of project clusters; later batches explode those clusters into named papers. Do not add the series flag and the exploded paper as two research items.

## Two spines (keep both)

1. **Traditional / computational design process**  
   Conceptual → preliminary → detailed; AASHTO / Eurocode / JTG; type selection; cable-force and TO; parametric BrIM; IFC 4.3; ACC; digital twins; ABC/UHPC.

2. **Agentic / LLM automation**  
   Text2BIM, BIM copilots, MCP/IFC tools, MASSE/OpenSees agents, AutoBIM for prefabricated bridges, LLM-ACC, NADIA detailing, verification loops.

## What Batches 08–13 actually harvested

1. *Automation in Construction* 2023–2026, filtered LLM / BIM / ACC / generative / bridge (Batch 08).
2. *Journal of Bridge Engineering* design / optimization / ABC / UHPC / parametric (Batch 09).
3. AEI + JCCE + Buildings + ECAM + ITcon (Batch 10).
4. ICE *Bridge Engineering* + IABSE SEI + Engineering Structures / SMO / JCSR (Batch 11).
5. ISARC 2025 (Montreal) and ISARC 2026 (Singapore) full-paper TOC, filtered (Batch 12).
6. 《中国公路学报》2026 大模型/IFC-graph 专栏, 《中外公路》2023–2025 参数化/交付/审查, 学位论文 (Batch 13).

## Dedup rule

Before adding an entry, grep titles in this folder:

```bash
rg -i "exact title fragment" literature/
```

Crossref DOIs were used for English journals/ISARC. Many CNKI DOIs (`10.19721/…`, `10.14048/…`) are journal-native and may not resolve on doi.org; the journal URL is the working link.
