# Batch 09 — Journal of Bridge Engineering 2016–2026: design methods, ABC/UHPC, optimization, parametric

Scope: unique vs. Batches 01–08. Named JBE papers on conceptual/preliminary/detailed design, UHPC and ABC systems, cable-force and member optimization, and BIM/parametric frameworks.


## BA. Conceptual, preliminary, parametric and optimization design

### BA01
- **Title:** Conceptual Design of a Novel UHPC-NC Hybrid Continuous Box-Girder System with Controllable Long-Term Deflection
- **Authors:** Zihao Luo, Weikun He, Hua Zhao, et al.
- **Year:** 2026
- **Source:** Journal of Bridge Engineering 31(8), 04026039
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-8142
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BA02
- **Title:** Parametric Design Framework of a Composite Footbridge Featuring Ultimate and Vibration Serviceability Limit States
- **Authors:** Denn’s S. Perônica, Roberto L. Pimentel, Felipe T. da Silva
- **Year:** 2026
- **Source:** Journal of Bridge Engineering 31(8), 04026041
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7841
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.

### BA03
- **Title:** Cable Force Identification of Stayed Cables Considering the Interference of an External Damper
- **Authors:** Lan-Ying Luo, Yan-Liang Du, Ting-Hua Yi, Chun-Xu Qu, Sheng-Jie Zhao, Xin-Liang Liu
- **Year:** 2026
- **Source:** Journal of Bridge Engineering 31(5), 04026017
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-8024
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BA04
- **Title:** Flutter Control by a Multiunit Gyroscopic Stabilizer: Deterministic-Stochastic Analysis of the Messina Strait Bridge Prototype Design
- **Authors:** Gian Felice Giaccu, Luca Caracoglia
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(5), 06025001
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7059
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 2

### BA05
- **Title:** Probabilistic Identification Method of Cable Force Considering Uncertain and Missing Modal Frequencies
- **Authors:** Yonghui An, Boxu Wang, Wei Zhu, Binbin Li, Jinping Ou
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(4), 04025007
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6977
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BA06
- **Title:** Evaluating Flexural Stiffness Equations for the Stability Design of Slender-Reinforced Concrete Bridge Columns
- **Authors:** Javad Esmaeelpour, Mark D. Denavit, Michael H. Scott
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(11), 04025068
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7680
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BA07
- **Title:** Biobjective Optimization of Cable Force for Concrete Cable-Stayed Bridges Considering the Requirements of the Serviceability and Ultimate Limit State
- **Authors:** Hongyou Cao, Huiyang Li, Yunhua Zhou, Zhi Li, Liuyang Feng
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(6), 04024026
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6572
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 9

### BA08
- **Title:** Joint Identification of Cable Force and Bending Stiffness Using Vehicle-Induced Cable–Beam Vibration Responses
- **Authors:** Lan-Ying Luo, Yan-Liang Du, Ting-Hua Yi, Song-Han Zhang
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(2), 04023117
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6555
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 7

### BA09
- **Title:** Piecewise-Fitted Formula for Cable Force Identification Considering Bending Stiffness, Sag, and Inclination
- **Authors:** Lan-Ying Luo, Yan-Liang Du, Ting-Hua Yi, Chun-Xu Qu, Song-Han Zhang, Tie-Suo Geng
- **Year:** 2023
- **Source:** Journal of Bridge Engineering 28(7), 04023038
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6143
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 19

### BA10
- **Title:** Substructure Mass Participation Effect on the Performance-Based Seismic Design Method for Isolated Bridges
- **Authors:** Mahsa Rasouli, Mahmoud R. Shiravand, Reza Rasti Ardakani
- **Year:** 2023
- **Source:** Journal of Bridge Engineering 28(12), 04023095
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6219
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 15

### BA11
- **Title:** Preliminary Design of a Steel–UHPFRC Composite Truss Arch Bridge and Model Tests of K-Joints
- **Authors:** Guang He, Xudong Shao, Yubao Chen, Ping Ouyang, Dongbo Zhang
- **Year:** 2022
- **Source:** Journal of Bridge Engineering 27(10), 04022090
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001921
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 15

### BA12
- **Title:** Simplified Risk-Targeted Performance-Based Seismic Design Method for Ordinary Standard Bridges
- **Authors:** Angshuman Deb, Alex L. Zha, Zachary A. Caamaño-Withall, Joel P. Conte, José I. Restrepo
- **Year:** 2022
- **Source:** Journal of Bridge Engineering 27(10), 04022089
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001916
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 7

### BA13
- **Title:** Scaling Factors Quantifying Seismic Load Uncertainty with Soil Nonlinearity Effect in Displacement-Based Design of Bridge Abutments
- **Authors:** Prajakta R. Jadhav, Amit Prashant
- **Year:** 2022
- **Source:** Journal of Bridge Engineering 27(11), 04022110
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001956
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BA14
- **Title:** Parametric Experimental Study of Ultra-Short Stud Connections for Lightweight Steel–UHPC Composite Bridges
- **Authors:** Qizhi Xu, Wendel Sebastian, Kaiwei Lu, Yiming Yao, Jingquan Wang
- **Year:** 2022
- **Source:** Journal of Bridge Engineering 27(2), 04021108
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001821
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 32

### BA15
- **Title:** Composite Steel Tee Concrete Deck Bridge System: Design, Fabrication, and Full-Scale Verification
- **Authors:** Clay J. Naito, Robin Hendricks, Richard Sause, Christina Cercone
- **Year:** 2021
- **Source:** Journal of Bridge Engineering 26(1), 04020109
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001652
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 5

### BA16
- **Title:** Evaluation of Regionally Calibrated Load and Resistance Factor-Design Method Used for Driven-Steel H-Piles
- **Authors:** Shawn Sersland, Mike Nop, Sri Sritharan, Philippe Kalmogo
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(8), 04020061
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001597
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 3

### BA17
- **Title:** Behavior and Design of Bridge Piers Subjected to Heavy Truck Collision
- **Authors:** Ran Cao, Sherif El-Tawil, Anil Kumar Agrawal, Xiaochen Xu, Waider Wong
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(7), 04019057
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001414
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 49

### BA18
- **Title:** Loading Definition and Design of Bridge Piers Impacted by Medium-Weight Trucks
- **Authors:** Xiaochen Xu, Ran Cao, Sherif El-Tawil, Anil Kumar Agrawal, Waider Wong
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(6), 04019042
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001397
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 37

### BA19
- **Title:** Design of Horizontally Curved Steel Bridge Girders with Tubular Flanges
- **Authors:** Haiying Ma, Richard Sause, Jun Dong
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(6), 04019040
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001403
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 9

### BA20
- **Title:** Model Test and Optimal Design of the Joint in a Sunflower Arch Bridge
- **Authors:** Yonghui Huang, Jiyang Fu, Airong Liu, Rui Rao, Di Wu, Jianwen Shen
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(2), 04018121
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001349
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 5

### BA21
- **Title:** Procedures and Guidelines for Design of Lateral Bridge Slide Activities
- **Authors:** Upul Attanayake, Haluk Aktan
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(9), 04019093
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001476
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BA22
- **Title:** Shape Optimization of UHPC Shear Keys for Precast, Prestressed, Adjacent Box-Girder Bridges
- **Authors:** Husam H. Hussein, Shad M. Sargand, Eric P. Steinberg
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(4), 04018009
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001220
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 46

### BA23
- **Title:** Mechanistic Deterioration Modeling for Bridge Design and Management
- **Authors:** Kyle Nickless, Rebecca A. Atadero
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(5), 04018018
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001223
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 24

### BA24
- **Title:** Simplified Design Method for the Shear Capacity of Steel Plate Shear-Strengthened Reinforced-Concrete Beams
- **Authors:** Jia-Ji Wang, Meng Zhou, Xin Nie, Jian-Sheng Fan, Mu-Xuan Tao
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(11), 04018089
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001310
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 14

### BA25
- **Title:** Conceptual Design of a New Three-Tower Cable-Stayed Bridge System with Unequal-Size Fans
- **Authors:** Xudong Shao, Fuhao Deng, Lu Deng
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(7), 06018002
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001257
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 12

### BA26
- **Title:** Reduction of Seismic Acceleration Parameters for Temporary Bridge Design
- **Authors:** Conor Stucki, Michel Bruneau
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(10), 04018081
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001292
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 2

### BA27
- **Title:** Seismic Vulnerability Assessment and Retrofitting Design of a Multispan Highway Bridge: Case Study
- **Authors:** Francesco Lo Monte, Chiara Pozzuoli, Elena Mola, Franco Mola
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(2), 05017016
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001148
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 2

### BA28
- **Title:** Conceptual Design of Modular Bridges Including Layout Optimization and Component Reusability
- **Authors:** Alexis Tugilimana, Ashley P. Thrall, Rajan Filomeno Coelho
- **Year:** 2017
- **Source:** Journal of Bridge Engineering 22(11), 04017094
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001138
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 19

### BA29
- **Title:** Simplified Displacement Loading Patterns for Incorporation of Spatially Variable Ground Motions in Bridge Seismic Design Codes
- **Authors:** M. R. Falamarz-Sheikhabadi, A. Zerva
- **Year:** 2017
- **Source:** Journal of Bridge Engineering 22(6), 04017010
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001035
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 13

### BA30
- **Title:** Bridge Design Framework for Target Seismic Loss
- **Authors:** Behzad Zakeri, Farzin Zareian
- **Year:** 2017
- **Source:** Journal of Bridge Engineering 22(10), 04017061
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001075
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 8

### BA31
- **Title:** Bridge Decks with Precast UHPC Waffle Panels: A Field Evaluation and Design Optimization
- **Authors:** Ebadollah Honarvar, Sri Sritharan, Jon Matthews Rouse, Sriram Aaleti
- **Year:** 2016
- **Source:** Journal of Bridge Engineering 21(1), 04015030
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0000775
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 45

### BA32
- **Title:** Prestressing Optimization and Local Reinforcement Design for a Mixed Externally and Internally Prestressed Precast Segmental Bridge
- **Authors:** Dong Xu, Jun Lei, Yu Zhao
- **Year:** 2016
- **Source:** Journal of Bridge Engineering 21(7), 05016003
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0000904
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 5


## BB. UHPC / ABC / composite detailed-design systems

### BB01
- **Title:** Ultrahigh-Performance Concrete Bridge Deck Overlays: Fundamental Concepts and Design Example
- **Authors:** Anuoluwa Adediji, Zachary B. Haber, Andrew Foden, Omid Souri
- **Year:** 2026
- **Source:** Journal of Bridge Engineering 31(10), 04026058
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7982
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.

### BB02
- **Title:** Reliability Evaluation of Punching Shear Capacity Design Provision for UHPC Bridge Slabs
- **Authors:** Minghong Qiu, Xudong Shao, Zhenyu Tao, Jingyu Lu, Junhui Cao, Jiahui Feng
- **Year:** 2026
- **Source:** Journal of Bridge Engineering 31(10), 04026055
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7880
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.

### BB03
- **Title:** Experimental and Theoretical Research on Bending Performances of a New UHPC–Steel–Concrete Composite Section
- **Authors:** Jun Luo, Yuxin Wang, Min Liu, et al.
- **Year:** 2026
- **Source:** Journal of Bridge Engineering 31(4), 04026008
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7659
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.

### BB04
- **Title:** Flexural Behavior of Steel-UHPC-NC Composite Girders with Different UHPC-NC Interface Treatments
- **Authors:** Jing-Wei Zhu, Yu Pan, Jun-Ping Liu, Mostafa Fahmi Hassanein, Hai-Ting Li
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(7), 04025047
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7376
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 6

### BB05
- **Title:** Full-Scale Precast UHPC–Postcast NC Hollow Composite Slab: Interface Technique Validation
- **Authors:** Jindong Yang, Yanping Zhu, Junfeng Qiu, et al.
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(5), 05025003
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7013
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 3

### BB06
- **Title:** Evaluation of the Performance of UHPC- and HCSC-Filled Noncontact Lap Splice Closure Joint Used for Lateral Slide-in Bridge Construction
- **Authors:** Abdalla Alomari, Justin Dahlberg, Brent M. Phares, Zhengyu Liu
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(6), 04025028
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7201
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 3

### BB07
- **Title:** Development and Performance of a Composite UHPC Box-Beam Bridge Section
- **Authors:** Huaian Zhang, Clay Naito, Farshad Rajabipour
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(11), 04025069
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7395
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 1

### BB08
- **Title:** Shear Behavior and Capacity of UHPC Double-Keyed Joints Subjected to Direct Shear Loading
- **Authors:** Yang Zhang, Hao Tang, Feihu He, et al.
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(12), 04025076
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7682
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.

### BB09
- **Title:** Application of Lightweight Steel-Plate–Reinforced Ribbed UHPC Deck Panel in a Long-Span Suspension Bridge
- **Authors:** Yan Wang, Xudong Shao, Shuhong Wang, Meng Chen, Changhao Li, Peng Cui
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(2), 05023011
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6487
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 8

### BB10
- **Title:** A Strut-and-Tie Model Approach to Design Precast Column-to-Pile Shaft Member Socket Connections against Prying-Action Failure
- **Authors:** Haifeng He, Mingsai Xu, Cancan Yang
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(5), 04024019
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6352
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 6

### BB11
- **Title:** Flexural Performance of Ultrathin UHPC Slab–Steel Composite Beams with Ultrashort Stud Connections
- **Authors:** Qizhi Xu, Wendel Sebastian, Jingquan Wang
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(5), 04024022
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6492
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 6

### BB12
- **Title:** Flexural Performance of SSK Reinforced Steel–UHPC Composite Beams: Experimental and Numerical Study
- **Authors:** Zhiwen Zhang, Zhongwei Guan, Wenjie Ge, Yan Liu, Shengcai Li, Dafu Cao
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(2), 05023012
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6493
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 4

### BB13
- **Title:** Strengthening of Steel Through-Girder Bridges Using UHPC and Post-Tensioning
- **Authors:** Zachary B. Haber, Benjamin A. Graybeal
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(3), 04024004
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6272
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 3

### BB14
- **Title:** UHPC Connection Details for Simple for Dead Load and Continuous for Live Load Steel Bridges in Nonseismic Areas
- **Authors:** Abbas Khodayari, Amir Sadeghnejad, Atorod Azizinamini
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(10), 04024079
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6644
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 3

### BB15
- **Title:** Flexural Behavior and Model of Curved Bolt Connections with UHPC Grout and CFRP Tendons for Prefabricated Concrete Panels
- **Authors:** Menghan Hu, Zhenlei Jia, Yulong Ni, Qiang Han
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(5), 04024017
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6650
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 3

### BB16
- **Title:** Flexural Behavior on a Steel–UHPC Composite Deck System of Long-Span Bridges
- **Authors:** Chengjun Tan, Zihao Luo, Hua Zhao, et al.
- **Year:** 2023
- **Source:** Journal of Bridge Engineering 28(9), 04023062
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6323
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 30

### BB17
- **Title:** Experimental Study on the Flexural Behavior of a Novel Nonprismatic Prestressed UHPC Composite Box Girder with Corrugated Steel Webs
- **Authors:** Huihui Li, Lifeng Li, Chunjin Du, Meng Ye, Xudong Shao, Cong Zhou
- **Year:** 2023
- **Source:** Journal of Bridge Engineering 28(7), 04023045
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6038
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 25

### BB18
- **Title:** Experimental Study on the Shear Behavior of UHPC-Strengthened Concrete T-Beams
- **Authors:** Tongxu Liu, Jean-Philippe Charron
- **Year:** 2023
- **Source:** Journal of Bridge Engineering 28(9), 04023064
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6122
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 19

### BB19
- **Title:** Design Verification of a New Socket Partially Embedded Connection between Precast Rectangular Columns and Stepped Pile Caps
- **Authors:** Zeng Zeng, Yan Xu, Hai Yan, Xin Qi
- **Year:** 2023
- **Source:** Journal of Bridge Engineering 28(2), 04022150
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-5815
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 12

### BB20
- **Title:** Cyclic Behavior of Precast Double-Column Bridge Bents with Lap Splice Connections by UHPC
- **Authors:** Jianfeng Gao, Nailiang Xiang, Jianzhong Li, Wenjing Xu
- **Year:** 2023
- **Source:** Journal of Bridge Engineering 28(7), 04023035
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6041
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 10

### BB21
- **Title:** Flexural Response of GFRP–UHPC Composite Slabs under a Hogging Moment
- **Authors:** Dan Zeng, Lei Cao, Yang Liu, Zhaochao Li, Hongpeng Li
- **Year:** 2023
- **Source:** Journal of Bridge Engineering 28(11), 04023082
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6383
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 6

### BB22
- **Title:** Direct Shear Strength of UHPC Large-Keyed Epoxy Joint: Theoretical Model and Experimental Verification
- **Authors:** Rensheng Pan, Weiwei He, Lingxiao Cheng, Chuanxi Li
- **Year:** 2022
- **Source:** Journal of Bridge Engineering 27(9), 04022083
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001936
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 27

### BB23
- **Title:** Flexural Behavior of Steel–UHPC Composite Beams with Waffle Slabs under Hogging Moment
- **Authors:** Jinsong Zhu, Xiuce Wang, Jingnan Ding, Cong Wang
- **Year:** 2022
- **Source:** Journal of Bridge Engineering 27(11), 04022100
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001944
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 6

### BB24
- **Title:** Cost-Effective UHPC for Accelerated Bridge Construction: Material Properties, Structural Elements, and Structural Applications
- **Authors:** Jingquan Wang, Jiaping Liu, Zhen Wang, Tongxu Liu, Jianzhong Liu, Jian Zhang
- **Year:** 2021
- **Source:** Journal of Bridge Engineering 26(2), 04020117
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001660
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 89

### BB25
- **Title:** Shear Strengthening of Corroded RC Beams Using UHPC–FRP Composites
- **Authors:** Cheng Chen, Haiyang Cai, Lijuan Cheng
- **Year:** 2021
- **Source:** Journal of Bridge Engineering 26(1), 04020111
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001653
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 60

### BB26
- **Title:** Experimental Investigation of Flexural Behavior of Steel–UHPC Composite Beam with Waffle-Slab System
- **Authors:** Jinsong Zhu, Xiaoyu Guo, Jingfu Kang, Menghao Duan, Yongguang Wang
- **Year:** 2021
- **Source:** Journal of Bridge Engineering 26(4), 04021011
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001695
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 27

### BB27
- **Title:** Transverse Joint Design of Small–Medium-Span Fully Precast Steel–UHPC Lightweight Composite Bridge
- **Authors:** Shuwen Deng, Xudong Shao, Banfu Yan, Xudong Zhao, Yang Wang
- **Year:** 2021
- **Source:** Journal of Bridge Engineering 26(8), 04021046
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001745
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 25

### BB28
- **Title:** Structural Behaviors of a Low-Profile Steel Plate–Reinforced UHPC Deck Panel with Longitudinal Ribs
- **Authors:** Yan Wang, Xudong Shao, Xin Zhang, Junhui Cao, Xudong Zhao, Shuwen Deng
- **Year:** 2021
- **Source:** Journal of Bridge Engineering 26(8), 04021043
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001731
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 25

### BB29
- **Title:** Biaxial Seismic Performance of a Two-Span Concrete Bridge Model with Six ABC Connections
- **Authors:** José Benjumea, M. “Saiid” Saiidi, Ahmad Itani
- **Year:** 2021
- **Source:** Journal of Bridge Engineering 26(8), 04021056
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001753
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 2

### BB30
- **Title:** Flexural Study on UHPC–Steel Composite Beams with Joints under Negative Bending Moment
- **Authors:** Yanping Zhu, Yang Zhang, Husam H. Hussein, Shukun Cai
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(10), 04020084
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001619
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 46

### BB31
- **Title:** Flexural Performance of Composite Prestressed UHPC-NC T-Girders
- **Authors:** Wangwang Li, Wenyu Ji, Mingzhe An, Li Zhu, Jue Wang
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(9), 04020064
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001600
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 36

### BB32
- **Title:** Experimental Study on Shear Behavior of a UHPC Connection Between Adjacent Precast Prestressed Concrete Voided Beams
- **Authors:** Haibo Jiang, Xiaotong Dong, Zhuangchen Fang, Jie Xiao, Ying Chen
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(12), 04020106
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001644
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 35

### BB33
- **Title:** Experimental Evaluation of Full-Scale Corroded Steel Plate Girders Repaired with UHPC
- **Authors:** Kevin F. McMullen, Arash E. Zaghi
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(4), 04020011
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001535
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 32

### BB34
- **Title:** Experimental and Numerical Investigation on the Anchorage Zone of Prestressed UHPC Box-Girder Bridge
- **Authors:** Chuanxi Li, Zheng Feng, Rensheng Pan, Lu Ke, Jun He, Shuai Dong
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(6), 04020028
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001556
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 28

### BB35
- **Title:** Full-Scale Experimental Verification of UHPC-RC Composite Slab Culvert with a Clear Span of 8 m
- **Authors:** Banfu Yan, Minghong Qiu, Tiansheng Zeng, Xudong Shao, Yanping Zhu, Mian Li
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(12), 05020010
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001640
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 25

### BB36
- **Title:** Flexural Behavior of a Fully Prefabricated Lightweight UHPC Bent Cap
- **Authors:** Meng Ye, Lifeng Li, Fangjian Hu, Xudong Shao, Jinliang Tang
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(10), 04020085
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001605
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 23

### BB37
- **Title:** Ultimate Behavior of Deck-to-Girder Composite Connection Details Using UHPC
- **Authors:** Zachary B. Haber, Benjamin A. Graybeal, Brian Nakashoji
- **Year:** 2020
- **Source:** Journal of Bridge Engineering 25(7), 04020038
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001574
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 19

### BB38
- **Title:** Quantifying Bonding Characteristics between UHPC and Normal-Strength Concrete for Bridge Deck Application
- **Authors:** Sriram Aaleti, Sri Sritharan
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(6), 04019041
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001404
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 129

### BB39
- **Title:** Low-Damage Seismic Design for Accelerated Bridge Construction
- **Authors:** Mustafa Mashal, Alessandro Palermo
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(7), 04019066
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001406
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 120

### BB40
- **Title:** Shear Strength of Dry Joints in Precast UHPC Segmental Bridges: Experimental and Theoretical Research
- **Authors:** Tongxu Liu, Zhen Wang, Jian Guo, Jingquan Wang
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(1), 04018100
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001323
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 113

### BB41
- **Title:** Retrofitting of Bridge Columns Using UHPC
- **Authors:** Mahsa Farzad, Mohamadreza Shafieifar, Atorod Azizinamini
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(12), 04019121
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001497
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 98

### BB42
- **Title:** Lateral Behavior of Precast Segmental UHPC Bridge Columns Based on the Equivalent Plastic-Hinge Model
- **Authors:** Zhen Wang, Jingquan Wang, Yuchuan Tang, Yufeng Gao, Jian Zhang
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(3), 04018124
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001332
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 64

### BB43
- **Title:** Experimental Study on Basic Performances of Reinforced UHPC Bridge Deck with Coarse Aggregates
- **Authors:** Yan Wang, Xudong Shao, Junhui Cao
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(12), 04019119
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001492
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 57

### BB44
- **Title:** Structural Evaluation of Steel–Concrete Joint with UHPC Grout in Single Cable–Plane Hybrid Cable-Stayed Bridges
- **Authors:** Shaohua He, Ayman S. Mosallam, Zhi Fang, Liyang Liu
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(4), 04019022
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001379
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 35

### BB45
- **Title:** Design, Construction, and Shake Table Testing of a Steel Girder Bridge System with ABC Connections
- **Authors:** Elmira Shoushtari, M. Saiid Saiidi, Ahmad Itani, Mohamed A. Moustafa
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(9), 04019088
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001464
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 27

### BB46
- **Title:** Effects of Temperature Distributions on Thermally Induced Behavior of UHPC Shear Key Connections of an Adjacent Precast Prestressed Concrete Box Beam Bridge
- **Authors:** Ali A. Semendary, Eric P. Steinberg, Kenneth K. Walsh, Elné Barnard
- **Year:** 2019
- **Source:** Journal of Bridge Engineering 24(2), 04018115
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001346
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 14

### BB47
- **Title:** Lap-Spliced Rebar Connections with UHPC Closures
- **Authors:** Zachary B. Haber, Benjamin A. Graybeal
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(6), 04018028
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001239
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 70

### BB48
- **Title:** Fatigue Assessment of Steel-UHPC Lightweight Composite Deck Based on Multiscale FE Analysis: Case Study
- **Authors:** Xudong Shao, Junhui Cao
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(1), 05017015
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001146
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 67

### BB49
- **Title:** NC-UHPC Composite Structure for Long-Term Creep-Induced Deflection Control in Continuous Box-Girder Bridges
- **Authors:** Yang Zhang, Ping Zhu, Yanping Zhu, Chao Bao, Xudong Shao, Janqun Shi
- **Year:** 2018
- **Source:** Journal of Bridge Engineering 23(6), 04018034
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001241
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 23

### BB50
- **Title:** Experimental Study of UHPC Repair for Corrosion-Damaged Steel Girder Ends
- **Authors:** Kevin M. Zmetra, Kevin F. McMullen, Arash E. Zaghi, Kay Wille
- **Year:** 2017
- **Source:** Journal of Bridge Engineering 22(8), 04017037
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001067
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 70

### BB51
- **Title:** Design and Behavior of UHPFRC Field-Cast Transverse Connections between Precast Bridge Deck Elements
- **Authors:** Sébastien Verger-Leboeuf, Jean-Philippe Charron, Bruno Massicotte
- **Year:** 2017
- **Source:** Journal of Bridge Engineering 22(7), 04017031
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001064
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 51

### BB52
- **Title:** Lightweight UHPC-FRP Composite Deck System
- **Authors:** Munaf A. Al-Ramahee, Titchenda Chan, Kevin R. Mackie, Sahar Ghasemi, Amir Mirmiran
- **Year:** 2017
- **Source:** Journal of Bridge Engineering 22(7), 04017022
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001049
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 33

### BB53
- **Title:** Early-Age Behavior of an Adjacent Prestressed Concrete Box-Beam Bridge Containing UHPC Shear Keys with Transverse Dowels
- **Authors:** Ali A. Semendary, Kenneth K. Walsh, Eric P. Steinberg
- **Year:** 2017
- **Source:** Journal of Bridge Engineering 22(5), 04017007
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0001034
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 19

### BB54
- **Title:** Effects of Partial-Design-Strength Concrete on the Seismic Performance of Concrete-Filled Tube Columns in Accelerated Bridge Construction
- **Authors:** Catherine Tucker, Luis Ibarra
- **Year:** 2016
- **Source:** Journal of Bridge Engineering 21(6), 04016023
- **DOI / link:** https://doi.org/10.1061/(asce)be.1943-5592.0000812
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.
- **Cites (Crossref):** 5


## BC. Additional JBE design-method papers

### BC01
- **Title:** Performance-Based Design and Hazard-Based Risk of Temporary Bridges with Light-Weight Superstructures in California
- **Authors:** SeyyedMahdi Kashizadeh, Floriana Petrone, Sashi Kunnath
- **Year:** 2025
- **Source:** Journal of Bridge Engineering 30(12), 04025074
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-7483
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.

### BC02
- **Title:** John A. Roebling’s 1845 Allegheny Aqueduct: Design, History, and Performance
- **Authors:** Stephen G. Buonopane, Dario A. Gasparini
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(2), 04023108
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6458
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.
- **Cites (Crossref):** 3

### BC03
- **Title:** Performance-Based Seismic Design for Retrofitting Deficient Bridge Bents: Developing Performance-Based Damage States
- **Authors:** Abu Obayed Chowdhury, A. H. M. Muntasir Billah, M. Shahria Alam
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(7), 04024046
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6236
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.
- **Cites (Crossref):** 3

### BC04
- **Title:** John A. Roebling’s 1846 Smithfield Street Bridge: History, Design, and Performance
- **Authors:** Stephen G. Buonopane, Dario A. Gasparini
- **Year:** 2024
- **Source:** Journal of Bridge Engineering 29(2), 04023113
- **DOI / link:** https://doi.org/10.1061/jbenf2.beeng-6459
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.
- **Cites (Crossref):** 2


---

**This batch listed:** 90 unique named items (deduped vs Batches 01–07 and earlier 08+).
