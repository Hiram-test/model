# Batch 12 — ISARC 2025–2026 + remaining high-fit journals and preprints

Scope: unique vs. Batches 01–11. Filtered full papers from ISARC 2025 (Montreal) and ISARC 2026 (Singapore) on LLM agents, BIM/IFC, ACC, generative design and bridges, plus leftover high-fit journal/preprint items that did not fit Batches 08–11.


## BH. ISARC 2025–2026 — LLM agents, BIM/IFC, ACC, generative design, bridges

### BH01
- **Title:** Research on the Structure and Transmission of Enhanced IFC for LLM-Driven Intelligent Design
- **Authors:** Yuwen Chen, Ziyang Jiang, Zhou Kaifeng, Zhao Xu
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0179
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH02
- **Title:** Retrieval-Augmented Generation and Multi-Agent Arbitration for Construction Code Compliance in AEC
- **Authors:** Hao Yin, Xichen Chen, Yang Zou, Liupengfei Wu
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0233
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.

### BH03
- **Title:** LLM-based Exploration of BIM Clash Information using Semantic Knowledge Graph
- **Authors:** Donguk Shin, Wonbok Lee, Hyunwoo Lee, et al.
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0091
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH04
- **Title:** LLM-Based BIM-DfS Framework for Phase-Specific Safety Mitigation Recommendations during the Design Stage
- **Authors:** Jaewook Jeong, Minsang Gu, Louis Kumi
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0100
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH05
- **Title:** Cognitive Scan-to-BIM: LLM-Driven Hyperparameter Optimization for Robust MEP Primitive Fitting in Complex Construction Environments
- **Authors:** Muhammad Talha, Rafiq Ahmad, Yitong Li, Omair Shafiq, Qipei Mei
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0184
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH06
- **Title:** BIM Design Assistant Driven by LLM Agents
- **Authors:** Jin Han, Sining Zhoubian, Xin-Zheng Lu, Zhen-Zhong Hu, Jun Ma, Jia-Rui Lin
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0227
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH07
- **Title:** Incremental IFC updates with 'why' and 'how': A case of IFC extension for LLM agent-enhanced simulation-based optimization for building energy efficiency
- **Authors:** Lingming Kong, Qianyun Zhou, Fan Xue
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0266
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH08
- **Title:** From 2D Drawings to BIM Models: An LLM-Assisted Approach
- **Authors:** Jean Viaunel Victor, Pavan Kumar, Shang-Hsien Hsieh
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0307
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH09
- **Title:** An LLM-Integrated BIM Workflow for Rapid Early-Stage Layout Generation of Worksite Trailers
- **Authors:** Pan Chao-Hsu, Li Ren-Jie, Tsai Liang-Ting, Yang Cheng-Hsuan, Tsai Meng-Han
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0317
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH10
- **Title:** Knowledge-Based Emergency Decision Support with Large Language Models and Structured Graph
- **Authors:** Fangzhou Lin, Zhengyi Chen, Mingkai Li, Boyu Wang, Xiao Zhang, Jack C.P. Cheng
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0014
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH11
- **Title:** LLM-Driven Adaptive Recovery for Multi-Agent Systems in Dynamic Environments
- **Authors:** Beril Yalcinkaya, Carlos A. P. Pizzino, Micael Couceiro, Salviano Soares, Antonio Valente
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0022
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH12
- **Title:** A Strongly Typed Assembly Agent for Construction Integrating Rhino and Multimodal Large Language Models
- **Authors:** Song Du, Wei Tong, Yiwei Weng
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0043
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH13
- **Title:** Phase-Adaptive Large Language Models for Multi-Robot Task Allocation in Dynamic Construction Environments
- **Authors:** Shyam Prasad Reddy Kaitha, Hongrui Yu
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0066
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH14
- **Title:** Crane Accident Investigation via LLM Reasoning: A System Thinking-guided Chain-of-Thought Approach
- **Authors:** Junyu Chen, Hung-lin Chi
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0102
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH15
- **Title:** Collaborative Safety Intelligence in Construction Sites through Agentic RAG Systems
- **Authors:** Alessandra Corneli, Tommaso Pieroni, Alessandro Carbonari, Berardo Naticchia
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0110
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH16
- **Title:** A proof-of-concept framework for LLM-augmented semantic web technologies for knowledge sharing and reuse in construction
- **Authors:** Zhen Zhang, Yang Zou, Johannes Dimyadi, Brian Guo
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0160
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH17
- **Title:** Domain-specific Large Language Model Pretraining for Construction Specification Review
- **Authors:** Shuyi Wang, Jinwoo Kim
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0172
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH18
- **Title:** A Hybrid Retrieval-Augmented Generation Driven Multi-Agent System for Quality Control in Off-Site Construction
- **Authors:** Fanfan Meng, Mi Pan, Wei Pan
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0175
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH19
- **Title:** In-Context Trajectory Learning for Construction Scheduling Using Large Language Models
- **Authors:** Shanika Manamperi, Wei Peng, Guomin Zhang
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0230
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH20
- **Title:** A Synergized LLM-KG Framework for Domain Knowledge Cognition
- **Authors:** Ruiyan Zheng, Jinying Xu
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0259
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH21
- **Title:** SAGE: A Knowledge-Grounded Multi-Agent Framework for Automated MEP Drawing Interpretation
- **Authors:** Vivek Vishwas Vichare, Pratik Khandelwal, Aditya Debnath, Divya Singh Rathore, Gauri Lamb, Paul O'Neill
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0319
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH22
- **Title:** RAG-LLM-Enhanced BIM for Automated Fall Hazard Detection and Prevention
- **Authors:** Mudasir Hussain, Tan Tan, Zhuoran Zhang, Yalan Mei
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0182
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH23
- **Title:** Automated BIM-Ready 3D Reconstruction from Muon Flux Tomography Data: An IFC-Based Integration Pipeline for Bridge Inspection
- **Authors:** Soheila Kookalani, Ioannis Brilakis, Sander Sein, et al.
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0186
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.

### BH24
- **Title:** An Automated Decision Support System for Pre-planning of Precast Bridge Installation using Heuristic-Based Simulation and Invariant Signatures
- **Authors:** Meta Soy, Zirui Hong, Fan Yang, Jiansong Zhang, Hubo Cai
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0009
- **Why relevant:** ABC/UHPC/precast bridge system design — a core contemporary detailed-design family.

### BH25
- **Title:** Automatic Geometry Extraction from Design Drawings and Design Compliance Checking for Steel Scaffolds
- **Authors:** Bing Sun, Boyu Wang, Chao Yin, Borja García de Soto, Jack C. P. Cheng
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0245
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.

### BH26
- **Title:** Knowledge-Enhanced Point Cloud Classification Model for Bridge Components
- **Authors:** Tao Yang, Yang Zou, Enrique del Rey Castillo, Weiwei Chen, Ajay Kumar Agrawal
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0224
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.

### BH27
- **Title:** Smart Bridge Sensing for Automated Vehicle Weight Estimation in Complex Traffic Scenarios
- **Authors:** Dawid Piotrowski, Marcin Jasi?ski, Artur Nowo?wiat, Piotr ?azi?ski, Qian Chen, Tony Yang
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0235
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.

### BH28
- **Title:** A Systematic Study on Instance-Level Bridge Point Cloud Segmentation under Cross-Type and Synthetic-Real Training Conditions
- **Authors:** Jeong Kyu Lee, Ui Chan Lee, Jong Won Ma
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0253
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.

### BH29
- **Title:** MiCRoadDiff: AI-driven generative design of on-site haul road for modular constructions using fine-tuned diffusion models
- **Authors:** Fangzheng Li, Rongyan Li, Hung-Lin Chi
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0216
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.

### BH30
- **Title:** BIM-Integrated AR for MEP field inspection: A Multi-modal Approach
- **Authors:** Zhidong Xu, Zhenan Feng, Nan Li, Mostafa Babaeian Jelodar, Brian H.W. Guo
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0027
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH31
- **Title:** An Automated Pipeline for Generating a Multi-Layered Spatial Map for Indoor Robot Navigation from BIM Data
- **Authors:** Festus Basimtaal Ayembilla, Taeyoung Kim, Min-Koo Kim, JoonOh Seo, Jung In KIM
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0030
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH32
- **Title:** A BIM-Driven Robotic Framework for Autonomous 3D Projection of Construction Layouts
- **Authors:** Zikang Wang, Huaquan Ying
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0064
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH33
- **Title:** BIM-Integrated Generation of Safety-Aware, Georeferenced Occupancy Grid Maps for Autonomous Masonry Robots
- **Authors:** Masoud Shakoorianfard, Jan Deubner, Christian Richter, Frank Will
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0078
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH34
- **Title:** BIM-Enabled On-Site Defect Detection for Tower-Crane Traction Wire Ropes via Transfer-Learned Lightweight YOLOv8 with GSConv-SE-SimAM
- **Authors:** Yongchao Xie, WenHao Li, Chenrun Dong, Yichuan Deng
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0096
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH35
- **Title:** A BIM-Based Automated System for Estimating Structural Temporary Support Cost and Schedule
- **Authors:** Tantri N. Handayani, Angga T. Yudhistira, Rezki Pertiwi, Risma Amelia, Veerasak Likhitruangsilp
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0111
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH36
- **Title:** Automating BIM Change Certification with Blockchain: A Case Study in Residential Building Design
- **Authors:** Reinaldo Valdebenito, Peter Waher, Eric Forcael, et al.
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0148
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH37
- **Title:** An Algorithmic Framework for the Automated Synchronization of Multi-Domain BIM Representations via Canonical Clustering
- **Authors:** Justin S. Lee, Ghang Lee
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0158
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH38
- **Title:** Training-Free Element Classification Aligned with BIM-driven Automated Construction Schedule Generation
- **Authors:** Steven Heung, Christoph Sydora, Eleni Stroulia
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0161
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH39
- **Title:** Scan-to-BIM: Edge-driven Pipeline to Facade Reconstruction
- **Authors:** Maxime Queruel, Stefan Bornhofen, Pierre Martin, Aymeric Histace
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0165
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH40
- **Title:** Multi-granularity infrastructure-BIM object classification and decomposition for highway project delivery
- **Authors:** Mengtian Yin, Junxiang Zhu, Xingbo Gong, Fengqiao Zhang, Yixiong Jing, Ioannis Brilakis
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0176
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH41
- **Title:** Neural Implicit Representations for IFC Objects: A Coordinate-Preserving Approach for Volumetric Spatial Reasoning
- **Authors:** Sang Du, Lei Hou, Guomin {Kevin} Zhang, Haosen Chen
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0190
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH42
- **Title:** BIM-Align: An Automatic Framework for BIM to As-Built Alignment with Multi-View Imagery and 3D Gaussian Splatting
- **Authors:** Guangan Chen, Michiel Vlaminck, Gianni Allebosch, Wilfried Philips, Hiep Luong
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0192
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH43
- **Title:** NUS3D: A BIM-Synthetic, Mobile-Scan and TLS Point Cloud Dataset for Robotic 3D Scene Understanding in Built Environment
- **Authors:** Vincent Gan, Mingkai Li, Jingxuan Li, Chao Yin, Boyu Wang
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0195
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH44
- **Title:** Automating Electrical Outlet and Circuit Assignment in BIM through AI-Assisted CAD-BIM Interoperability
- **Authors:** Luis Angel Cristancho, Kevin Daniel Torres Garcia, Omar Sanchez, Rodrigo F. Herrera, Karen Castañeda
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0199
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH45
- **Title:** Automated Scan-to-BIM Method for City-Scale Building Roof Reconstruction Using UAV Photogrammetry and Geospatial Building Footprints
- **Authors:** Boan Tao, Frédéric Bosché, Jiajun Li
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0205
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH46
- **Title:** Feasibility Assessment of a BIM-Driven Robotic Rebar Cage Assembly Framework for Ballastless Railway Track Slab Construction
- **Authors:** Ashritha Reddy Yeddula, Samson Mathew
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0206
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH47
- **Title:** Energy-Intelligent Forecasting for Taiwanese Office Buildings: Developing a BIM-Derived Dataset and Integrating Advanced AI Models
- **Authors:** Ngoc-Mai Nguyen, Minh-Tu Cao, Wei-Chih Wang
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0209
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH48
- **Title:** A BIM-based Ontology Method for Knowledge Representation in Light Gauge Steel Panel Assembly
- **Authors:** Mariana Marines Alvarado, Arash Hosseini Gourabpasi, Farzad Jalaei, Rafiq Ahmad
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0217
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH49
- **Title:** An integrated workflow based on UAS, GIS, and BIM for building envelope maintenance management
- **Authors:** Caio Lima, Vanessa Pacheco, Alisson Silva, et al.
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0220
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH50
- **Title:** BIM-based Hybrid Knowledge Graph based on DSL for Computational Design Rule Formalization
- **Authors:** Huzhou Deng, Dian Zhuang
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0229
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH51
- **Title:** Construction of BIM-FM Data Linkage Methods Based on Real Estate Ownership Forms and Implementation in Management Systems
- **Authors:** Ryoyu Tanaka, Kosei Ishida, Toshimasa Itaya, Kenji Ishihara
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0232
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH52
- **Title:** An automated approach to quantify exposure of informal urban settlements using UAV and Scan-to-BIM
- **Authors:** Mirian Ruth Merma Onofre, Christopher Joseph Nuñez Varillas, Carlos Francisco Davila de la Cruz, et al.
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0234
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH53
- **Title:** Intelligent Automation and Optimization of Structural Design in BIM-Based Workflows: Case Studies
- **Authors:** Tafraout Salim, Bourahla Nouredine
- **Year:** 2026
- **Source:** ISARC 2026 (Singapore)
- **DOI / link:** https://doi.org/10.22260/isarc2026/0247
- **Why relevant:** BIM automation, IFC semantics or parametric modelling underpinning computer-aided bridge design.

### BH54
- **Title:** Towards Agent: LLM-based Framework for Robotic Construction by Leveraging IFC
- **Authors:** Song Du, Yan Gao, Wei Tong, Yiwei Weng
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0048
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH55
- **Title:** Proof-of-Concept Framework of Integrating AI-based LLM Reasoning into BIM Workflows for Design Automation
- **Authors:** Jinwu Xiao, Cansu Coskun, Soowon Chang, Kyubyung Kang, Deniz Besiktepe
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0134
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BH56
- **Title:** A Large Language Model as an Assistant for Software-Independent Structural Analytical Model Review and Editing
- **Authors:** Justin S. Lee, Ghang Lee
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0009
- **Why relevant:** LLM tool-use on structural analysis/CAD — the verification loop of an agentic design process.

### BH57
- **Title:** LLM-PCPP: A novel robot prioritized coverage path planning approach for complex environments
- **Authors:** Zhaofeng Hu, Ci-Jyun Liang
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0034
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH58
- **Title:** How Reliable Are Large Language Models? Zero-Shot Detection of Construction Hazards
- **Authors:** Nishi Chaudhary, S M Jamil Uddin, Mahzabin Tamanna, Alex Albert, Abdur Rahman Shahid
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0085
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH59
- **Title:** RAG-Enhanced Safety Information Retrieval for Construction: Integration of Large Language Models with Domain-Specific Information
- **Authors:** Xianxiang Zhao, Advik Mehta, Falak Sethi, Brian Gue, Qipei Mei, Lingzi Wu
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0088
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH60
- **Title:** Ontology-driven LLM framework for knowledge graph in smart buildings
- **Authors:** Sebastien Gerin, Laurent Joblot, Nisrine Makhoul, Frederic Merienne
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0137
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH61
- **Title:** Knowledge-Based Systems in the Era of Large Language Models: A Case Study in Fire Safety Management
- **Authors:** Dilan Durmus, Shabtai Isaac, Alessandro Carbonari, Alberto Giretti
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0209
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BH62
- **Title:** IFC Schema Extension for BIM-based Automated Code Checking of Korean Design Standards for Bridges
- **Authors:** Wonbok Lee, Youngsu Yu, Bonsang Koo, Bonghyuck Choi, Seunghwan Lee
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0121
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.

### BH63
- **Title:** Enhancing Circular Construction Through Structural Steel Reuse: Case Study of Champlain Bridge
- **Authors:** Dina Abouhelal, Amin Hammad
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0090
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.

### BH64
- **Title:** Automated Extraction of Structural Elements and Section Views from Bridge Drawings Using Deep Learning
- **Authors:** Hakan Bayer, Markus König
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0133
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.

### BH65
- **Title:** On-site Semantic Mapping and Waypoint Planning for Autonomous Aerial Bridge Monitoring
- **Authors:** Yohan Kim, Sunwoong Paik, Hyoungkwan Kim
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0158
- **Why relevant:** Bridge engineering design, optimization or information-modelling paper on the traditional-methods spine.

### BH66
- **Title:** Design Optimization of Steel Structures with Reused Components Using Generative Design
- **Authors:** Golnaz Mirzaei, Amin Hammad, Faraeen Homayounfard
- **Year:** 2025
- **Source:** ISARC 2025 (Montreal)
- **DOI / link:** https://doi.org/10.22260/isarc2025/0094
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.

### BH67
- **Title:** Automated Clash Resolution of Rebar Design in RC Joints using Multi-Agent Reinforcement Learning and BIM
- **Authors:** Jiepeng Liu, Pengkun Liu, Liang Feng, Wenbo Wu, Hao Lan
- **Year:** 2019
- **Source:** Proceedings of the International Symposium on Automation and Robotics in Construction (IAARC), Proceedings of the 36th International Symposium on Automation and Robotics in Construction (ISARC)
- **DOI / link:** https://doi.org/10.22260/isarc2019/0123
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 4

### BH68
- **Title:** Integration of BIM and FEA in Automation of Building and Bridge Engineering Design
- **Authors:** F. Fedorik, T. Makkonen, R. Heikkilä
- **Year:** 2016
- **Source:** Proceedings of the International Symposium on Automation and Robotics in Construction (IAARC), Proceedings of the 33rd International Symposium on Automation and Robotics in Construction (ISARC)
- **DOI / link:** https://doi.org/10.22260/isarc2016/0089
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 9

### BH69
- **Title:** Parametric Library Components for BIM-Based Curtain Wall Design Automation Module
- **Authors:** Beomjun Kim, Sangyoon Chin
- **Year:** 2016
- **Source:** Proceedings of the International Symposium on Automation and Robotics in Construction (IAARC), Proceedings of the 33rd International Symposium on Automation and Robotics in Construction (ISARC)
- **DOI / link:** https://doi.org/10.22260/isarc2016/0029
- **Why relevant:** Generative/parametric structural design whose representation and search methods transfer to bridge scheme generation.


## BI. Remaining high-fit journals / preprints (2023–2026 first)

### BI01
- **Title:** Four-Dimensional Fire Safety Knowledge-Enhanced Large Language Model for BIM Compliance Checking
- **Authors:** Yicheng Zhao, Zhoupeng Wang, Xingbo Gong, Xingyu Tao
- **Year:** 2026
- **Source:** Proceedings of the International Symposium on Automation and Robotics in Construction (IAARC), Proceedings of the 43rd International Symposium on Automation and Robotics in Construction
- **DOI / link:** https://doi.org/10.22260/isarc2026/0170
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.

### BI02
- **Title:** Assessing the Viability of LLM Agents for Generating Reusable Compliance Checking Functions
- **Authors:** Stefan Fuchs, Sylvain Hellin, André Borrmann
- **Year:** 2026
- **Source:** Computing in Construction, Proceedings of the 2026 European Conference on Computing in Construction 7
- **DOI / link:** https://doi.org/10.35490/ec3.2026.318
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.

### BI03
- **Title:** A Hybrid Framework for Intelligent Bridge Maintenance by Integrating Deep Learning and Large Language Models
- **Authors:** Mkhuzo Zulu, Tiexin Wang
- **Year:** 2026
- **Source:** (source not in metadata)
- **DOI / link:** https://doi.org/10.2139/ssrn.6843649
- **Why relevant:** LLM applied to bridge engineering (specs, drawings, BrIM or design support) — direct thematic fit.

### BI04
- **Title:** An integrated method for BIM data retrieval using large language model
- **Authors:** Deli Liu, Xiaoping Zhou, Yu Li
- **Year:** 2026
- **Source:** Architectural Science Review 69(4), 428-440
- **DOI / link:** https://doi.org/10.1080/00038628.2025.2538505
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 9

### BI05
- **Title:** BIMVLM: A vision-language model for iterative generation of component BIM models
- **Authors:** Hao Zhang, Junwei Yan, Quan Liu, et al.
- **Year:** 2026
- **Source:** Expert Systems with Applications 315, 131765
- **DOI / link:** https://doi.org/10.1016/j.eswa.2026.131765
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 1

### BI06
- **Title:** Transforming BIM data interaction: A user-centric framework leveraging lightweight ontology and large language model integration
- **Authors:** Zhikun Ding, Yongchang Li, Zhiwei Liu, Hongping Yuan
- **Year:** 2026
- **Source:** Journal of Building Design and Environment
- **DOI / link:** https://doi.org/10.70401/jbde.2026.0034
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI07
- **Title:** Exploring Large Language Model-driven Automated Generation of BIM Parametric Designs
- **Authors:** Xiaoqian Peng
- **Year:** 2026
- **Source:** Scientific Research Bulletin 3(1), 86-94
- **DOI / link:** https://doi.org/10.71052/srb2024/wehx2553
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI08
- **Title:** From Natural-Language Description to Formalization: Capturing Human-Centered Social Design Intentions in BIM using Large Language Models
- **Authors:** Yazan Nidal Hasan Zayed, Aliakbar Kamari, Carl Schultz
- **Year:** 2026
- **Source:** Journal of Intelligent Construction 4(2), 1-20
- **DOI / link:** https://doi.org/10.26599/jic.2026.9180119
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI09
- **Title:** IfcLLM: Natural Language Querying of IFC Models through Complementary Relational and Graph Representations
- **Authors:** Rabindra Lamsal, Sisi Zlatanova, Haowen Xu, Yafei Sun, Johnson Xuesong Shen
- **Year:** 2026
- **Source:** arXiv preprint
- **DOI / link:** https://arxiv.org/abs/2605.13236v2
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI10
- **Title:** SchemaRAG-IFC: Context-Aware Semantic Normalization in1Heterogeneous BIM Data
- **Authors:** Marlena  Anna Cerny, Johannes Schneider
- **Year:** 2026
- **Source:** (source not in metadata)
- **DOI / link:** https://doi.org/10.2139/ssrn.6618021
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI11
- **Title:** Multi-Agent Robotic Assembly for Industrialized Construction: A Hierarchical, LLM-Based BIM-to-BOT Framework
- **Authors:** Amirpooya Shirazi, Aladdin Alwisy
- **Year:** 2026
- **Source:** (source not in metadata)
- **DOI / link:** https://doi.org/10.2139/ssrn.6473479
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI12
- **Title:** An Agentic AI and LLM-Based Framework for Probabilistic Cost Estimation from Fragmented BIM Data
- **Authors:** Liupengfei Wu, Qian Zhang, Ruiying Xu, Yiran Zhang, Frank Ato Ghansah, Xichen Chen
- **Year:** 2026
- **Source:** Intelligent Infrastructure and Construction 2(3), 8
- **DOI / link:** https://doi.org/10.3390/iic2030008
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI13
- **Title:** Automated BIM-Based Regulatory Compliance Checking for Bridge Infrastructure,Using Ontology-Driven Semantic Rule Interpretation: A Multi-Model Validation Study
- **Authors:** Dongwook Kim
- **Year:** 2026
- **Source:** (source not in metadata)
- **DOI / link:** https://doi.org/10.2139/ssrn.6848702
- **Why relevant:** Automated compliance checking aimed at bridge codes/standards — the ACC target of BrIM agents.

### BI14
- **Title:** From Natural Language to Interoperable BIM: an Extensible Framework of Compliance-Aware Generative Design
- **Authors:** Bo Pang, Jiansong Zhang, Jingyi Lai, Bernard Nartey
- **Year:** 2026
- **Source:** (source not in metadata)
- **DOI / link:** https://doi.org/10.2139/ssrn.6947980
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.

### BI15
- **Title:** Nye Nerlandsøy Bridge: Integrated BIM Modelling and Structural Design
- **Authors:** Jens Kristian Dyrelund, Rahel Wasta, Arne Øyvind Kolstrøm, Andreas Hauso, Maureen Tricard, Ragnhild Holen Relling
- **Year:** 2026
- **Source:** IABSE Reports, IABSE Symposium, Copenhagen 2026: Bridging Advanced Technologies - Structural Innovation 122, 582-590
- **DOI / link:** https://doi.org/10.2749/copenhagen.2026.0582
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.

### BI16
- **Title:** Translating regulatory clauses into executable codes for building design checking via large language model driven function matching and composing
- **Authors:** Zhe Zheng, Jin Han, Ke-Yin Chen, Xin-Yu Cao, Xin-Zheng Lu, Jia-Rui Lin
- **Year:** 2026
- **Source:** Engineering Applications of Artificial Intelligence 163, 112823
- **DOI / link:** https://doi.org/10.1016/j.engappai.2025.112823
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 11

### BI17
- **Title:** Large Language Model–Based Construction Site Management for Severe Weather Preparedness
- **Authors:** Jinwoong Lee, Kyochul Jang, Anthony E. Sparkling, Kyubyung Kang
- **Year:** 2026
- **Source:** Journal of Construction Engineering and Management 152(1), 04025220
- **DOI / link:** https://doi.org/10.1061/jcemd4.coeng-17168
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 4

### BI18
- **Title:** SuKE: Structural Knowledge Extractor enhances large language model for knowledge graph completion
- **Authors:** Yunhai Ye, Shuo Wang
- **Year:** 2026
- **Source:** Expert Systems with Applications 297, 129199
- **DOI / link:** https://doi.org/10.1016/j.eswa.2025.129199
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 4

### BI19
- **Title:** Development of ontology based knowledge construction tool with large language model
- **Authors:** Takehisa Nishida, Tomoaki Morioka, Toshiaki Kono
- **Year:** 2026
- **Source:** Procedia CIRP 140, 401-406
- **DOI / link:** https://doi.org/10.1016/j.procir.2026.05.068
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BI20
- **Title:** Verication-driven closed-loop multi-agent large language modelframework for code-compliant structural design
- **Authors:** Jianbin Luo, Weibin Lin, Yiran Lin, Qing Wei, Wei Guo
- **Year:** 2026
- **Source:** arXiv preprint
- **DOI / link:** https://arxiv.org/abs/2608.07978v1
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BI21
- **Title:** A LARGE LANGUAGE MODEL-BASED MULTI-AGENT SYSTEM FOR ENHANCED INFORMATION RETRIEVAL IN CIVIL ENGINEERING
- **Authors:** Sebastian Kunz, Benedikt Justin Kandler, Uwe Rüppel
- **Year:** 2026
- **Source:** Computing in Construction, Proceedings of the 2026 European Conference on Computing in Construction 7
- **DOI / link:** https://doi.org/10.35490/ec3.2026.300
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.

### BI22
- **Title:** Semantic instance segmentation and automated 3D BIM reconstruction for viaduct using LiDAR point clouds and weakly-supervised learning
- **Authors:** Zheng Qiao, Vincent J.L. Gan, Mingkai Li, Kelvin Goh Chun Keong, Lim Pia Lian, Allan Yeo Chen Long
- **Year:** 2026
- **Source:** Automation in Construction 181, 106612
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106612
- **Why relevant:** BrIM/IFC-Bridge or BIM-for-bridges, closing the CAD/parametric design loop.
- **Cites (Crossref):** 13

### BI23
- **Title:** Multi-agent for BIM Automated Compliance Checking driven BIM-to-Text Paradigm
- **Authors:** Bohao Shang, Ren Li, JianXi Yang, Qiao Xiao
- **Year:** 2025
- **Source:** 2025 4th International Conference on Cloud Computing, Big Data Application and Software Engineering (CBASE)
- **DOI / link:** https://doi.org/10.1109/cbase67452.2025.11335470
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.
- **Cites (Crossref):** 1

### BI24
- **Title:** ARPaCCino: An Agentic-RAG for Policy as Code Compliance
- **Authors:** Francesco Romeo, Luigi Arena, Francesco Blefari, Francesco Aurelio Pironti, Matteo Lupinacci, Angelo Furfaro
- **Year:** 2025
- **Source:** arXiv preprint
- **DOI / link:** https://doi.org/10.1007/978-3-032-05727-3_39
- **Why relevant:** LLM/agent pipeline for automated code or regulation checking — transferable to AASHTO/JTG/Eurocode bridge-spec agents.

### BI25
- **Title:** Agentic generative AI for context-aware outlier removal and historical cost optimization in construction
- **Authors:** Vamsi Sai Kalasapudi, Krishna Pranay Angara, Charles Tofferi, Naga Sai Aditya Varanasi
- **Year:** 2025
- **Source:** Frontiers in Built Environment 11, 1678156
- **DOI / link:** https://doi.org/10.3389/fbuil.2025.1678156
- **Why relevant:** LLM/multi-agent generative structural design with code awareness — precursor to agentic bridge design.
- **Cites (Crossref):** 2

### BI26
- **Title:** Natural Language Information Retrieval from BIM Models: An LLM-Based Multi-Agent System Approach
- **Authors:** Sylvain Hellin Sylvain Hellin, Stavros Nousias Stavros Nousias, André Borrmann André Borrmann
- **Year:** 2025
- **Source:** Computing in Construction, Proceedings of the 2025 European Conference on Computing in Construction 6
- **DOI / link:** https://doi.org/10.35490/ec3.2025.265
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 4

### BI27
- **Title:** BIMCoder: A Comprehensive Large Language Model Fusion Framework for Natural Language-Based BIM Information Retrieval
- **Authors:** Bingru Liu, Hainan Chen
- **Year:** 2025
- **Source:** Applied Sciences 15(14), 7647
- **DOI / link:** https://doi.org/10.3390/app15147647
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 3

### BI28
- **Title:** A Foundation Model Approach: Generating Point Clouds for Scan-to-BIM Training and BIM Model Generation
- **Authors:** Nils Sören Krause Nils Sören Krause, Joern Ploennig Joern Ploennig
- **Year:** 2025
- **Source:** Computing in Construction, Proceedings of the 2025 European Conference on Computing in Construction 6
- **DOI / link:** https://doi.org/10.35490/ec3.2025.243
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 1

### BI29
- **Title:** An Embodied AR Navigation Agent: Integrating BIM with Retrieval-Augmented Generation for Language Guidance
- **Authors:** Hsuan-Kung Yang, Tsu-Ching Hsiao, Ryoichiro Oka, Ryuya Nishino, Satoko Tofukuji, Norimasa Kobori
- **Year:** 2025
- **Source:** arXiv preprint
- **DOI / link:** https://arxiv.org/abs/2508.16602v1
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI30
- **Title:** LLM-assisted Graph-RAG Information Extraction from IFC Data
- **Authors:** Sima Iranmanesh, Hadeel Saadany, Edlira Vakaj
- **Year:** 2025
- **Source:** arXiv preprint
- **DOI / link:** https://arxiv.org/abs/2504.16813v1
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI31
- **Title:** AUTO-BIM DATA-EXTRACTION FOR ANALYZING SPACES & AI TRAINING: COMBINING SPATIAL OBJECT/PROPERTIES WITH LLM-GENERATED DATA
- **Authors:** Bomin Kim Bomin Kim, Jin-Kook Lee Jin-Kook Lee, Hayoon Kim Hayoon Kim, Youngchae Kim Youngchae Kim, Seung Hyun Cha Seung Hyun Cha
- **Year:** 2025
- **Source:** Computing in Construction, Proceedings of the 2025 European Conference on Computing in Construction 6
- **DOI / link:** https://doi.org/10.35490/ec3.2025.463
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.

### BI32
- **Title:** Automatic construction of asset knowledge graph with large language model
- **Authors:** Tomoaki Morioka, Toshiaki Kono, Takehisa Nishida
- **Year:** 2025
- **Source:** Procedia CIRP 135, 762-767
- **DOI / link:** https://doi.org/10.1016/j.procir.2025.01.097
- **Why relevant:** Agentic/LLM work in AEC whose tools (RAG, IFC, agents) transfer to automated bridge design.
- **Cites (Crossref):** 5

### BI33
- **Title:** Refining Bridge Engineering-based Construction Scheme Compliance Review with Advanced Large Language Model Integration
- **Authors:** Yifan Zhu, Gen Zhao, Hao Liu, Dongtao Sun, Yunze He
- **Year:** 2024
- **Source:** Proceedings of the 2024 8th International Conference on Big Data and Internet of Things
- **DOI / link:** https://doi.org/10.1145/3697355.3697404
- **Why relevant:** LLM applied to bridge engineering (specs, drawings, BrIM or design support) — direct thematic fit.
- **Cites (Crossref):** 2

### BI34
- **Title:** Generative AI and Large Language Model Assisted Causal Discovery and Inference for Driving Process Improvements
- **Authors:** P. Rai, A. Jain, A. Anand
- **Year:** 2024
- **Source:** ADIPEC
- **DOI / link:** https://doi.org/10.2118/221872-ms
- **Why relevant:** LLM/multi-agent generative structural design with code awareness — precursor to agentic bridge design.
- **Cites (Crossref):** 2

### BI35
- **Title:** A Large Language Model–based Approach for automatically Optimizing BIM
- **Authors:** Junfeng Wang, Qiliang Yang, Yin Chen
- **Year:** 2024
- **Source:** 2024 43rd Chinese Control Conference (CCC)
- **DOI / link:** https://doi.org/10.23919/ccc63176.2024.10661504
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 2

### BI36
- **Title:** Integration of AI and LLMs for Enhanced BIM Analysis: A Study on .IFC Model Interpretation
- **Authors:** Groenmeyer Leon, Grunwald Gregor
- **Year:** 2024
- **Source:** AI-DRIVEN ARCHITECTURE: PIONEERING THE DIGITAL FRONTIER
- **DOI / link:** https://doi.org/10.38027/ai-driven-6
- **Why relevant:** LLM (often multi-agent) reading or writing BIM/IFC — the query/authoring layer a BrIM design copilot needs.
- **Cites (Crossref):** 1

### BI37
- **Title:** A Regionalist Approach to Generative Design Process: From Concept to BIM Model
- **Authors:** LEONARDO JORGE, RAFAEL FIUZA, HUGO SAMPAIO, DANIEL CARDOSO, MARIANA LIMA, REBECA FIUZA
- **Year:** 2024
- **Source:** Blucher Design Proceedings
- **DOI / link:** https://doi.org/10.5151/sigradi2023-107
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BI38
- **Title:** Large Language Model (LLM) & GPT, A Monolithic Study in Generative AI
- **Authors:** Atif Farid Mohammad, Bryan Clark, Ramya Hegde
- **Year:** 2023
- **Source:** 2023 Congress in Computer Science, Computer Engineering, &amp; Applied Computing (CSCE)
- **DOI / link:** https://doi.org/10.1109/csce60160.2023.00068
- **Why relevant:** LLM/multi-agent generative structural design with code awareness — precursor to agentic bridge design.
- **Cites (Crossref):** 12

### BI39
- **Title:** Topology Optimization of Continuous Precast Prestressed Concrete Bridge Girders Using Shape Memory Alloys
- **Authors:** Minsoo Sung, Bassem Andrawes
- **Year:** 2023
- **Source:** Journal of Structural Engineering 149(6), 04023051
- **DOI / link:** https://doi.org/10.1061/jsendh.steng-11999
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 11

### BI40
- **Title:** Integration of BrIM in Bridge Management - Enhanced Predictive Functionality
- **Authors:** Sachidanand Joshi, Atharvi Thorat, Harshali Dehadray, Mayuri Tundalwar
- **Year:** 2023
- **Source:** IABSE Congress Reports, IABSE Congress, New Delhi 2023: Engineering for Sustainable Development 23, 1105-1112
- **DOI / link:** https://doi.org/10.2749/newdelhi.2023.1105
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BI41
- **Title:** Cyclic Bond-Slip Behavior of Partially Debonded Tendons for Sustainable Design of Non-Emulative Precast Segmental Bridge Columns
- **Authors:** Leilei Xia, Hongcheng Hu, Shiyu Guan, Yasir Ibrahim Shah, Yingqi Liu
- **Year:** 2023
- **Source:** Sustainability 15(10), 8128
- **DOI / link:** https://doi.org/10.3390/su15108128
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 2

### BI42
- **Title:** Code compliance checking of railway designs by integrating BIM, BPMN and DMN
- **Authors:** Marco Häußler, Sebastian Esser, André Borrmann
- **Year:** 2021
- **Source:** Automation in Construction 121, 103427
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103427
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 71

### BI43
- **Title:** Loose coupling of GIS and BIM data models for automated compliance checking against zoning codes
- **Authors:** Yelin Demir Altıntaş, Mustafa Emre Ilal
- **Year:** 2021
- **Source:** Automation in Construction 128, 103743
- **DOI / link:** https://doi.org/10.1016/j.autcon.2021.103743
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 40

### BI44
- **Title:** Parametric bridge design – reinforcement design
- **Authors:** Jaroslav Navrátil, Petr Ševčík, Johann Stampler, Gregor Strekelj
- **Year:** 2021
- **Source:** IABSE Congress Reports, IABSE Congress, Ghent 2021: Structural Engineering for Future Societal Needs 20, 860-867
- **DOI / link:** https://doi.org/10.2749/ghent.2021.0860
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1

### BI45
- **Title:** Rule-based compliance checking and generative design for building interiors using BIM
- **Authors:** Christoph Sydora, Eleni Stroulia
- **Year:** 2020
- **Source:** Automation in Construction 120, 103368
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103368
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 105

### BI46
- **Title:** Design Concept for a Greened Timber Truss Bridge in City Area
- **Authors:** Benjamin Kromoser, Martin Ritt, Alexandra Spitzer, Rosemarie Stangl, Friedrich Idam
- **Year:** 2020
- **Source:** Sustainability 12(8), 3218
- **DOI / link:** https://doi.org/10.3390/su12083218
- **Why relevant:** Generative, topology or parametric method for bridge structures — computational conceptual/preliminary design.
- **Cites (Crossref):** 14

### BI47
- **Title:** Sustainability-Based Lifecycle Management for Bridge Infrastructure Using 6D BIM
- **Authors:** Sakdirat Kaewunruen, Jessada Sresakoolchai, Zhihao Zhou
- **Year:** 2020
- **Source:** Sustainability 12(6), 2436
- **DOI / link:** https://doi.org/10.3390/su12062436
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 123

### BI48
- **Title:** BIM Basic Workflows in Bridge Design – Challenges and Difficulties
- **Authors:** Ł. Grobelny, W. Trochymiak, I. Czmoch
- **Year:** 2020
- **Source:** IABSE Reports, IABSE Symposium, Wroclaw 2020: Synergy of Culture and Civil Engineering – History and Challenges 116, 975-982
- **DOI / link:** https://doi.org/10.2749/wroclaw.2020.0975
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BI49
- **Title:** Rule checking Interface development between building information model and end user
- **Authors:** Su-Ling Fan, Hung-Lin Chi, Po-Quan Pan
- **Year:** 2019
- **Source:** Automation in Construction 105, 102842
- **DOI / link:** https://doi.org/10.1016/j.autcon.2019.102842
- **Why relevant:** BIM- or NLP-based automated compliance checking — method baseline later wrapped by LLM-ACC.
- **Cites (Crossref):** 20

### BI50
- **Title:** The Gamechanger: How BIM for Bridges triumphs over the competition and revolutionizes design workflows.
- **Authors:** Michael Alestra
- **Year:** 2017
- **Source:** IABSE Reports, IABSE Symposium, Vancouver 2017: Engineering the Future 109, 846-846
- **DOI / link:** https://doi.org/10.2749/vancouver.2017.0846
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.

### BI51
- **Title:** BIM: Design Embedded Simulation of Road Bridges
- **Authors:** Markus Noeldgen, Jennifer Harder
- **Year:** 2016
- **Source:** IABSE Congress Reports, IABSE Congress, Stockholm 2016: Challenges in Design and Construction of an Innovative and Sustainable Built Environment 19, 385-391
- **DOI / link:** https://doi.org/10.2749/stockholm.2016.0362
- **Why relevant:** Traditional or case-based bridge design process (conceptual → preliminary → detailed) that agents must emulate.
- **Cites (Crossref):** 1


---

**This batch listed:** 120 unique named items (deduped vs Batches 01–07 and earlier 08+).
