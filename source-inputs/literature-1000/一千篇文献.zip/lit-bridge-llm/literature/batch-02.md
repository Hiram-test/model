# Batch 02 — Expansion: type-specific optimization, ACC-NLP, semantic BIM, digital twins, remaining LLM/agents (~114 items)

Scope: unique vs. `batch-01-core-90.md`. Continues the two spines:

1. **Traditional / computational design process:** conceptual form-finding and type-specific sizing–shape–topology optimization; codes and textbooks; parametric BrIM / IFC; NLP–ontology ACC; knowledge graphs; digital twins that close design–O&M.
2. **Agentic / LLM automation:** remaining 2023–2026 BIM-generation, IFC-tool-use, ACC, and analysis-agent papers not listed in Batch 01.

Priority: 2016–2026; extra weight on 2023+ LLM/agent work. English-first, with key Chinese sources.

Citation counts are approximate Google Scholar / Crossref snapshots (2026) and are only for ranking, not exact.

---

## H. Topology / size / shape / cable-force optimization of specific bridge types

### H01
- **Title:** Optimization of cable-stayed bridges: A literature survey
- **Authors:** Alberto M. B. Martins, Luís M. C. Simões, João H. J. O. Negrão
- **Year:** 2020
- **Source:** Advances in Engineering Software 149, 102829
- **DOI / link:** https://doi.org/10.1016/j.advengsoft.2020.102829
- **Why relevant:** Canonical survey splitting cable-stayed design into *cable-force* vs *sizing/geometry/topology* optimization — the computational counterpart of preliminary design.
- **Cites (approx.):** 180+

### H02
- **Title:** Optimum design of concrete cable-stayed bridges
- **Authors:** Alberto M. B. Martins, Luís M. C. Simões, João H. J. O. Negrão
- **Year:** 2016
- **Source:** Engineering Optimization 48(5)
- **DOI / link:** https://doi.org/10.1080/0305215X.2015.1057057
- **Why relevant:** Discrete/continuous design variables for concrete cable-stayed bridges under real code constraints — a full preliminary-design optimizer.

### H03
- **Title:** Theoretically optimal forms for very long-span bridges under gravity loading
- **Authors:** Helen E. Fairclough, Matthew Gilbert, Aleksey V. Pichugin, Andy Tyas, Ian Firth
- **Year:** 2018
- **Source:** Proceedings of the Royal Society A 474(2217), 20170726
- **DOI / link:** https://doi.org/10.1098/rspa.2017.0726
- **Why relevant:** Layout optimization that *reopens conceptual form* for ultra-long spans, rather than only sizing a pre-chosen suspension/cable-stayed scheme.
- **Cites (approx.):** 90+

### H04
- **Title:** Closing the gap towards super-long suspension bridges using computational morphogenesis
- **Authors:** Mads Baandrup, Ole Sigmund, Henrik Polk, Niels Aage
- **Year:** 2020
- **Source:** Nature Communications 11, 2735
- **DOI / link:** https://doi.org/10.1038/s41467-020-16599-6
- **Why relevant:** Topology/morphogenesis applied to a real-scale suspension-bridge girder, claiming >28% weight saving — flagship “generative design” of a signature bridge.
- **Cites (approx.):** 120+

### H05
- **Title:** Efficient Design Optimization of Cable-Stayed Bridges: A Two-Layer Framework with Surrogate-Model-Assisted Prediction of Optimum Cable Forces
- **Authors:** Yuan Ma, Chongchong Song, Zilong Wang, Zhengrong Jiang
- **Year:** 2024
- **Source:** Applied Sciences 14(5), 2007
- **DOI / link:** https://doi.org/10.3390/app14052007
- **Why relevant:** Decouples cable prestress prediction from sizing/geometry PSO — a practical preliminary-design loop for real cable-stayed projects.

### H06
- **Title:** Cable Force Optimization of Cable-Stayed Bridge Based on Multiobjective Particle Swarm Optimization Algorithm with Mutation Operation and Adaptive Inertia Weight
- **Authors:** Lifeng Wang, Ziwang Xiao, Min Li, Ning Fu
- **Year:** 2023
- **Source:** Applied Sciences 13(4), 2611
- **DOI / link:** https://doi.org/10.3390/app13042611
- **Why relevant:** Multi-objective cable-force optimization at the completed state — the classical “reasonable finished geometry” step of Chinese/Japanese cable-stayed design.

### H07
- **Title:** Reliability-based optimization of steel truss arch bridges
- **Authors:** Jin Cheng, Hui Jin
- **Year:** 2017
- **Source:** International Journal of Steel Structures 17
- **DOI / link:** https://doi.org/10.1007/s13296-017-1212-y
- **Why relevant:** RBDO of steel truss arches — links conceptual member layout to the safety core of detailed design.

### H08
- **Title:** Intelligent generation method for innovative structures of the main truss in a steel bridge
- **Authors:** Wenjie Du, Ying-Qi Wang, Hui Wang, Yannan Zhao
- **Year:** 2023
- **Source:** Soft Computing
- **DOI / link:** https://doi.org/10.1007/s00500-023-07864-z
- **Why relevant:** Direct *generative* design of steel-bridge main-truss topology — a pre-LLM intelligent-design line on the bridge itself.

### H09
- **Title:** Optimization of prestressed concrete bridge girder section using a modified harmony search algorithm
- **Authors:** M. Jahjouh, Sema Alper Erhan
- **Year:** 2022
- **Source:** Structures 46
- **DOI / link:** https://doi.org/10.1016/j.istruc.2022.10.093
- **Why relevant:** Section/size optimization of PC girders — the workhorse of conventional highway-bridge detailed design.

### H10
- **Title:** Comprehensive Design Optimization Framework for Prestressed Concrete Continuous Beam Bridge Using Genetic Algorithm
- **Authors:** Hao Bai, Yanbo Zhang, Beiyu You, Keyu Chen
- **Year:** 2025
- **Source:** Buildings 15(8), 1344
- **DOI / link:** https://doi.org/10.3390/buildings15081344
- **Why relevant:** End-to-end GA framework for PC continuous-beam bridges covering multiple design variables and code constraints.

### H11
- **Title:** Crossing cable design optimization of multi-tower cable-stayed bridge based on joint analytical method and genetic algorithm
- **Authors:** Kaijie Huang, Shengbo Chai, Xiulan Wang
- **Year:** 2024
- **Source:** Structures
- **DOI / link:** https://doi.org/10.1016/j.istruc.2024.107335
- **Why relevant:** Conceptual/preliminary design of crossing-stay systems for multi-tower cable-stayed bridges.

### H12
- **Title:** The Structural Design and Optimization of Top-Stiffened Double-Layer Steel Truss Bridges Based on the Response Surface Method and Particle Swarm Optimization
- **Authors:** Lingbo Wang, Rongjie Xi, Xinjun Guo, Yinping Ma
- **Year:** 2023
- **Source:** Applied Sciences 13(19), 11033
- **DOI / link:** https://doi.org/10.3390/app131911033
- **Why relevant:** Combined structural-scheme + sizing optimization of a double-layer steel truss — typical of urban rail/highway dual-use bridges.

### H13
- **Title:** Design of truss structures through reuse and optimization of steel elements
- **Authors:** Jan Brütting, Joseph Desruelle, Gennaro Senatore, Corentin Fivet
- **Year:** 2019
- **Source:** Structures 18, 128–137
- **DOI / link:** https://doi.org/10.1016/j.istruc.2018.11.006
- **Why relevant:** Layout/size optimization under *stock constraints* — a sustainability-aware conceptual-design formulation later wrapable by agents.

### H14
- **Title:** Determination of optimum post-tensioning cable forces of cable-stayed bridges
- **Authors:** M. M. Hassan, A. O. Nassef, A. A. El Damatty
- **Year:** 2012 (still the most-cited cable-force paper used by 2016–2026 surveys)
- **Source:** Engineering Structures 44, 248–259
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2012.06.009
- **Why relevant:** Real-coded GA for stay prestress — the method later papers compare against when automating “reasonable completed state”.
- **Cites (approx.):** 180+

### H15
- **Title:** Optimal prestress design of composite cable-stayed bridges
- **Authors:** Fernando Fabbrocino, Mariano Modano, Ilenia Farina, Gerardo Carpentieri, Fernando Fraternali
- **Year:** 2017
- **Source:** Composite Structures 169
- **DOI / link:** https://doi.org/10.1016/j.compstruct.2016.09.008
- **Why relevant:** Prestress as a first-class design variable of composite cable-stayed decks.

### H16
- **Title:** Shape optimization of streamlined decks of cable-stayed bridges considering aeroelastic and structural constraints
- **Authors:** Miguel Cid Montoya, Santiago Hernández, Félix Nieto
- **Year:** 2018
- **Source:** Structural and Multidisciplinary Optimization 57
- **DOI / link:** https://doi.org/10.1007/s00158-017-1814-1
- **Why relevant:** Coupled aero-structural *deck-section* design — the wind-governed half of long-span conceptual design.

### H17
- **Title:** Layout optimization of structures with distributed self-weight, lumped masses and frictional supports
- **Authors:** Helen E. Fairclough, Matthew Gilbert, Andy Tyas
- **Year:** 2022
- **Source:** Structural and Multidisciplinary Optimization 65
- **DOI / link:** https://doi.org/10.1007/s00158-021-03148-0
- **Why relevant:** Extends the 2018 long-span layout method to more realistic self-weight and support conditions.

### H18
- **Title:** Karamba—A Toolkit for Parametric Structural Design
- **Authors:** Clemens Preisinger, Martin Heimrath
- **Year:** 2014
- **Source:** Structural Engineering International 24(2)
- **DOI / link:** https://doi.org/10.2749/101686614X13830790993483
- **Why relevant:** The de-facto Grasshopper FEM used in countless parametric/generative *bridge and long-span* early-design studies.

### H19
- **Title:** Combining structural performance and designer preferences in evolutionary design space exploration
- **Authors:** Caitlin T. Mueller, John A. Ochsendorf
- **Year:** 2015
- **Source:** Automation in Construction 52, 70–82
- **DOI / link:** https://doi.org/10.1016/j.autcon.2015.02.011
- **Why relevant:** Formalizes *human-in-the-loop* conceptual structural design — the interaction pattern LLM copilots later try to replace or augment.
- **Cites (approx.):** 220+

### H20
- **Title:** Design for structural and energy performance of long span buildings using geometric multi-objective optimization
- **Authors:** Nathan C. Brown, Caitlin T. Mueller
- **Year:** 2016
- **Source:** Energy and Buildings 127, 748–761
- **DOI / link:** https://doi.org/10.1016/j.enbuild.2016.05.090
- **Why relevant:** Multi-objective geometric optimization of long-span systems — transferable to bridge-deck/superstructure trade-off studies.

---

## I. NLP / BERT / ontology automated compliance (pre-LLM → transformer)

### I01
- **Title:** Automated Information Transformation for Automated Regulatory Compliance Checking in Construction
- **Authors:** Jiansong Zhang, Nora M. El-Gohary
- **Year:** 2015
- **Source:** Journal of Computing in Civil Engineering 29(4)
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000427
- **Why relevant:** First full IE → logical-clause transformation pipeline for codes; Batch 01 had the 2016/2017 follow-ons, not this 2015 origin paper.
- **Cites (approx.):** 230+

### I02
- **Title:** Ontology-based automated information extraction from building energy conservation codes
- **Authors:** Peng Zhou, Nora El-Gohary
- **Year:** 2017
- **Source:** Automation in Construction 74, 103–117
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.09.004
- **Why relevant:** Ontology + cascaded IE for hierarchically nested code sentences — the pattern later reused for structural/bridge specs.
- **Cites (approx.):** 180+

### I03
- **Title:** A rule-based semantic approach for automated regulatory compliance in the construction sector
- **Authors:** Thomas H. Beach, Yacine Rezgui, Haijiang Li, Tala Kasim
- **Year:** 2015
- **Source:** Expert Systems with Applications 42(12), 5219–5231
- **DOI / link:** https://doi.org/10.1016/j.eswa.2015.02.029
- **Why relevant:** Domain-expert-authored semantic rules executed on BIM — the Cardiff line of ACC later combined with LLMs.
- **Cites (approx.):** 250+

### I04
- **Title:** A Generalized Adaptive Framework (GAF) for Automating Code Compliance Checking
- **Authors:** Nawari O. Nawari
- **Year:** 2019
- **Source:** Buildings 9(4), 86
- **DOI / link:** https://doi.org/10.3390/buildings9040086
- **Why relevant:** Adaptive computable-representation framework for design-review automation, widely used as a taxonomy in later LLM-ACC papers.
- **Cites (approx.):** 110+

### I05
- **Title:** Automated Building Code Compliance Checking – Where is it at?
- **Authors:** Johannes Dimyadi, Robert Amor
- **Year:** 2013
- **Source:** CIB World Building Congress 2013
- **DOI / link:** https://itc.scix.net/paper/wbc2013_241
- **Why relevant:** The status-report that Batch 01’s Amor/Dimyadi 2021 “promise of ACC” paper updates — needed for the historical ACC spine.

### I06
- **Title:** Translating building legislation into a computer-executable format for evaluating building permit requirements
- **Authors:** Hyunsoo Lee, Jin-Kook Lee, Seokyung Park, Inhan Kim
- **Year:** 2016
- **Source:** Automation in Construction 71, 49–61
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.04.008 ; https://www.sciencedirect.com/science/article/abs/pii/S0926580516300796
- **Why relevant:** KBimCode / KBimLogic — Korea’s national computable-code programme, a direct analogue of JTG/AASHTO operationalization for bridges.

### I07
- **Title:** Computer representation of building codes for automated compliance checking
- **Authors:** Sinan Macit İlal, H. Murat Günaydın
- **Year:** 2017
- **Source:** Automation in Construction 82, 43–58
- **DOI / link:** https://doi.org/10.1016/j.autcon.2017.06.018
- **Why relevant:** Formal analysis of *how* codes should be represented (not just extracted) — a prerequisite for executable LLM-compiled regulations.

### I08
- **Title:** Classification of BIM-based model checking concepts
- **Authors:** Eilif Hjelseth
- **Year:** 2016
- **Source:** ITcon 21, 354–370
- **DOI / link:** https://www.itcon.org/paper/2016/23
- **Why relevant:** Distinguishes model-checking *concepts* (validation, code, content, smart-object) still used to scope ACC vs. design-automation agents.

### I09
- **Title:** Towards the adoption of automated regulatory compliance checking in the built environment
- **Authors:** Thomas H. Beach, Jean-Laurent Hippolyte, Yacine Rezgui
- **Year:** 2020
- **Source:** Automation in Construction 118, 103285
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103285
- **Why relevant:** Industry roadmap of *adoption* barriers (not only algorithms) — explains why LLM-ACC still needs human oversight.

### I10
- **Title:** Automated Construction Specification Review with Named Entity Recognition Using Natural Language Processing
- **Authors:** Sungkook Moon, Ghang Lee, Seokho Chi, Hyunsoo Oh
- **Year:** 2021
- **Source:** Journal of Construction Engineering and Management 147(1)
- **DOI / link:** https://doi.org/10.1061/(ASCE)CO.1943-7862.0001953
- **Why relevant:** NER over construction *specifications* (the project-level counterpart of national codes) — needed for agentic spec-to-check pipelines.

### I11
- **Title:** Automated detection of contractual risk clauses from construction specifications using bidirectional encoder representations from transformers (BERT)
- **Authors:** Sungkook Moon, Seokho Chi, Seok-Been Im
- **Year:** 2022
- **Source:** Automation in Construction 142, 104465
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104465
- **Why relevant:** BERT-era clause classification of specs — the transformer baseline LLM-ACC papers beat.

### I12
- **Title:** Deep learning-based extraction of construction procedural constraints from construction regulations
- **Authors:** Botao Zhong, Xing Pan, Hao Wu, Lieyun Ding, Heng Li
- **Year:** 2020
- **Source:** Advanced Engineering Informatics (Zhong group line; also related JCCE variants)
- **DOI / link:** https://doi.org/10.1016/j.aei.2019.101003
- **Why relevant:** DL extraction of *procedural* (not only geometric) constraints — relevant to construction-stage bridge specs and method statements.

### I13
- **Title:** Pretrained domain-specific language model for natural language processing tasks in the AEC domain
- **Authors:** Zhe Zheng, Xinzheng Lu, Ke-Yin Chen, Yu-Cheng Zhou, Jia-Rui Lin
- **Year:** 2022
- **Source:** Computers in Industry 142, 103733
- **DOI / link:** https://doi.org/10.1016/j.compind.2022.103733
- **Why relevant:** First AEC-domain pretrained LM (Tsinghua Lin/Lu) — the immediate precursor of Qwen-BIM / LLM-ACC in Batch 01.
- **Cites (approx.):** 150+

### I14
- **Title:** A deep neural network-based method for deep information extraction using transfer learning strategies to support automated compliance checking
- **Authors:** Ruichuan Zhang, Nora El-Gohary
- **Year:** 2021
- **Source:** Automation in Construction 132, 103834
- **DOI / link:** https://doi.org/10.1016/j.autcon.2021.103834
- **Why relevant:** Transfer-learning IE for codes just before GPT-era ACC — the El-Gohary 2021–22 baseline.

### I15
- **Title:** Semantic text classification for supporting automated compliance checking in construction
- **Authors:** D. M. Salama, Nora M. El-Gohary
- **Year:** 2016
- **Source:** Journal of Computing in Civil Engineering 30(1), 04014106
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000441
- **Why relevant:** Text classification as the first ACC stage (relevant vs. irrelevant provisions) still used in RAG/LLM checkers.

### I16
- **Title:** Building Codes Part-of-Speech Tagging Performance Improvement by Error-Driven Transformational Rules
- **Authors:** Xiaorui Xue, Jiansong Zhang
- **Year:** 2020
- **Source:** Journal of Computing in Civil Engineering 34(5), 04020035
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000917
- **Why relevant:** Domain POS tagging of codes — a non-LLM linguistic resource still useful as a guardrail for LLM parsers.

### I17
- **Title:** Comparing machine learning and rule-based inferencing for semantic enrichment of BIM models
- **Authors:** Tanya Bloch, Rafael Sacks
- **Year:** 2018
- **Source:** Automation in Construction 91, 256–272
- **DOI / link:** https://doi.org/10.1016/j.autcon.2018.03.018
- **Why relevant:** Shows when learned vs. symbolic rules win for BIM semantics — the same trade-off LLM agents now face on IFC.
- **Cites (approx.):** 220+

### I18
- **Title:** Ontology-based semantic modeling of regulation constraint for automated construction quality compliance checking
- **Authors:** Botao Zhong, Lieyun Ding, Hanbin Luo, Ying Zhou, Y. Hu, H. Hu
- **Year:** 2012
- **Source:** Automation in Construction 28, 58–70
- **DOI / link:** https://doi.org/10.1016/j.autcon.2012.06.006
- **Why relevant:** Early Chinese KG/ontology ACC — the ancestor of Batch 01 D06 and of later LLM+KG hybrid checkers.
- **Cites (approx.):** 350+

---

## J. Knowledge graphs, ontologies, semantic enrichment (BIM / bridges)

### J01
- **Title:** Semantic web technologies in AEC industry: A literature overview
- **Authors:** Pieter Pauwels, Sijie Zhang, Yong-Cheol Lee
- **Year:** 2017
- **Source:** Automation in Construction 73, 145–165
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.10.003
- **Why relevant:** Highest-cited map of semantic web / linked data in AEC — the substrate of KG-ACC and of LLM+KG RAG over codes.
- **Cites (approx.):** 800+

### J02
- **Title:** EXPRESS to OWL for construction industry: Towards a recommendable and usable ifcOWL ontology
- **Authors:** Pieter Pauwels, Walter Terkaj
- **Year:** 2016
- **Source:** Automation in Construction 63, 100–133
- **DOI / link:** https://doi.org/10.1016/j.autcon.2015.12.003
- **Why relevant:** ifcOWL as the RDF view of IFC — required if agents are to SPARQL/reason over bridge models rather than only call Revit APIs.
- **Cites (approx.):** 400+

### J03
- **Title:** BOT: The building topology ontology of the W3C Linked Building Data group
- **Authors:** Mads Holten Rasmussen, Maxime Lefrançois, Georg Ferdinand Schneider, Pieter Pauwels
- **Year:** 2021
- **Source:** Semantic Web 12(1), 143–161
- **DOI / link:** https://doi.org/10.3233/SW-200385
- **Why relevant:** Minimal topology vocabulary used by almost all later LBD / digital-twin graphs; reusable for BrIM spatial structure.
- **Cites (approx.):** 440+

### J04
- **Title:** Semantic Enrichment for Building Information Modeling: Procedure for Compiling Inference Rules and Operators for Empirical Data
- **Authors:** Rafael Sacks, Ling Ma, Raz Yosef, André Borrmann, Simon Daum, Uri Kattel
- **Year:** 2017
- **Source:** Journal of Computing in Civil Engineering 31(6), 04017062
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000705
- **Why relevant:** The SeeBridge *procedure* for compiling bridge engineers’ knowledge as forward-chaining rules on IFC.
- **Cites (approx.):** 180+

### J05
- **Title:** Semantic Enrichment for Building Information Modeling
- **Authors:** Michael Belsky, Rafael Sacks, Ioannis Brilakis
- **Year:** 2016
- **Source:** Computer-Aided Civil and Infrastructure Engineering 31(4)
- **DOI / link:** https://doi.org/10.1111/mice.12128
- **Why relevant:** SEE engine (precast joints/slabs) — the general method later specialized to bridges in SeeBridge.
- **Cites (approx.):** 310+

### J06
- **Title:** SeeBridge as next generation bridge inspection: Overview, Information Delivery Manual and Model View Definition
- **Authors:** Rafael Sacks, Amir Kedar, André Borrmann, Ling Ma, Ioannis Brilakis, Philipp Hüthwohl, Simon Daum, Uri Kattel, Raz Yosef, Thomas Liebich, Burcu Esen Barutcu, Sergej Muhic
- **Year:** 2018
- **Source:** Automation in Construction 90, 134–145
- **DOI / link:** https://doi.org/10.1016/j.autcon.2018.02.033
- **Why relevant:** IDM/MVD for semantically rich *bridge* models from survey to assessment — the open information contract later LLM-BrIM agents must honour.
- **Cites (approx.):** 220+

### J07
- **Title:** CBIM: A Graph-based Approach to Enhance Interoperability Using Semantic Enrichment
- **Authors:** Zijian Wang, Huaquan Ying, Rafael Sacks, André Borrmann
- **Year:** 2023
- **Source:** arXiv 2304.11672 (CIB W78 / journal follow-on)
- **DOI / link:** https://arxiv.org/abs/2304.11672
- **Why relevant:** Graph neural / object-graph view of BIM interoperability — the data structure LLM agents query when they “read” a model.

### J08
- **Title:** State of the art of damage information modeling for RC bridges – A literature review
- **Authors:** Marcel Artus, Christian Koch
- **Year:** 2020
- **Source:** Structure and Infrastructure Engineering 16
- **DOI / link:** https://doi.org/10.1080/15732479.2020.1719167
- **Why relevant:** How damage, not only as-designed geometry, is modelled on RC bridges — needed for design–assessment closed loops.

### J09
- **Title:** Bridge damage: Detection, IFC-based semantic enrichment and visualization
- **Authors:** Dušan Isailović, Vladimir Stojanovic, Matthias Trapp, Rico Richter, Rade Hajdin, Jürgen Döllner
- **Year:** 2020
- **Source:** Automation in Construction 112, 103082
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103082
- **Why relevant:** IFC semantic enrichment of detected bridge damage — a machine-readable as-is model that design agents can consume.

### J10
- **Title:** Knowledge graph for identifying hazards on construction sites: Integrating computer vision with ontology
- **Authors:** Weili Fang, Lieyun Ding, Peter E. D. Love, Hanbin Luo, Heng Li, A. Zhou
- **Year:** 2020
- **Source:** Automation in Construction / related Safety Science line
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103310
- **Why relevant:** CV + ontology KG pattern later reused for code entities and for LLM-grounded site/design hazard checks.

### J11
- **Title:** Natural language processing for smart construction: Current status and future directions
- **Authors:** Chengke Wu, Xiao Li, Yuanjun Guo, Ji Wang, Zenglei Ren, Mengcheng Wang, Zhile Yang
- **Year:** 2022
- **Source:** Automation in Construction 134, 104059
- **DOI / link:** https://doi.org/10.1016/j.autcon.2021.104059
- **Why relevant:** Pre-ChatGPT panoramic NLP-in-construction review (specs, codes, contracts) that LLM papers now cite as the baseline.
- **Cites (approx.):** 250+

### J12
- **Title:** Digital approaches to construction compliance checking: Validating the suitability of an ecosystem approach to compliance checking
- **Authors:** Thomas Beach, Jonathan Yeung, Nicholas Nisbet, Yacine Rezgui
- **Year:** 2024
- **Source:** Advanced Engineering Informatics 59, 102288
- **DOI / link:** https://doi.org/10.1016/j.aei.2023.102288
- **Why relevant:** Moves ACC from a single BIM checker to a *service ecosystem* — the architecture into which LLM rule-compilers (ARCHER, etc.) plug.

---

## K. Digital twins of bridges (closing the design–O&M loop)

### K01
- **Title:** Development of a bridge maintenance system for prestressed concrete bridges using 3D digital twin model
- **Authors:** Chang-Su Shim, Ngoc-Son Dang, Sokhom Lon, Chi-Ho Jeon
- **Year:** 2019
- **Source:** Structure and Infrastructure Engineering 15
- **DOI / link:** https://doi.org/10.1080/15732479.2019.1620789
- **Why relevant:** First widely cited *bridge* DT maintenance system on PSC girders — the as-maintained model that should feed back into design rules.
- **Cites (approx.):** 360+

### K02
- **Title:** Digital twinning of existing reinforced concrete bridges from labelled point clusters
- **Authors:** Ruodan Lu, Ioannis Brilakis
- **Year:** 2019
- **Source:** Automation in Construction 105, 102837
- **DOI / link:** https://doi.org/10.1016/j.autcon.2019.102837
- **Why relevant:** Geometric DT generation from point clouds for RC bridges — the as-built BrIM that automated design/checking must eventually target.
- **Cites (approx.):** 360+

### K03
- **Title:** Digital twin and its implementations in the civil engineering sector
- **Authors:** Feng Jiang, Ling Ma, Tim Broyd, Ke Chen
- **Year:** 2021
- **Source:** Automation in Construction 130, 103838
- **DOI / link:** https://doi.org/10.1016/j.autcon.2021.103838
- **Why relevant:** Distinguishes DT vs BIM vs CPS and clusters civil DT applications — the map used by later agentic DT papers.
- **Cites (approx.):** 650+

### K04
- **Title:** Towards Civil Engineering 4.0: Concept, workflow and application of Digital Twins for existing infrastructure
- **Authors:** Maria Pregnolato, Sam Gunner, Elia Voyagaki, et al.
- **Year:** 2022
- **Source:** Automation in Construction 141, 104421
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104421
- **Why relevant:** Explicit DT *workflow* for existing infrastructure (including bridges) from scan to decision.

### K05
- **Title:** Towards a semantic Construction Digital Twin: Directions for future research
- **Authors:** Calin Boje, Annie Guerriero, Sylvain Kubicki, Yacine Rezgui
- **Year:** 2020
- **Source:** Automation in Construction 114, 103179
- **DOI / link:** https://doi.org/10.1016/j.autcon.2020.103179
- **Why relevant:** Argues DT must be *semantic* (not only 3D) — the knowledge layer LLM agents query.
- **Cites (approx.):** 700+

### K06
- **Title:** Building Information Modelling, Artificial Intelligence and Construction Tech
- **Authors:** Rafael Sacks, Mark Girolami, Ioannis Brilakis
- **Year:** 2020
- **Source:** Developments in the Built Environment 4, 100011
- **DOI / link:** https://doi.org/10.1016/j.dibe.2020.100011
- **Why relevant:** Places AI design/code-checking and digital twins on a shared BIM information foundation — the conceptual frame of this corpus.
- **Cites (approx.):** 180+

### K07
- **Title:** Integrating RC Bridge Defect Information into BIM Models
- **Authors:** Philipp Hüthwohl, Ioannis Brilakis, André Borrmann, Rafael Sacks
- **Year:** 2018
- **Source:** Journal of Computing in Civil Engineering 32(3), 04018013
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000744
- **Why relevant:** Defect semantics on BrIM — required if an agent is to check a *real* (damaged/as-built) bridge, not only a design model.

### K08
- **Title:** Bridge Information Modeling for Inspection and Evaluation
- **Authors:** Brian McGuire, Rebecca Atadero, Caroline Clevenger, Mehmet Ozbek
- **Year:** 2016
- **Source:** Journal of Bridge Engineering 21(4), 04015076
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000773
- **Why relevant:** Early BrIM-for-inspection on real US bridges — the owner-side information requirement that design BIM must support.

### K09
- **Title:** Digital twin application in the construction industry: A literature review
- **Authors:** De-Graft Joe Opoku, Srinath Perera, Robert Osei-Kyei, Maria Rashdi
- **Year:** 2021
- **Source:** Journal of Building Engineering 40, 102726
- **DOI / link:** https://doi.org/10.1016/j.jobe.2021.102726
- **Why relevant:** Broad construction-DT review used as the industry baseline before bridge-specific DT papers.

### K10
- **Title:** From BIM to digital twins: a systematic review of the evolution of intelligent building representations in the AEC-FM industry
- **Authors:** Min Deng, Carol C. Menassa, Vineet R. Kamat
- **Year:** 2021
- **Source:** Journal of Information Technology in Construction (ITcon) 26, 58–83
- **DOI / link:** https://www.itcon.org/paper/2021/5
- **Why relevant:** Traces BIM → DT evolution and the data/semantics gaps agents must fill.

### K11
- **Title:** Structural Performance Monitoring Using a Dynamic Data-Driven BIM Environment
- **Authors:** Juan Manuel Davila Delgado, Liam J. Butler, Ioannis Brilakis, Mohammed Z. E. B. Elshafie, Campbell R. Middleton
- **Year:** 2018
- **Source:** Journal of Computing in Civil Engineering 32(3), 04018009
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000749
- **Why relevant:** Live SHM data bound to BIM on a real bridge (Stafford Area) — the sensing half of a design–verify agent loop.

### K12
- **Title:** Building Information Models to Robot-Ready Site Digital Twins (BIM2RDT): An Agentic AI Safety-First Framework
- **Authors:** Reza Akhavian, Mani Amani, Johannes Mootz, Robert Ashe, Behrad Beheshti
- **Year:** 2025
- **Source:** arXiv 2509.20705
- **DOI / link:** https://arxiv.org/abs/2509.20705
- **Why relevant:** Agentic AI that turns BIM into a robot-ready site DT (LLM-informed registration) — the construction-side counterpart of design agents.

---

## L. Parametric BrIM, IFC, computational / generative structural design (pre-LLM)

### L01
- **Title:** Exchange of Parametric Bridge Models Using a Neutral Data Format
- **Authors:** Yang Ji, André Borrmann, Jakob Beetz, Mathias Obergrießer
- **Year:** 2013
- **Source:** Journal of Computing in Civil Engineering 27(6), 593–606
- **DOI / link:** https://doi.org/10.1061/(ASCE)CP.1943-5487.0000286
- **Why relevant:** The IFC-Bridge *parametric-geometry* origin paper that Batch 01’s 2019 IFC-Bridge project paper builds on.
- **Cites (approx.):** 150+

### L02
- **Title:** Analytical review and theoretical framework for BIM for infrastructure (BIM-infra)
- **Authors:** Jack C. P. Cheng, Qiqi Lu, Yichuan Deng
- **Year:** 2016
- **Source:** Visualization in Engineering 4, 9
- **DOI / link:** https://doi.org/10.1186/s40327-016-0038-6
- **Why relevant:** Theoretical framework for infrastructure BIM (roads/bridges/rail) complementary to Costin/Bradley reviews in Batch 01.

### L03
- **Title:** Towards intelligent structural design of buildings: A BIM-based solution
- **Authors:** Tofigh Hamidavi, Sepehr Abrishami, M. Reza Hosseini
- **Year:** 2020
- **Source:** Journal of Building Engineering 32, 101685
- **DOI / link:** https://doi.org/10.1016/j.jobe.2020.101685
- **Why relevant:** Revit → Dynamo → Robot automated generation/optimization of structural schemes from the architectural BIM.
- **Cites (approx.):** 120+

### L04
- **Title:** OSD: A framework for the early-stage parametric optimisation of the structural design in BIM-based platform
- **Authors:** Tofigh Hamidavi, Sepehr Abrishami, P. Ponterosso, D. Begg, N. Nanos
- **Year:** 2020
- **Source:** Construction Innovation 20(2)
- **DOI / link:** https://doi.org/10.1108/CI-11-2019-0126
- **Why relevant:** Explicit *early-stage* (conceptual/preliminary) structural optimization inside BIM — the process stage agentic design must hit.

### L05
- **Title:** Automated structural design of shear wall residential buildings using generative adversarial networks
- **Authors:** Wenjie Liao, Xinzheng Lu, Yuli Huang, Zhe Zheng, Yiqi Lin
- **Year:** 2021
- **Source:** Automation in Construction 132, 103931
- **DOI / link:** https://doi.org/10.1016/j.autcon.2021.103931
- **Why relevant:** StructGAN origin paper (Batch 01 had the 2023 AE/GNN follow-ons, not this 2021 GAN generator).
- **Cites (approx.):** 280+

### L06
- **Title:** Intelligent structural design of shear wall residence using physics-enhanced generative adversarial networks
- **Authors:** Xinzheng Lu, Wenjie Liao, Yi Zhang, Yuli Huang
- **Year:** 2022
- **Source:** Earthquake Engineering & Structural Dynamics 51
- **DOI / link:** https://doi.org/10.1002/eqe.3632
- **Why relevant:** Injects physics/seismic performance into generative structural design — the “generate *and* check” loop later wrapped by LLMs.

### L07
- **Title:** Knowledge-enhanced generative adversarial networks for schematic design of framed tube structures
- **Authors:** Yifan Fei, Wenjie Liao, Yuli Huang, Xinzheng Lu
- **Year:** 2022
- **Source:** Automation in Construction 144, 104619
- **DOI / link:** https://doi.org/10.1016/j.autcon.2022.104619
- **Why relevant:** Domain-knowledge constraints inside a GAN — a non-LLM way to keep generated schemes code-plausible.

### L08
- **Title:** Implementing BIM on infrastructure: Comparison of two bridge construction projects
- **Authors:** B. Fanning, Caroline M. Clevenger, Mehmet E. Ozbek, Hussam Mahmoud
- **Year:** 2015
- **Source:** Practice Periodical on Structural Design and Construction 20(4), 04014044
- **DOI / link:** https://doi.org/10.1061/(ASCE)SC.1943-5576.0000239
- **Why relevant:** Side-by-side BIM vs non-BIM bridge delivery — empirical baseline for “why automate BrIM”.

### L09
- **Title:** Virtual generative BIM workspace for AEC conceptual design automation: prototype development
- **Authors:** Sepehr Abrishami, Jack Goulding, Farzad Pour Rahimian, Abdulkadir Ganah
- **Year:** 2015
- **Source:** Engineering, Construction and Architectural Management 22
- **DOI / link:** https://doi.org/10.1108/ECAM-03-2014-0035
- **Why relevant:** Early generative+BIM *conceptual-design* workspace — process ancestor of Text2BIM-style agents.

### L10
- **Title:** Project Discover: An application of generative design for architectural space planning
- **Authors:** Danil Nagy, Lorenzo Villaggi, David Lau, James Stoddart, et al. (Autodesk Research)
- **Year:** 2017/2018
- **Source:** SimAUD / Autodesk University
- **DOI / link:** https://www.autodeskresearch.com/publications/project-discover-application-generative-design-architectural-space-planning
- **Why relevant:** Industry-scale generative design (Project Discover) that structural/bridge GD tools imitate.

### L11
- **Title:** Meta-parametric design
- **Authors:** John Harding, Paul Shepherd
- **Year:** 2017
- **Source:** Design Studies 52, 73–95
- **DOI / link:** https://doi.org/10.1016/j.destud.2016.09.005
- **Why relevant:** Treats the parametric *model itself* as the design object — relevant when agents write Grasshopper/Dynamo rather than instances.

### L12
- **Title:** Towards an integrated generative design framework
- **Authors:** Vishal Singh, Ning Gu
- **Year:** 2012
- **Source:** Design Studies 33(2), 185–207
- **DOI / link:** https://doi.org/10.1016/j.destud.2011.06.001
- **Why relevant:** Foundational GD process model (generate–evaluate–evolve) that both TO and LLM-MAS design loops instantiate.

### L13
- **Title:** Quantifying diversity in parametric design: a comparison of possible metrics
- **Authors:** Nathan C. Brown, Caitlin T. Mueller
- **Year:** 2019
- **Source:** Artificial Intelligence for Engineering Design, Analysis and Manufacturing 33
- **DOI / link:** https://doi.org/10.1017/S089006041800003X
- **Why relevant:** How to measure whether a generator actually explores the conceptual-design space — an evaluation need for agentic design.

### L14
- **Title:** Improving applicability for information model of an IFC-based steel bridge in Korea
- **Authors:** Sang I. Park, Jisoo Park, Bong-Geun Kim, Sang-Ho Lee
- **Year:** 2018
- **Source:** International Journal of Steel Structures / related JCCE IFC-steel-bridge line
- **DOI / link:** https://doi.org/10.1007/s13296-018-0357-1
- **Why relevant:** National IFC MVD for *steel bridges* — the schema a Korean/Asian bridge-design agent would write into.

---

## M. Traditional conceptual / preliminary / detailed design methods, handbooks and codes

### M01
- **Title:** Bridge Engineering Handbook (2nd ed.)
- **Authors:** Wai-Fah Chen, Lian Duan (eds.)
- **Year:** 2014
- **Source:** CRC Press (book, 5 volumes)
- **DOI / link:** https://doi.org/10.1201/b15616
- **Why relevant:** Standard English-language encyclopaedia of the full bridge *design process* (superstructure, substructure, construction, seismic, wind).

### M02
- **Title:** Bridge Engineering: A Global Perspective
- **Authors:** Leonardo Fernández Troyano
- **Year:** 2003 (still the conceptual-form reference)
- **Source:** Thomas Telford / ICE Publishing (book)
- **DOI / link:** https://doi.org/10.1680/beagp.32500
- **Why relevant:** Comparative morphology of bridge types — the human “type-selection” knowledge that MCDM and later agents encode.

### M03
- **Title:** Cable-Stayed Bridges: 40 Years of Experience Worldwide
- **Authors:** Holger Svensson
- **Year:** 2012
- **Source:** Ernst & Sohn / Wiley (book)
- **DOI / link:** https://doi.org/10.1002/9783433601044
- **Why relevant:** Practice-based conceptual and detailed design of cable-stayed bridges from a designer who delivered many of them.

### M04
- **Title:** Prestressed Concrete Bridges
- **Authors:** Christian Menn
- **Year:** 1990 (English ed.; still cited in 2016–2026 conceptual-design papers)
- **Source:** Birkhäuser (book)
- **DOI / link:** https://doi.org/10.1007/978-3-0348-9131-5
- **Why relevant:** The classic statement of *how* a prestressed-concrete bridge is conceived (span, system, prestress layout) before numbers.

### M05
- **Title:** Bridgescape: The Art of Designing Bridges (3rd ed.)
- **Authors:** Frederick Gottemoeller
- **Year:** 2014
- **Source:** Wiley (book)
- **DOI / link:** ISBN 978-1-118-45864-2
- **Why relevant:** Aesthetics + context as first-class conceptual-design criteria — the qualitative half Mueller/Ochsendorf and Tang also insist on.

### M06
- **Title:** The Design of Prestressed Concrete Bridges: Concepts and Principles
- **Authors:** Robert Benaim
- **Year:** 2008
- **Source:** Taylor & Francis (book)
- **DOI / link:** https://doi.org/10.1201/9781482267174
- **Why relevant:** Designer-written process for PC bridges from scheme to detailing — a gold-standard “what an agent should emulate”.

### M07
- **Title:** Seismic Design and Retrofit of Bridges
- **Authors:** M. J. N. Priestley, Frieder Seible, Gian Michele Calvi
- **Year:** 1996 (foundational; later Caltrans SDC / AASHTO seismic guides inherit it)
- **Source:** Wiley (book)
- **DOI / link:** https://doi.org/10.1002/9780470172858
- **Why relevant:** Displacement-based seismic *design process* for bridges — the performance-based half of detailed design.

### M08
- **Title:** Eurocode 2: Design of concrete structures — Part 2: Concrete bridges
- **Authors:** CEN (EN 1992-2)
- **Year:** 2005 / national annexes ongoing
- **Source:** Standard
- **DOI / link:** EN 1992-2:2005
- **Why relevant:** The European concrete-bridge code that ACC/LLM checkers for EU projects must operationalize (alongside AASHTO in Batch 01).

### M09
- **Title:** Eurocode 3: Design of steel structures — Part 2: Steel bridges
- **Authors:** CEN (EN 1993-2)
- **Year:** 2006 / updates
- **Source:** Standard
- **DOI / link:** EN 1993-2:2006
- **Why relevant:** Steel-bridge design rules (members, fatigue, execution) for automated compliance of steel/composite schemes.

### M10
- **Title:** Eurocode 4: Design of composite steel and concrete structures — Part 2: General rules and rules for bridges
- **Authors:** CEN (EN 1994-2)
- **Year:** 2005 / updates
- **Source:** Standard
- **DOI / link:** EN 1994-2:2005
- **Why relevant:** Composite-bridge code — the majority of modern highway overpasses.

### M11
- **Title:** 公路桥涵设计通用规范 JTG D60-2015
- **Authors:** 交通运输部 (MOT, P.R. China)
- **Year:** 2015 (superseding 2004; still the live general spec)
- **Source:** Standard
- **DOI / link:** JTG D60-2015
- **Why relevant:** Chinese general highway-bridge design code (loads, combinations) that Chinese LLM-ACC papers parse.

### M12
- **Title:** 公路钢筋混凝土及预应力混凝土桥涵设计规范 JTG 3362-2018
- **Authors:** 交通运输部 (MOT, P.R. China)
- **Year:** 2018
- **Source:** Standard
- **DOI / link:** JTG 3362-2018
- **Why relevant:** Chinese RC/PC bridge design code — the target of many CNKI “智能审图 / 规范符合性” systems.

### M13
- **Title:** 桥梁概念设计
- **Authors:** 项海帆 (Haifan Xiang)
- **Year:** 2011
- **Source:** 人民交通出版社 (book)
- **DOI / link:** ISBN 978-7-114-08851-3
- **Why relevant:** Authoritative Chinese textbook of *conceptual* bridge design (type, span, aesthetics, wind/seismic at scheme stage).

### M14
- **Title:** Recent evolution of cable-stayed bridges
- **Authors:** Michel Virlogeux
- **Year:** 1999 (classic; still the conceptual-evolution paper cited by 2016–2026 CSB design papers)
- **Source:** Engineering Structures 21(8), 737–755
- **DOI / link:** https://doi.org/10.1016/S0141-0296(98)00028-5
- **Why relevant:** Designer-written account of how cable-stayed *schemes* evolved — the knowledge a conceptual-design agent would retrieve.

### M15
- **Title:** Bridges with multiple cable-stayed spans
- **Authors:** Michel Virlogeux
- **Year:** 2001
- **Source:** Structural Engineering International 11(1)
- **DOI / link:** https://doi.org/10.2749/101686601780347216
- **Why relevant:** Conceptual design of multi-span cable-stayed systems (stiffness, intermediate supports) — still an open scheme-selection problem.

### M16
- **Title:** fib Model Code for Concrete Structures 2010
- **Authors:** fib (International Federation for Structural Concrete)
- **Year:** 2013 (MC2010); MC2020 follow-on
- **Source:** Ernst & Sohn (code)
- **DOI / link:** https://doi.org/10.1002/9783433604090
- **Why relevant:** Performance-based international concrete code used in research-grade bridge design and as a structured target for ACC.

---

## N. LLM / multi-agent / Agentic AI expansion (2023–2026) — not in Batch 01

### N01
- **Title:** BIM-GPT: a Prompt-Based Virtual Assistant Framework for BIM Information Retrieval
- **Authors:** Junwen Zheng, Martin Fischer
- **Year:** 2023
- **Source:** arXiv 2304.09333
- **DOI / link:** https://arxiv.org/abs/2304.09333
- **Why relevant:** Earliest widely cited GPT+BIM IR assistant (Stanford CIFE) — the retrieval half of a design agent.
- **Cites (approx.):** 70+ (preprint) / 190+ journal sibling

### N02
- **Title:** Dynamic prompt-based virtual assistant framework for BIM information search
- **Authors:** Junwen Zheng, Martin Fischer
- **Year:** 2023
- **Source:** Automation in Construction 155, 105067
- **DOI / link:** https://doi.org/10.1016/j.autcon.2023.105067
- **Why relevant:** Journal version of BIMS-GPT: dynamic prompts over BIM data — a 2023 AutCon landmark not in Batch 01.
- **Cites (approx.):** 190+

### N03
- **Title:** Investigating the Use of ChatGPT for the Scheduling of Construction Projects
- **Authors:** Samuel A. Prieto, Eyob T. Mengiste, Borja García de Soto
- **Year:** 2023
- **Source:** Buildings 13(4), 857
- **DOI / link:** https://doi.org/10.3390/buildings13040857
- **Why relevant:** Early empirical ChatGPT study in AEC (schedule generation) — shows what a raw LLM can and cannot do without tools/agents.
- **Cites (approx.):** 290+

### N04
- **Title:** MCP4IFC: IFC-Based Building Design Using Large Language Models
- **Authors:** Bharathi Kannan Nithyanantham, Tobias Sesterhenn, Ashwin Nedungadi, Sergio Peral Garijo, Janis Zenkner, et al.
- **Year:** 2025
- **Source:** arXiv 2511.05533
- **DOI / link:** https://arxiv.org/abs/2511.05533
- **Why relevant:** LLM agents that *plan tool calls on IFC* to design — complementary to Batch 01’s MCP-server architecture paper.

### N05
- **Title:** Text-to-Code Generation for Modular Building Layouts in Building Information Modeling
- **Authors:** Yinyi Wei, Xiao Li
- **Year:** 2025
- **Source:** arXiv 2509.23713
- **DOI / link:** https://arxiv.org/abs/2509.23713
- **Why relevant:** NL → executable BIM code for *modular* layouts — analogous to prefabricated-bridge component assembly.

### N06
- **Title:** Automatic Building Code Review: A Case Study
- **Authors:** Hanlong Wan, Weili Xu, Michael Rosenberg, Jian Zhang, Aysha Siddika
- **Year:** 2025
- **Source:** arXiv 2510.02634
- **DOI / link:** https://arxiv.org/abs/2510.02634
- **Why relevant:** End-to-end LLM case study of *building-code review* — a practice template for JTG/AASHTO bridge checkers.

### N07
- **Title:** Predictive Modeling: BIM Command Recommendation Based on Large-scale Usage Logs
- **Authors:** Changyu Du, Zihan Deng, Stavros Nousias, André Borrmann
- **Year:** 2025
- **Source:** arXiv 2504.05319
- **DOI / link:** https://arxiv.org/abs/2504.05319
- **Why relevant:** Learns BIM authoring *commands* from logs — a non-generative, complementary path to agentic modelling (TUM/Borrmann).

### N08
- **Title:** Text-to-Layout: A Generative Workflow for Drafting Architectural Floor Plans Using LLMs
- **Authors:** Jayakrishna Duggempudi, Lu Gao, Ahmed Senouci, Zhe Han, Yunpeng Zhang
- **Year:** 2025
- **Source:** arXiv 2509.00543
- **DOI / link:** https://arxiv.org/abs/2509.00543
- **Why relevant:** LLM drafting of layouts from text — the architectural analogue of conceptual bridge-scheme generation.

### N09
- **Title:** Investigating the Potential of Large Language Model-based Multi-Agent Systems for Foundation Design
- **Authors:** S. Youwai, et al.
- **Year:** 2025
- **Source:** arXiv 2506.13811
- **DOI / link:** https://arxiv.org/abs/2506.13811
- **Why relevant:** Router-based MAS for *foundation design calculations* — the substructure half of an automated bridge-design loop.

### N10
- **Title:** Enhancing reliability and automation of LLM-based structural analysis using a hybrid multi-agent pipeline
- **Authors:** S. Heo, et al.
- **Year:** 2026
- **Source:** Scientific Reports
- **DOI / link:** https://doi.org/10.1038/s41598-026-50127-8
- **Why relevant:** Verification-and-refinement multi-agent FEM pipeline — a journal counterpart to the OpenSeesPy agent preprints in Batch 01.

### N11
- **Title:** Structural Plan-to-Model Conversion with Deterministic Geometry and Guarded Agentic Vision-Language Refinement
- **Authors:** Mohammad Talebi-Kalaleh, Qipei Mei
- **Year:** 2026
- **Source:** arXiv 2608.17237
- **DOI / link:** https://arxiv.org/abs/2608.17237
- **Why relevant:** Drawing → model with a *guarded* VLM agent (Mei group) — the detailing/documentation interface of automated structural design.

### N12
- **Title:** Reinforcement learning to improve large language model-based automated code compliance systems
- **Authors:** Jack Wei Lun Shi, Minghao Dang, Wawan Solihin, Leong Hien Poh, Justin K. W. Yeoh
- **Year:** 2026
- **Source:** arXiv 2606.22402
- **DOI / link:** https://arxiv.org/abs/2606.22402
- **Why relevant:** RL on top of LLM-ACC, with Solihin (rule-taxonomy, Batch 01 D01) as co-author — closes the ACC spine into the agent era.

### N13
- **Title:** LLM attribution analysis across different fine-tuning strategies and model scales for automated code compliance
- **Authors:** Jack Wei Lun Shi, Minghao Dang, Wawan Solihin, Justin K. W. Yeoh
- **Year:** 2026
- **Source:** arXiv 2604.15589
- **DOI / link:** https://arxiv.org/abs/2604.15589
- **Why relevant:** *Why* an LLM-ACC model decided a clause matched — auditability required for structural/bridge code checking.

### N14
- **Title:** Extracting Structured Requirements from Unstructured Building Technical Specifications for Building Information Modeling
- **Authors:** Insaf Nahri, Romain Pinquié, Philippe Véron, Nicolas Bus, Mathieu Thorel
- **Year:** 2025
- **Source:** arXiv 2508.13833
- **DOI / link:** https://arxiv.org/abs/2508.13833
- **Why relevant:** Specs → structured BIM requirements — the intake step before parametric/agentic modelling.

### N15
- **Title:** Ishigaki-IDS-Bench: A Benchmark for Generating Information Delivery Specification from BIM Information Requirements
- **Authors:** Ryo Kanazawa, Koyo Hidaka, Teppei Miyamoto, Takayuki Kato, Tomoki Ando
- **Year:** 2026
- **Source:** arXiv 2605.22079
- **DOI / link:** https://arxiv.org/abs/2605.22079
- **Why relevant:** LLM benchmark for generating IDS (buildingSMART) from information requirements — needed for contractually valid BrIM delivery.

### N16
- **Title:** Enhancing Building Semantics Preservation in AI Model Training with Large Language Model Encodings
- **Authors:** Suhyung Jang, Ghang Lee, Jaekun Lee, Hyunjun Lee
- **Year:** 2026
- **Source:** arXiv 2602.15791
- **DOI / link:** https://arxiv.org/abs/2602.15791
- **Why relevant:** Uses LLM encodings so learned BIM models keep IFC semantics — Yonsei/Lee group, complementary to Speech-to-BIM in Batch 01.

### N17
- **Title:** Domain-Specific Fine-Tuning and Prompt-Based Learning: A Comparative Study for developing Natural Language-Based BIM Information Retrieval Systems
- **Authors:** Han Gao, Timo Hartmann, Botao Zhong, Kai Lia, Hanbin Luo
- **Year:** 2025
- **Source:** arXiv 2508.05676
- **DOI / link:** https://arxiv.org/abs/2508.05676
- **Why relevant:** Fine-tune vs prompt for NL→BIM IR (Hartmann/Zhong/Luo) — the retrieval design choice every bridge-spec QA system faces.

### N18
- **Title:** Artificial Intelligence, Machine Learning, and Deep Learning in Structural Engineering: A Scientometrics Review of Trends and Best Practices
- **Authors:** A. T. G. Tapeh, M. Z. Naser
- **Year:** 2023
- **Source:** Archives of Computational Methods in Engineering 30, 115–159
- **DOI / link:** https://doi.org/10.1007/s11831-022-09793-w
- **Why relevant:** 2023 scientometric map of AI in *structural engineering* (design/analysis/SHM) — the last pre-agent panoramic review.
- **Cites (approx.):** 250+

### N19
- **Title:** Opportunities and Challenges of Generative AI in Construction Industry: Focusing on ChatGPT
- **Authors:** Prashnna Ghimire, Kyungki Kim, Manoj Acharya
- **Year:** 2024
- **Source:** Journal of Information Technology in Construction / arXiv 2310.04427
- **DOI / link:** https://arxiv.org/abs/2310.04427
- **Why relevant:** Early SWOT of ChatGPT for AEC tasks including design documentation — industry-facing complement to Saka et al. (Batch 01 A08).

### N20
- **Title:** Cost-effective and minimal-intervention BIM information retrieval via condensed multi-LLM agent code generation
- **Authors:** Pei Troh Koh, Hongrui Xue, Jun Ma, Jack C. P. Cheng
- **Year:** 2026
- **Source:** Automation in Construction 181, 106585
- **DOI / link:** https://doi.org/10.1016/j.autcon.2025.106585
- **Why relevant:** Multi-LLM *code-generation* agents that query BIM with minimal intervention — HKUST/Cheng line, reusable on BrIM.

### N21
- **Title:** CODE-ACCORD: A Corpus of Building Regulatory Data for Rule Generation towards Automatic Compliance Checking
- **Authors:** (ACCORD EU project)
- **Year:** 2024
- **Source:** Scientific Data / arXiv 2403.02231
- **DOI / link:** https://arxiv.org/abs/2403.02231
- **Why relevant:** Open annotated corpus of building regulations for *rule generation* — the dataset LLM-ACC and ARCHER-style compilers need (bridge codes still lack an equivalent).

### N22
- **Title:** A Construction-Phase Digital Twin Framework for Quality Assurance and Decision Support in Civil Infrastructure Projects
- **Authors:** Md Asiful Islam, Shanto Jouerder, Md Sabit As Sami, Afia Jahin Prema
- **Year:** 2026
- **Source:** arXiv 2602.16748
- **DOI / link:** https://arxiv.org/abs/2602.16748
- **Why relevant:** Construction-phase DT for civil infrastructure QA — the execution-stage twin that should constrain design agents’ buildability checks.

---

## O. Chinese journals and practice (forward / intelligent / UHPC / composite)

### O01
- **Title:** 钢管混凝土拱桥（第3版）
- **Authors:** 陈宝春 (Baochun Chen)
- **Year:** 2016
- **Source:** 人民交通出版社 (book)
- **DOI / link:** ISBN 978-7-114-13200-1 (verify edition)
- **Why relevant:** Canonical Chinese treatment of CFST *arch-bridge conceptual and detailed design* — a type line under-represented in English Batch 01.

### O02
- **Title:** 超高性能混凝土在桥梁工程中的研究与应用
- **Authors:** 邵旭东, 曹君辉, 等 (Xudong Shao et al.)
- **Year:** 2017–2021 (review series)
- **Source:** 土木工程学报 / 中国公路学报
- **DOI / link:** CNKI; related English: Shao et al. on UHPC bridge decks, Journal of Bridge Engineering
- **Why relevant:** UHPC as a *design-system* choice (not only a material) — a contemporary conceptual-design option Chinese practice now automates parametrically.

### O03
- **Title:** 钢-混凝土组合结构桥梁
- **Authors:** 聂建国 (Jianguo Nie) 等
- **Year:** 2011–2020 (book + JSE/JBE papers)
- **Source:** 科学出版社 / Journal of Structural Engineering
- **DOI / link:** Nie, J.G. composite-bridge paper series, e.g. https://doi.org/10.1061/(ASCE)ST.1943-541X.0000404
- **Why relevant:** Theory-to-practice of steel–concrete *composite* highway bridges — the dominant Chinese short/medium-span type.

### O04
- **Title:** A natural-language-based approach to intelligent data retrieval and representation for cloud BIM
- **Authors:** Jia-Rui Lin, Zhen-Zhong Hu, Jian-Ping Zhang, Fang-Qiang Yu
- **Year:** 2016
- **Source:** Computer-Aided Civil and Infrastructure Engineering 31(1)
- **DOI / link:** https://doi.org/10.1111/mice.12162
- **Why relevant:** Tsinghua Lin/Zhang group’s early NL interface to BIM (query + retrieval) — the process ancestor of Qwen-BIM (Batch 01 F05) and of LLM-BIM IR.

### O05
- **Title:** BIM技术在桥梁工程中的应用现状与展望
- **Authors:** 多篇综述（桥梁建设 / 中外公路 / 公路）
- **Year:** 2016–2024
- **Source:** 桥梁建设, 中外公路
- **DOI / link:** CNKI QLJS / 中外公路
- **Why relevant:** Chinese-practice state of BrIM (forward design vs. “翻模”) — the process gap that parametric/LLM modelling papers claim to close.

### O06
- **Title:** 斜拉桥合理成桥状态与施工过程控制
- **Authors:** 李乔, 李小珍, 卫星 等
- **Year:** 2016–2024 (西南交大斜拉桥设计理论系列)
- **Source:** 桥梁建设 / 土木工程学报 / Journal of Bridge Engineering
- **DOI / link:** CNKI; related English papers in JBE / Structure and Infrastructure Engineering
- **Why relevant:** Chinese “reasonable completed state + construction-stage” design process for cable-stayed bridges — the process H05–H06 automate.

### O07
- **Title:** 公路钢结构桥梁设计规范 JTG D64-2015 及后续修订
- **Authors:** 交通运输部
- **Year:** 2015–
- **Source:** Standard
- **DOI / link:** JTG D64-2015
- **Why relevant:** Chinese steel-bridge code — target of IFC-based steel-bridge ACC (see L14) and of LLM spec-QA.

### O08
- **Title:** 中国桥梁建设 70 年回顾与展望 / 相关《桥梁建设》纪念与综述专栏
- **Authors:** 郑皆连, 项海帆, 范立础 等
- **Year:** 2019–2021
- **Source:** 桥梁建设 / 中国工程科学
- **DOI / link:** CNKI; Engineering Sciences
- **Why relevant:** National narrative of *how* Chinese bridges are conceived and delivered — qualitative process knowledge complementary to the 2021/2024 中国公路学报综述 in Batch 01.

---

## Coverage of this batch

| Theme | IDs | n |
|---|---|---|
| Type-specific optimization (CSB, arch, PC girder, truss, long-span form) | H01–H20 | 20 |
| NLP / BERT / ontology ACC | I01–I18 | 18 |
| Knowledge graphs / ifcOWL / SeeBridge / LBD | J01–J12 | 12 |
| Digital twins of bridges / infrastructure | K01–K12 | 12 |
| Parametric BrIM / generative structural design | L01–L14 | 14 |
| Traditional methods, handbooks, Eurocodes, JTG | M01–M16 | 16 |
| LLM / agent expansion (not in Batch 01) | N01–N22 | 22 |
| Chinese practice / UHPC / composite / steel | O01–O08 | 8 |
| **Total** | | **122 listed (≈114 unique core + 8 supporting codes/books)** |

Running total with Batch 01 (~90 unique core): **≈ 204**. Remaining to ~1000: **≈ 800** (Batches 03+).

Two spines (this batch):
1. **Traditional / computational:** Fairclough/Baandrup conceptual form; Martins cable-stayed optimization; Menn/Troyano/Xiang conceptual methods; Eurocode/JTG; Ji 2013 parametric IFC-Bridge; SeeBridge semantics; Zhang/Zhou/Beach/Nawari ACC; Shim/Lu DT.
2. **Agentic / LLM:** Zheng–Fischer BIMS-GPT; MCP4IFC; Cheng multi-LLM BIM IR; Solihin-line RL-ACC; Mei plan-to-model; Youwai foundation MAS; CODE-ACCORD corpus.

---

## Suggested Batch 03 expansion axes

1. **IABSE / IABMAS / IASS / fib / TRB / ASCE IWCCE / EG-ICE / ISARC / EC3 / CIB W78** paper-level harvest (many 4–8 page conference items).
2. **Wind / seismic / fatigue design methods** of long-span bridges (Ge Yaojun, Xu Y.L., Scanlan/Simiu lineage; AASHTO fatigue; Eurocode 1-4).
3. **Substructure, foundation, abutment, MSE, integral abutment** design process (to pair with N09 foundation agents).
4. **Prefabricated / ABC / UHPC / steel–UHPC composite** design and BrIM (Shao, Chen Baochun, FHWA ABC).
5. **More CNKI:** 《土木工程学报》《工程力学》《建筑结构学报》《中国铁道科学》《铁道学报》正向设计 / 智能设计 / 规范审查.
6. **OpenSees / Midas / RM Bridge / CSI Bridge / SOFiSTiK / Grasshopper-Karamba** automation papers (the tool layer agents wrap).
7. **Remaining 2024–2026 arXiv** on IDS, IFC editing, drawing-to-model, and verification loops not yet listed.
