# Batch 04 — Life-cycle & load rating, IABSE/SEI cases, software APIs, more ACC/BIM, CNKI forward design (~110 items)

Scope: unique vs. Batches 01–03.

---

## Y. Life-cycle design, load rating, redundancy, SHM-informed redesign

### Y01
- **Title:** Life-Cycle Performance of Civil Structure and Infrastructure Systems: Survey
- **Authors:** Fabio Biondini, Dan M. Frangopol
- **Year:** 2018
- **Source:** Journal of Structural Engineering 144(1), 06017001
- **DOI / link:** https://doi.org/10.1061/(ASCE)ST.1943-541X.0001923
- **Why relevant:** Authoritative survey of life-cycle *design and management* of bridges/infra — the time dimension traditional LRFD snapshots omit.
- **Cites (approx.):** 300+

### Y02
- **Title:** Life-cycle management of deteriorating civil infrastructure considering resilience to lifetime hazards
- **Authors:** David Y. Yang, Dan M. Frangopol
- **Year:** 2019
- **Source:** Reliability Engineering & System Safety 183, 197–212
- **DOI / link:** https://doi.org/10.1016/j.ress.2018.11.016
- **Why relevant:** Formal life-cycle optimization under hazards — a computational *design-for-life* process later agentic reliability papers (Batch 01 F26) sit on.

### Y03
- **Title:** Bridge life-cycle performance and cost: analysis, prediction, optimization and decision-making
- **Authors:** Dan M. Frangopol, et al. (IABMAS/IABSE keynotes 2016–2022)
- **Year:** 2017–2022
- **Source:** Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1080/15732479.2016.1267772
- **Why relevant:** Ties conceptual/preliminary choices (material, redundancy, maintainability) to life-cycle cost — a multi-criteria layer for scheme selection.

### Y04
- **Title:** The Manual for Bridge Evaluation (3rd ed. and later interims)
- **Authors:** AASHTO
- **Year:** 2018–2022
- **Source:** Standard (MBE)
- **DOI / link:** AASHTO MBE-3
- **Why relevant:** US *load-rating* process (LRFR/LFR/ASR) — the evaluation counterpart of design, and a structured ACC/agent target.

### Y05
- **Title:** Redundancy in highway bridge superstructures
- **Authors:** Michel Ghosn, Fred Moses, et al. / NCHRP 406 lineage; later 2016–2024 JBE papers
- **Year:** 1998 NCHRP; 2016–2024 updates
- **Source:** NCHRP / Journal of Bridge Engineering
- **DOI / link:** NCHRP Report 406; later https://doi.org/10.1061/(ASCE)BE.1943-5592.0000974
- **Why relevant:** System-redundancy *design factors* — a conceptual-design attribute rarely yet in generative layout tools.

### Y06
- **Title:** Load rating of existing bridges using structural health monitoring
- **Authors:** (Seo, Hu, Zhao, et al. 2016–2023 JBE / SIE reviews)
- **Year:** 2016–2023
- **Source:** Journal of Bridge Engineering / Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000852 (representative)
- **Why relevant:** SHM → rating → possible strengthening *redesign* — closes the DT loop (Batch 02 K) back into design.

### Y07
- **Title:** Fatigue reliability assessment of steel bridges using SHM
- **Authors:** Ye Xia, Yun Liu, et al. / Xu Y.L. group papers 2016–2022
- **Year:** 2016–2022
- **Source:** Engineering Structures / Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2016.xx (Xu/Xia SHM-fatigue line)
- **Why relevant:** Fatigue as a *remaining-life design* problem, not only a new-design check (Batch 03 Q12).

### Y08
- **Title:** Performance-based design of bridges for fire, blast and multi-hazard
- **Authors:** (Quiel, Garlock, Kodur, et al. 2016–2024)
- **Year:** 2016–2024
- **Source:** Engineering Structures / Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2016.01.009 (representative fire-bridge)
- **Why relevant:** Extreme-event *limit states* that conceptual design (continuity, redundancy, material) must anticipate.

### Y09
- **Title:** Climate-change adaptation in life-cycle bridge design
- **Authors:** Mitsuyoshi Akiyama, Dan M. Frangopol, et al.
- **Year:** 2020–2025
- **Source:** Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1080/15732479.2020.1843505
- **Why relevant:** Changes the *load and deterioration models* that detailed design assumes — a future input to agentic design.

### Y10
- **Title:** Sustainability and resilience in bridge engineering: a review
- **Authors:** (Dong, Frangopol, Bocchini 2013; later 2016–2024 SIE special issues)
- **Year:** 2016–2024
- **Source:** Structure and Infrastructure Engineering
- **DOI / link:** https://doi.org/10.1080/15732479.2013.769011 (foundation) ; later SIE special issues
- **Why relevant:** Makes sustainability a *design objective* alongside safety/cost — the extra objective in Batch 01 B08 set-based design.

---

## Z. IABSE / Structural Engineering International — conceptual and signature-bridge design

### Z01
- **Title:** Conceptual design of the 1915 Çanakkale Bridge
- **Authors:** (COWI / Tekfen / T-bridge design team papers in SEI / IABSE 2020–2023)
- **Year:** 2022
- **Source:** Structural Engineering International
- **DOI / link:** https://doi.org/10.1080/10168664.2022.2035889 (representative SEI Çanakkale paper)
- **Why relevant:** Documented *scheme selection* for the current world-record suspension span — a gold-standard conceptual-design case.

### Z02
- **Title:** Design of the Hong Kong–Zhuhai–Macao Bridge immersed tunnel and sea-crossing bridges
- **Authors:** (Meng, Lin, Gao, et al. / SEI and Engineering papers)
- **Year:** 2018–2021
- **Source:** Structural Engineering International / Engineering
- **DOI / link:** https://doi.org/10.1016/j.eng.2017.12.010
- **Why relevant:** Multi-type sea-crossing *system selection* (bridge + island + immersed tunnel) at conceptual/preliminary stage.

### Z03
- **Title:** Design of the Queensferry Crossing
- **Authors:** (Naeem Hussain / ARUP / Transport Scotland SEI papers)
- **Year:** 2016–2018
- **Source:** Structural Engineering International / ICE Proceedings
- **DOI / link:** https://doi.org/10.1680/jbren.16.00025
- **Why relevant:** Multi-tower cable-stayed *conceptual and detailed* design, including crossing-stay decisions (see Batch 02 H11).

### Z04
- **Title:** Design of the Russky Bridge / Vladivostok cable-stayed bridge
- **Authors:** (SK MOST / Institute Giprostroymost papers; SEI)
- **Year:** 2012–2016 still cited
- **Source:** Structural Engineering International
- **DOI / link:** https://doi.org/10.2749/101686612X13363869893400
- **Why relevant:** Record cable-stayed span — scheme, pylon and stay layout as conceptual-design evidence.

### Z05
- **Title:** Millau Viaduct: design and construction
- **Authors:** Michel Virlogeux, Marc Mimram, et al. (SEI / later retrospectives 2016+)
- **Year:** 2004 origin; 2016–2020 retrospectives
- **Source:** Structural Engineering International
- **DOI / link:** https://doi.org/10.2749/101686604777963928
- **Why relevant:** Multi-span cable-stayed *form* as a teaching case for conceptual design (pairs with Batch 02 M15).

### Z06
- **Title:** Design of steel–UHPC composite deck systems for long-span bridges
- **Authors:** Shao Xudong group / SEI and JBE
- **Year:** 2018–2023
- **Source:** Structural Engineering International
- **DOI / link:** https://doi.org/10.1080/10168664.2018.1453772
- **Why relevant:** SEI-level documentation of a new *deck scheme* now spreading in Chinese practice (Batch 03 P08).

### Z07
- **Title:** Aesthetic guidelines for bridge design (IABSE SED / WC3)
- **Authors:** IABSE Working Commission 3 / Gottemoeller, Strasky, et al.
- **Year:** 2016–2022
- **Source:** IABSE SED / SEI
- **DOI / link:** https://iabse.org/Publications/SED
- **Why relevant:** Codifies the *qualitative* conceptual-design criteria Tang (Batch 01 B01) and Gottemoeller (Batch 02 M05) argue for.

### Z08
- **Title:** Stress-ribbon and cable-supported pedestrian bridges
- **Authors:** Jiri Strasky
- **Year:** 2011 (2nd ed.; cited throughout 2016–2026 pedestrian-bridge conceptual papers)
- **Source:** ICE Publishing (book)
- **DOI / link:** https://doi.org/10.1680/srcspb.36129
- **Why relevant:** Pedestrian-bridge *conceptual catalogue* (stress ribbon, cable-stayed, arch) used as a compact design-space for generative studies.

### Z09
- **Title:** ICE Proceedings — Bridge Engineering: recent UK conceptual and parametric-design papers
- **Authors:** various (2020–2026)
- **Year:** 2020–2026
- **Source:** Proceedings of the Institution of Civil Engineers – Bridge Engineering
- **DOI / link:** https://www.icevirtuallibrary.com/toc/jbren/current
- **Why relevant:** Practice-oriented UK bridge *design process* papers (Batch 01 C09 is one; this flags the journal run).

### Z10
- **Title:** fib Bulletin: Precast-concrete bridges / Prefabrication
- **Authors:** fib Commission 1 / Commission 5
- **Year:** 2016–2024
- **Source:** fib Bulletins
- **DOI / link:** https://www.fib-international.org/publications/fib-bulletins.html
- **Why relevant:** International prefabricated-bridge *design guidance* complementary to PCI (Batch 03 P06) and Culmo (P01).

---

## AA. Software APIs and scripted design–analysis automation

### AA01
- **Title:** CSiBridge / SAP2000 OAPI for automated bridge modeling
- **Authors:** Computers and Structures, Inc. (API reference) + academic wrappers 2016–2025
- **Year:** 2016–2025
- **Source:** Software documentation / JBE application papers
- **DOI / link:** https://www.csiamerica.com/products/csibridge
- **Why relevant:** The commercial API that many “automated bridge analysis” papers (and future LLM tool-use agents) wrap.

### AA02
- **Title:** MIDAS Civil Open API and parametric wizard for bridge design
- **Authors:** MIDAS IT + Korean/Chinese application papers
- **Year:** 2016–2025
- **Source:** Software / 桥梁建设 application notes
- **DOI / link:** https://www.midasoft.com/bridge/midas-civil
- **Why relevant:** Dominant Asian bridge-design platform; parametric wizards are the industrial analogue of research BrIM.

### AA03
- **Title:** Bentley RM Bridge / OpenBridge Designer computational workflow
- **Authors:** Bentley Systems
- **Year:** 2016–2025
- **Source:** Software / Bentley Year-in-Infrastructure cases
- **DOI / link:** https://www.bentley.com/software/openbridge-designer/
- **Why relevant:** Alignment-driven 3D bridge design (the vendor implementation of IfcAlignment thinking, Batch 03 T12).

### AA04
- **Title:** SOFiSTiK Teddy / CABD parametric bridge design
- **Authors:** SOFiSTiK AG
- **Year:** 2016–2025
- **Source:** Software / user-group papers
- **DOI / link:** https://www.sofistik.com/
- **Why relevant:** Textual parametric CAD/FEM (CABD) — a compilation target for LLM-generated bridge models (closer to code than Revit GUI).

### AA05
- **Title:** ANSYS ACT / APDL scripting for bridge FEA automation
- **Authors:** ANSYS + academic ACT papers 2016–2024
- **Year:** 2016–2024
- **Source:** Software / Engineering Structures application papers
- **DOI / link:** https://www.ansys.com/
- **Why relevant:** Scripted high-fidelity FEA — the “specialist tool” an analysis agent (Batch 01 F09) may call beyond OpenSees.

### AA06
- **Title:** Grasshopper–Karamba–Kiwi!3d / Compas for computational bridge geometry
- **Authors:** Preisinger (Karamba, Batch 02 H18); Block Research Group COMPAS
- **Year:** 2016–2025
- **Source:** Software / IASS papers
- **DOI / link:** https://compas.dev/
- **Why relevant:** Open computational-geometry stack used in form-finding of shells, funicular bridges and topology-informed schemes.

### AA07
- **Title:** Revit API / Dynamo for infrastructure (Civil 3D + Revit bridge workflows)
- **Authors:** Autodesk University classes 2016–2025 (Informed Design, 2025 cable-stay session, etc.)
- **Year:** 2016–2025
- **Source:** Autodesk University
- **DOI / link:** https://www.autodesk.com/autodesk-university/
- **Why relevant:** The industrial API surface that Text2BIM / BIMgent / MCP servers (Batch 01 F01–F06) actually invoke.

### AA08
- **Title:** Ifc.js / That Open Engine for web-based IFC agents
- **Authors:** That Open Company / community
- **Year:** 2020–2026
- **Source:** Open-source
- **DOI / link:** https://thatopen.com/
- **Why relevant:** Browser IFC viewer/editor that LLM agents can drive without desktop Revit — relevant to MCP/IFC-edit benchmarks.

### AA09
- **Title:** OpenBridge / OpenRoads to IFC 4.3 export implementations
- **Authors:** Bentley / Autodesk / Trimble IFC-infra exporters
- **Year:** 2021–2025
- **Source:** Vendor + buildingSMART deployment reports
- **DOI / link:** https://www.buildingsmart.org/compliance/software-certification/
- **Why relevant:** Whether a generated BrIM is *round-trippable* to IFC 4.3 — a hard evaluation criterion for design agents.

### AA10
- **Title:** AASHTOWare Bridge Design and Rating (BrDR) automation
- **Authors:** AASHTO / agency reports 2016–2025
- **Year:** 2016–2025
- **Source:** Software
- **DOI / link:** https://www.aashtoware.org/
- **Why relevant:** The production US *design+rating* engine that LLM/ACC tools must eventually interoperate with, not only OpenSees.

---

## AB. More ACC, permitting, ontologies (2016–2026)

### AB01
- **Title:** GeoBIM for building permitting: a research agenda
- **Authors:** Francesca Noardo, Thomas Krijnen, et al.
- **Year:** 2020
- **Source:** ISPRS / Automation in Construction related
- **DOI / link:** https://doi.org/10.1016/j.autcon.2019.102979
- **Why relevant:** Digital permitting as the *institutional* home of ACC (extends Batch 03 U07 CORENET).

### AB02
- **Title:** A review of the development and application of BIM-based automated code compliance checking
- **Authors:** (2021–2024 SLR papers beyond Batch 01 D13)
- **Year:** 2021
- **Source:** Automation in Construction / Buildings
- **DOI / link:** https://doi.org/10.3390/buildings11030100 (representative 2021 Buildings SLR)
- **Why relevant:** Extra SLR covering 2010–2020 ACC just before GPT; useful for not double-counting D13.

### AB03
- **Title:** IfcOWL and Linked Building Data in practice: LDAC workshop series
- **Authors:** Pauwels, Beetz, Terkaj, Bonduel, Rasmussen, et al.
- **Year:** 2016–2025
- **Source:** LDAC / Semantic Web Journal companion papers
- **DOI / link:** https://linkedbuildingdata.net/
- **Why relevant:** The practitioner workshop series behind Batch 02 J01–J03.

### AB04
- **Title:** BOT, PRODUCT, OPM, FSO: modular ontologies for the built environment
- **Authors:** Rasmussen, Lefrançois, Schneider, Pauwels, Bonduel
- **Year:** 2019–2023
- **Source:** Semantic Web / LDAC
- **DOI / link:** https://w3id.org/bot#
- **Why relevant:** Ontology *modules* a KG-RAG design agent would retrieve alongside BOT (Batch 02 J03).

### AB05
- **Title:** LegalRuleML and OASIS standards for regulatory knowledge
- **Authors:** OASIS LegalRuleML TC; Dimyadi/Amor applications
- **Year:** 2016–2022
- **Source:** OASIS standard + ITcon applications
- **DOI / link:** https://www.oasis-open.org/committees/legalruleml/
- **Why relevant:** Vendor-neutral executable-law format — a compilation target for ARCHER (Batch 01 F27).

### AB06
- **Title:** Singapore CORENET X / digital regulatory approval (2020s reboot)
- **Authors:** BCA Singapore
- **Year:** 2021–2025
- **Source:** BCA programme
- **DOI / link:** https://www1.bca.gov.sg/buildsg/digitalisation/corenet-x
- **Why relevant:** Next-gen national digital permitting after classic CORENET — the deployment context for LLM-ACC.

### AB07
- **Title:** BIM-based automated code checking in China: 图审 / 智能审图 industry systems
- **Authors:** 审图机构 / 广联达 / 品茗 / 清华BIM课题组 papers 2018–2025
- **Year:** 2018–2025
- **Source:** 图学学报 / 土木建筑工程信息技术 / AutCon (Lin group)
- **DOI / link:** CNKI; linjiarui.net
- **Why relevant:** Chinese *intelligent drawing-checking* industry — the local counterpart of CORENET and of Batch 01 G03.

### AB08
- **Title:** Ontology-based representation of the Eurocodes for automated checking
- **Authors:** (Beach, Li, Rezgui Cardiff group; later EU ACCORD project)
- **Year:** 2016–2024
- **Source:** Automation in Construction / ACCORD deliverables
- **DOI / link:** https://accordproject.eu/ (pairs with Batch 02 N21 CODE-ACCORD)
- **Why relevant:** Eurocode-as-knowledge-graph — needed if EU bridge ACC is not to remain AASHTO/JTG-centric.

### AB09
- **Title:** Fire-safety automated checking on BIM (a mature ACC subdomain)
- **Authors:** (Dimyadi/Amor fire; Preidel; Solibri use-cases; 2016–2024 AutCon)
- **Year:** 2016–2024
- **Source:** Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.12.005 (representative)
- **Why relevant:** Fire ACC is the most commercially mature checker family — a methods template for *structural* ACC.

### AB10
- **Title:** Accessibility / ADA / means-of-egress automated checking
- **Authors:** (Lee, Eastman; Li/Cai/Kamat Batch 03 U05; later 2018–2024)
- **Year:** 2016–2024
- **Source:** Automation in Construction / JCCE
- **DOI / link:** https://doi.org/10.1016/j.autcon.2015.12.019 (Lee–Eastman egress, representative)
- **Why relevant:** Geometry-intensive ACC (Batch 01 D12) matured first on egress — lessons for bridge clearance/gauge checks.

---

## AC. More intelligent / generative structural design (buildings → transferable methods)

### AC01
- **Title:** Intelligent beam-slab layout design using deep learning
- **Authors:** (Lu/Liao group and parallel Korean/US groups 2022–2025)
- **Year:** 2023–2025
- **Source:** Automation in Construction / Journal of Building Engineering
- **DOI / link:** https://doi.org/10.1016/j.autcon.2023.104812 (representative)
- **Why relevant:** Extends StructGAN from walls to *beam-slab* systems — closer to bridge-deck framing.

### AC02
- **Title:** Graph neural networks for structural topology and member-type selection
- **Authors:** (Zhao Liao Lu 2023 Batch 01 E01; follow-ons 2024–2026)
- **Year:** 2024–2026
- **Source:** Advanced Engineering Informatics
- **DOI / link:** https://doi.org/10.1016/j.aei.2024.102512 (representative GNN-structure follow-on)
- **Why relevant:** Member-type as a learned label — analogous to choosing I-girder vs box vs truss.

### AC03
- **Title:** Reinforcement learning for structural design optimization
- **Authors:** (2018–2025 SMO / Engineering Structures RL-TO papers)
- **Year:** 2018–2025
- **Source:** Structural and Multidisciplinary Optimization
- **DOI / link:** https://doi.org/10.1007/s00158-020-02627-y (representative)
- **Why relevant:** RL as an optimizer *and* as the trainer of ACC-improving LLMs (Batch 02 N12).

### AC04
- **Title:** Surrogate-assisted evolutionary structural optimization
- **Authors:** (Jin, Haftka, Forrester lineage; 2016–2024 SMO bridge applications)
- **Year:** 2016–2024
- **Source:** Structural and Multidisciplinary Optimization
- **DOI / link:** https://doi.org/10.1007/s00158-016-1522-2 (Forrester/Keane Kriging textbook papers)
- **Why relevant:** The efficiency trick behind Batch 02 H05 cable-stayed two-layer optimization.

### AC05
- **Title:** Multi-objective optimization of bridges for cost, carbon and safety
- **Authors:** (2018–2025 JBE / Engineering Structures; ties to Batch 01 B12)
- **Year:** 2018–2025
- **Source:** Journal of Bridge Engineering / Engineering Structures
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0001293 (representative)
- **Why relevant:** Explicit 3-objective preliminary design — what an agentic designer should optimize, not only weight.

### AC06
- **Title:** Topology optimization of steel-concrete composite decks and girders
- **Authors:** (2017–2025 SMO / Engineering Structures)
- **Year:** 2017–2025
- **Source:** Structural and Multidisciplinary Optimization
- **DOI / link:** https://doi.org/10.1007/s00158-018-2174-1 (representative)
- **Why relevant:** TO applied to the *actual* highway-bridge cross-section, not only Michell arches.

### AC07
- **Title:** Form-finding of funicular and shell bridges (Thrust Network Analysis applications 2016–2025)
- **Authors:** Philippe Block, Tom Van Mele, et al.
- **Year:** 2016–2025
- **Source:** IASS / Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.autcon.2016.09.010 (RhinoVAULT/TNA applications)
- **Why relevant:** Force-driven conceptual design of arch/shell bridges — a generative method orthogonal to GAN/LLM.

### AC08
- **Title:** Discrete topology optimization / ground-structure methods for bridges
- **Authors:** (Gilbert, Tyas, Fairclough — Batch 02 H03/H17; 2016–2024 follow-ons)
- **Year:** 2016–2024
- **Source:** Structural and Multidisciplinary Optimization
- **DOI / link:** https://doi.org/10.1007/s00158-016-1572-5 (representative)
- **Why relevant:** Ground-structure TO as the classical “generate new bridge types” engine (pairs with Batch 01 E06 VAE).

### AC09
- **Title:** Machine learning for predicting bridge design quantities and cost at conceptual stage
- **Authors:** (2017–2025 JCEM / JBE cost models)
- **Year:** 2017–2025
- **Source:** Journal of Construction Engineering and Management
- **DOI / link:** https://doi.org/10.1061/(ASCE)CO.1943-7862.0001326 (representative)
- **Why relevant:** Conceptual-stage *quantity/cost* predictors — the evaluation head of a scheme-generation agent.

### AC10
- **Title:** Case-based reasoning for bridge type selection (2016–2023 updates of the CBR/MCDM line)
- **Authors:** (beyond Batch 01 B09 fuzzy; CBR papers in ESWA / AutCon)
- **Year:** 2016–2023
- **Source:** Expert Systems with Applications / Automation in Construction
- **DOI / link:** https://doi.org/10.1016/j.eswa.2016.10.008 (representative CBR bridge-type)
- **Why relevant:** Retrieves similar historical bridges for scheme suggestion — RAG before LLMs.

---

## AD. Chinese 正向设计, 智能配筋, 自动出图, 规范审查 (CNKI-heavy)

### AD01
- **Title:** 基于CATIA的桥梁参数化正向设计
- **Authors:** (中交/中铁 CATIA 模板化设计 2016–2023，《桥梁建设》《中外公路》)
- **Year:** 2016–2023
- **Source:** 桥梁建设
- **DOI / link:** CNKI QLJS
- **Why relevant:** Dassault CATIA “skeleton + template” as the Chinese industrial *forward-design* stack (Batch 01 C07).

### AD02
- **Title:** 基于Revit+Dynamo的装配式桥梁智能建模与出图
- **Authors:** (公路院 / 设计院 2018–2025)
- **Year:** 2018–2025
- **Source:** 中外公路 / 公路
- **DOI / link:** CNKI
- **Why relevant:** Dynamo-driven prefab-bridge modelling *and drawing production* — the documentation half of automated design.

### AD03
- **Title:** BIM正向设计在大跨斜拉桥中的应用
- **Authors:** (苏通、沪通、常泰等项目论文 2016–2024)
- **Year:** 2016–2024
- **Source:** 桥梁建设 / 世界桥梁
- **DOI / link:** CNKI
- **Why relevant:** Forward BIM on *signature* cable-stayed projects — process evidence beyond standard-span boxes.

### AD04
- **Title:** 混凝土桥梁智能配筋与钢筋BIM
- **Authors:** (同济/东南/设计院 2017–2025，《土木工程学报》《图学学报》)
- **Year:** 2017–2025
- **Source:** 土木工程学报 / 图学学报
- **DOI / link:** CNKI
- **Why relevant:** Rebar design is the most labour-intensive *detailed-design* task — a high-value agent skill (pairs with Batch 01 F14 drawing agent).

### AD05
- **Title:** 基于知识库的桥梁设计规范符合性自动审查
- **Authors:** (西南交大 / 长安大学 / 重庆交大 2018–2025)
- **Year:** 2018–2025
- **Source:** 铁道科学与工程学报 / 重庆交通大学学报
- **DOI / link:** CNKI
- **Why relevant:** Chinese-campus KG-ACC on JTG — the local pre-LLM line that Batch 01 D11 (LLM highway-bridge checking) supersedes.

### AD06
- **Title:** 桥梁施工图自动生成与三维出图
- **Authors:** (中铁二院 / 中交公路规划设计院 2019–2025)
- **Year:** 2019–2025
- **Source:** 铁路技术创新 / 公路
- **DOI / link:** CNKI
- **Why relevant:** Automated *drawing* from the model — the last mile of detailed design, now being tried with LLM+CAD (Batch 01 F14).

### AD07
- **Title:** 高速铁路32 m简支箱梁标准化与参数化设计
- **Authors:** (中国铁路设计集团 / 铁四院 2016–2023)
- **Year:** 2016–2023
- **Source:** 铁道学报 / 铁道标准设计
- **DOI / link:** CNKI
- **Why relevant:** The most standardized bridge product in the world — the easiest real target for a fully agentic design loop (see Batch 03 X07).

### AD08
- **Title:** 桥梁信息模型交付标准研究（公路/铁路）
- **Authors:** 交通运输部公路科学研究院 / 铁路BIM联盟 2017–2024
- **Year:** 2017–2024
- **Source:** 公路交通科技 / 铁路技术创新
- **DOI / link:** CNKI; MOT research reports
- **Why relevant:** Chinese *information-delivery* specs for BrIM — the IDS/EIR counterpart (Batch 03 T02/T10).

### AD09
- **Title:** 独柱墩桥梁抗倾覆设计方法
- **Authors:** 彭卫兵 等
- **Year:** 2016–2022
- **Source:** 中国公路学报 / 桥梁建设
- **DOI / link:** https://doi.org/10.19721/j.cnki.1001-7372.201x (彭卫兵倾覆系列)
- **Why relevant:** A specifically Chinese *detailed-design* failure mode (single-column pier overturning) that ACC must include.

### AD10
- **Title:** 钢混组合梁桥设计理论进展
- **Authors:** 聂建国, 樊健生, 陶慕轩 等
- **Year:** 2016–2023
- **Source:** 土木工程学报 / Journal of Structural Engineering
- **DOI / link:** CNKI; https://doi.org/10.1061/(ASCE)ST.1943-541X.0000404 (Nie composite line)
- **Why relevant:** Updates Batch 02 O03 with the 2016–2023 *design-theory* papers used in Chinese composite-bridge codes.

---

## AE. Soil–structure, abutments, piers (journal methods)

### AE01
- **Title:** Soil–structure interaction in integral abutment bridges: a review
- **Authors:** (2016–2023 Engineering Structures / JBE reviews)
- **Year:** 2018
- **Source:** Engineering Structures
- **DOI / link:** https://doi.org/10.1016/j.engstruct.2018.05.028 (representative)
- **Why relevant:** SSI is what makes jointless-bridge *preliminary design* non-trivial (Batch 03 R04).

### AE02
- **Title:** Lateral spreading and pile foundations of bridges in liquefaction
- **Authors:** (Brandenberg, Boulanger, Kramer 2016–2022)
- **Year:** 2016–2022
- **Source:** Journal of Geotechnical and Geoenvironmental Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)GT.1943-5606.0001496 (representative)
- **Why relevant:** Geotech *design method* that seismic-bridge agents (Batch 03 Q05–Q07) must call.

### AE03
- **Title:** Strut-and-tie design of bridge piers, pile caps and anchorage zones
- **Authors:** (Schlaich, Schäfer origin; 2016–2024 AASHTO STM papers; Batch 02 cable-pylon STM)
- **Year:** 2016–2024
- **Source:** ACI Structural Journal / Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000990 (representative)
- **Why relevant:** STM is the *detailed-design language* of D-regions — a graph structure GNNs and agents can output.

### AE04
- **Title:** Design of MSE walls and abutments for bridges (FHWA NHI)
- **Authors:** FHWA
- **Year:** 2017
- **Source:** FHWA-NHI-16-024 / GEC
- **DOI / link:** https://www.fhwa.dot.gov/engineering/geotech/
- **Why relevant:** MSE abutment as a *scheme* competing with stub/pile-cap abutments in preliminary design.

### AE05
- **Title:** Pile group analysis for bridge foundations (group efficiency, raft-pile)
- **Authors:** (Poulos; Randolph; 2016–2024 Computers and Geotechnics)
- **Year:** 2016–2024
- **Source:** Computers and Geotechnics
- **DOI / link:** https://doi.org/10.1016/j.compgeo.2016.08.006 (representative)
- **Why relevant:** Computational foundation *design process* wrapping Batch 03 R02–R03.

### AE06
- **Title:** Seismic design of bridge abutments and retaining systems
- **Authors:** (Caltrans; AASHTO; 2016–2023 JBE)
- **Year:** 2016–2023
- **Source:** Journal of Bridge Engineering
- **DOI / link:** https://doi.org/10.1061/(ASCE)BE.1943-5592.0000894 (representative)
- **Why relevant:** Abutment seismic *design rules* often missed by superstructure-only generators.

---

## AF. Remaining LLM / agent / CAD papers (2023–2026)

### AF01
- **Title:** Large language models for computer-aided design: beyond the CSUR survey (application papers)
- **Authors:** (CAD+LLM 2024–2026: Text2CAD, CAD-LLM, SolidWorks copilots)
- **Year:** 2024–2026
- **Source:** arXiv / ACM TOG / Automation in Construction
- **DOI / link:** https://arxiv.org/abs/2404.09407 (representative Text2CAD)
- **Why relevant:** Generic CAD-LLM methods that structural/bridge CAD agents inherit (Batch 01 F28 was the survey).

### AF02
- **Title:** ReAct, Toolformer and function-calling as the agent pattern used in BIM copilots
- **Authors:** Yao et al. ReAct 2022; Schick Toolformer 2023
- **Year:** 2022–2023
- **Source:** ICLR / NeurIPS
- **DOI / link:** https://arxiv.org/abs/2210.03629 (ReAct); https://arxiv.org/abs/2302.04761 (Toolformer)
- **Why relevant:** The *agent pattern* Batch 01 F02/F14 explicitly use (ReAct + tools) — cite the CS origin.

### AF03
- **Title:** Retrieval-Augmented Generation for knowledge-intensive NLP
- **Authors:** Lewis et al.
- **Year:** 2020
- **Source:** NeurIPS
- **DOI / link:** https://arxiv.org/abs/2005.11401
- **Why relevant:** RAG is the default architecture of spec-QA and AutoBIM (Batch 01 D14, F15).

### AF04
- **Title:** GraphRAG for engineering documents
- **Authors:** (2024–2026 engineering-diagram / P&ID GraphRAG; Batch 02 arXiv spillover)
- **Year:** 2024–2026
- **Source:** arXiv
- **DOI / link:** https://arxiv.org/abs/2603.22528 (ChatP&ID representative)
- **Why relevant:** Graph-grounded RAG over drawings/specs — closer to bridge drawings than vector-only RAG.

### AF05
- **Title:** Multimodal LLMs for drawing and sheet understanding in AEC
- **Authors:** (2024–2026 VLM drawing-to-BIM papers; Batch 02 N11 is one)
- **Year:** 2024–2026
- **Source:** arXiv / Automation in Construction
- **DOI / link:** https://arxiv.org/abs/2407.xxxxx (cluster; see also 2608.17237)
- **Why relevant:** VLMs as the *input* interface from existing 2D bridge drawings into models.

### AF06
- **Title:** Guardrails, self-consistency and verifier agents for engineering LLM systems
- **Authors:** (Wang self-consistency 2022; later engineering verifiers 2025–2026)
- **Year:** 2022–2026
- **Source:** NeurIPS / arXiv
- **DOI / link:** https://arxiv.org/abs/2203.11171
- **Why relevant:** The CS techniques behind Batch 01 F12 (hallucination-reduction MAS) and F13 (verification-driven design).

### AF07
- **Title:** Model Context Protocol (MCP) specification
- **Authors:** Anthropic / open spec
- **Year:** 2024–2026
- **Source:** Specification
- **DOI / link:** https://modelcontextprotocol.io/
- **Why relevant:** The protocol Batch 01 F06 instantiates for agentic BIM.

### AF08
- **Title:** Computer-use / GUI agents (OSWorld, Anthropic computer use) applied to engineering software
- **Authors:** (2024–2026; BIMgent Batch 01 F03 is the BIM instance)
- **Year:** 2024–2026
- **Source:** arXiv
- **DOI / link:** https://arxiv.org/abs/2404.07972 (OSWorld representative)
- **Why relevant:** General GUI-agent research that BIMgent specializes to Revit.

### AF09
- **Title:** Domain-adapted LLMs for civil engineering corpora (beyond Zheng 2022 PLM)
- **Authors:** (2023–2026: CivilBERT, Construction-BERT, Qwen-BIM Batch 01 F05)
- **Year:** 2023–2026
- **Source:** arXiv / Automation in Construction
- **DOI / link:** https://arxiv.org/abs/2303.xxxxx (CivilBERT cluster)
- **Why relevant:** Encoder LMs still used for NER/clause-class before decoder LLM agents.

### AF10
- **Title:** Evaluation benchmarks for engineering LLM agents (beyond MASSE/SDAB)
- **Authors:** (2025–2026: BIM-Edit, IFCMemoryBench, Ishigaki-IDS, CODE-ACCORD)
- **Year:** 2025–2026
- **Source:** arXiv
- **DOI / link:** see Batch 01 F22/F23 and Batch 02 N15/N21
- **Why relevant:** Points to the *evaluation* spine that a 1000-paper corpus must keep collecting.

---

## Coverage of this batch

| Theme | IDs | n |
|---|---|---|
| Life-cycle, rating, redundancy, SHM-redesign | Y01–Y10 | 10 |
| IABSE / SEI / ICE / fib conceptual cases | Z01–Z10 | 10 |
| Software APIs (CSi, Midas, RM, SOFiSTiK, Revit, IFC.js) | AA01–AA10 | 10 |
| Further ACC / permitting / ontologies | AB01–AB10 | 10 |
| Further generative / TO / CBR structural design | AC01–AC10 | 10 |
| CNKI forward design / rebar / drawings / JTG checking | AD01–AD10 | 10 |
| SSI, abutments, STM, liquefaction | AE01–AE06 | 6 |
| CS-origin agent/RAG/MCP/VLM papers | AF01–AF10 | 10 |
| **Total** | | **86 listed (plus series flags)** |

Running total: 01 (~90) + 02 (~114) + 03 (~108) + 04 (~86) ≈ **398**. Remaining to ~1000: **≈ 600**.

Note: several AD/Z/AA items are *series flags* (one entry standing for a project-paper cluster). Batch 05 should explode those clusters into paper-level records (IABSE SEI 2016–2026; 桥梁建设 2018–2025 Dynamo/CATIA; ISARC 2018–2025 full papers).

---

## Suggested Batch 05 (paper-level explosion)

1. **ISARC 2018–2025 full-paper list** filtered to BIM, NLP, ACC, DT, agents (~80).
2. **EG-ICE 2018–2025** (~40).
3. **Structural Engineering International 2016–2026** bridge-design articles (~50).
4. **桥梁建设 + 世界桥梁 + 中外公路 2018–2025** 正向/参数化/智能 (~60).
5. **Journal of Bridge Engineering 2016–2026** optimization + BIM + ABC subset (~80).
6. Remaining arXiv 2025–2026 agent papers one-by-one.
